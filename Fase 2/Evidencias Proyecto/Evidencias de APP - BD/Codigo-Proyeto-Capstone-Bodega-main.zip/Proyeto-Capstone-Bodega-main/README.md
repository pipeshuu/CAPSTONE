# Bodega Central para Alimentos No Perecibles

**Descripción**  
Bodega Central es una plataforma de gestión integral para el almacenamiento y distribución de alimentos no perecibles. Permite llevar un control detallado de inventarios, gestionar órdenes de entrada y salida, y generar reportes operativos y de seguimiento.

---

## Funcionalidades principales
- **Control de inventario**: Registro y actualización de existencias por producto, lote y fecha de recepción.  
- **Gestión de pedidos**: Creación y seguimiento de órdenes de salida para clientes o instituciones.  
- **Reportes y estadísticas**: Visualización de niveles de stock, rotación de productos y alertas de reabastecimiento.  
- **Roles y permisos**: Usuarios administradores, operadores de almacén y consultores con accesos diferenciados.  
- **Auditoría de movimientos**: Historial completo de entradas/salidas con trazabilidad de usuarios.

---

## Tecnologías y herramientas
- **Frontend**: Angular, TypeScript 
- **Backend**: Python (FastAPI), Docker
- **Base de datos**: Postgres SQL
- **Almacenamiento de archivos estaticos**: AWS S3  

---
