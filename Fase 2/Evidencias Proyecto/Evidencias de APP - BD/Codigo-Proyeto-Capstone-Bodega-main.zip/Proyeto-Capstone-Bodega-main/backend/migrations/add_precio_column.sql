-- Script para agregar la columna precio a la tabla producto
ALTER TABLE producto 
ADD COLUMN IF NOT EXISTS precio NUMERIC(12, 2);

-- Mensaje de confirmación
DO $$
BEGIN
    RAISE NOTICE 'Columna precio agregada a la tabla producto';
END $$; 