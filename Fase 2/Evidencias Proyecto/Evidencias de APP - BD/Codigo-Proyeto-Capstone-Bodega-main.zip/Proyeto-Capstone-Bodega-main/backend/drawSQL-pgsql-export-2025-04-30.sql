CREATE TABLE "proveedor"(
    "proveedor_id" BIGINT NOT NULL,
    "nombre" TEXT NOT NULL,
    "ruc" VARCHAR(20) NULL,
    "direccion" TEXT NULL,
    "contacto" TEXT NULL,
    "telefono" VARCHAR(50) NULL
);
ALTER TABLE
    "proveedor" ADD PRIMARY KEY("proveedor_id");
ALTER TABLE
    "proveedor" ADD CONSTRAINT "proveedor_ruc_unique" UNIQUE("ruc");
CREATE TABLE "producto"(
    "producto_id" BIGINT NOT NULL,
    "sku" VARCHAR(100) NOT NULL,
    "nombre" TEXT NOT NULL,
    "descripcion" TEXT NULL,
    "unidad_medida" VARCHAR(50) NULL,
    "peso" DECIMAL(10, 2) NULL,
    "categoria_id" BIGINT NOT NULL
);
ALTER TABLE
    "producto" ADD PRIMARY KEY("producto_id");
ALTER TABLE
    "producto" ADD CONSTRAINT "producto_sku_unique" UNIQUE("sku");
CREATE TABLE "bodega"(
    "bodega_id" BIGINT NOT NULL,
    "nombre" TEXT NOT NULL,
    "direccion" TEXT NULL,
    "tipo" VARCHAR(20) NOT NULL,
    "parent_bodega_id" BIGINT NULL
);
ALTER TABLE
    "bodega" ADD PRIMARY KEY("bodega_id");
CREATE TABLE "ubicacion"(
    "ubicacion_id" BIGINT NOT NULL,
    "bodega_id" BIGINT NOT NULL,
    "codigo" VARCHAR(50) NOT NULL,
    "descripcion" TEXT NULL,
    "capacidad_max" INTEGER NULL
);
ALTER TABLE
    "ubicacion" ADD PRIMARY KEY("ubicacion_id");
ALTER TABLE
    "ubicacion" ADD CONSTRAINT "ubicacion_codigo_unique" UNIQUE("codigo");
CREATE TABLE "empleado"(
    "empleado_id" BIGINT NOT NULL,
    "nombre" TEXT NOT NULL,
    "apellidos" TEXT NULL,
    "cargo" VARCHAR(100) NULL,
    "usuario_sistema" VARCHAR(100) NULL,
    "bodega_id" BIGINT NOT NULL
);
ALTER TABLE
    "empleado" ADD PRIMARY KEY("empleado_id");
ALTER TABLE
    "empleado" ADD CONSTRAINT "empleado_usuario_sistema_unique" UNIQUE("usuario_sistema");
CREATE TABLE "orden_compra"(
    "oc_id" BIGINT NOT NULL,
    "proveedor_id" BIGINT NOT NULL,
    "fecha_emision" TIMESTAMP(0) WITH
        TIME zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
        "estado" VARCHAR(20) NOT NULL
);
ALTER TABLE
    "orden_compra" ADD PRIMARY KEY("oc_id");
CREATE TABLE "detalle_oc"(
    "oc_detalle_id" BIGINT NOT NULL,
    "oc_id" BIGINT NOT NULL,
    "producto_id" BIGINT NOT NULL,
    "cantidad" INTEGER NOT NULL,
    "precio_unitario" DECIMAL(12, 4) NOT NULL
);
ALTER TABLE
    "detalle_oc" ADD PRIMARY KEY("oc_detalle_id");
CREATE TABLE "inventario"(
    "inv_id" BIGINT NOT NULL,
    "producto_id" BIGINT NOT NULL,
    "ubicacion_id" BIGINT NOT NULL,
    "cantidad_actual" INTEGER NOT NULL,
    "cantidad_maxima" INTEGER NOT NULL
);
ALTER TABLE
    "inventario" ADD PRIMARY KEY("inv_id");
CREATE TABLE "movimiento"(
    "mov_id" BIGINT NOT NULL,
    "inv_id" BIGINT NOT NULL,
    "empleado_id" BIGINT NOT NULL,
    "tipo_mov" VARCHAR(20) NOT NULL,
    "cantidad" INTEGER NOT NULL,
    "fecha_hora" TIMESTAMP(0) WITH
        TIME zone NOT NULL DEFAULT CURRENT_TIMESTAMP,
        "referencia" TEXT NULL
);
ALTER TABLE
    "movimiento" ADD PRIMARY KEY("mov_id");
CREATE TABLE "solicitud"(
    "solicitud_id" BIGINT NOT NULL,
    "bodega_id" BIGINT NOT NULL,
    "estado" VARCHAR(255) NOT NULL
);
ALTER TABLE
    "solicitud" ADD PRIMARY KEY("solicitud_id");
CREATE TABLE "categoria"(
    "categoria_id" BIGINT NOT NULL,
    "nombre" VARCHAR(255) NOT NULL,
    "descripcion" VARCHAR(255) NOT NULL
);
ALTER TABLE
    "categoria" ADD PRIMARY KEY("categoria_id");
ALTER TABLE
    "empleado" ADD CONSTRAINT "empleado_bodega_id_foreign" FOREIGN KEY("bodega_id") REFERENCES "bodega"("bodega_id");
ALTER TABLE
    "bodega" ADD CONSTRAINT "bodega_parent_bodega_id_foreign" FOREIGN KEY("parent_bodega_id") REFERENCES "bodega"("bodega_id");
ALTER TABLE
    "producto" ADD CONSTRAINT "producto_categoria_id_foreign" FOREIGN KEY("categoria_id") REFERENCES "categoria"("categoria_id");
ALTER TABLE
    "detalle_oc" ADD CONSTRAINT "detalle_oc_producto_id_foreign" FOREIGN KEY("producto_id") REFERENCES "producto"("producto_id");
ALTER TABLE
    "ubicacion" ADD CONSTRAINT "ubicacion_bodega_id_foreign" FOREIGN KEY("bodega_id") REFERENCES "bodega"("bodega_id");
ALTER TABLE
    "inventario" ADD CONSTRAINT "inventario_ubicacion_id_foreign" FOREIGN KEY("ubicacion_id") REFERENCES "ubicacion"("ubicacion_id");
ALTER TABLE
    "orden_compra" ADD CONSTRAINT "orden_compra_proveedor_id_foreign" FOREIGN KEY("proveedor_id") REFERENCES "proveedor"("proveedor_id");
ALTER TABLE
    "detalle_oc" ADD CONSTRAINT "detalle_oc_oc_id_foreign" FOREIGN KEY("oc_id") REFERENCES "orden_compra"("oc_id");
ALTER TABLE
    "inventario" ADD CONSTRAINT "inventario_producto_id_foreign" FOREIGN KEY("producto_id") REFERENCES "producto"("producto_id");
ALTER TABLE
    "solicitud" ADD CONSTRAINT "solicitud_bodega_id_foreign" FOREIGN KEY("bodega_id") REFERENCES "bodega"("bodega_id");
ALTER TABLE
    "movimiento" ADD CONSTRAINT "movimiento_inv_id_foreign" FOREIGN KEY("inv_id") REFERENCES "inventario"("inv_id");
ALTER TABLE
    "movimiento" ADD CONSTRAINT "movimiento_empleado_id_foreign" FOREIGN KEY("empleado_id") REFERENCES "empleado"("empleado_id");