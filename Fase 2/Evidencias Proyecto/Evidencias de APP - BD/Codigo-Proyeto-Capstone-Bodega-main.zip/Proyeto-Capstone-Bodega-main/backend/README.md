# Backend Bodega

Este es el backend para el sistema de gestión de bodega, desarrollado con FastAPI y PostgreSQL.

## Requisitos Previos

- Python 3.8 o superior
- Docker y Docker Compose
- PostgreSQL (se puede usar el contenedor Docker proporcionado)

## Configuración del Entorno

1. Clonar el repositorio:
```bash
git clone [URL_DEL_REPOSITORIO]
cd backend
```

2. Crear un entorno virtual (opcional pero recomendado):
```bash
python -m venv venv
source venv/bin/activate  # En Windows: venv\Scripts\activate
```

3. Instalar dependencias:
```bash
pip install -r requirements.txt
```

## Configuración de la Base de Datos

El proyecto utiliza Docker Compose para la base de datos. Para iniciar la base de datos:

```bash
docker-compose up --build -d
```

## Ejecutar la Aplicación

1. Iniciar el servidor de desarrollo:
```bash
uvicorn main:app --reload
```

2. La aplicación estará disponible en:
```
http://localhost:8000
```

3. Para ver la documentación de la API:
```
http://localhost:8000/docs
```

## Estructura del Proyecto

- `main.py`: Punto de entrada de la aplicación y definición de endpoints
- `models.py`: Modelos de la base de datos (Proveedor, Producto, Bodega, Ubicacion, Empleado, OrdenCompra, etc.)
- `database.py`: Configuración de la base de datos
- `seed_data.py`: Script para poblar la base de datos con datos iniciales
- `requirements.txt`: Dependencias del proyecto

## Modelos Principales

El sistema incluye los siguientes modelos principales:
- Proveedor
- Producto
- Bodega
- Ubicacion
- Empleado
- OrdenCompra
- DetalleOC
- Inventario
- Movimiento

## Variables de Entorno

El proyecto utiliza las siguientes variables de entorno:
- `DATABASE_URL`: URL de conexión a la base de datos
- `POSTGRES_USER`: Usuario de PostgreSQL
- `POSTGRES_PASSWORD`: Contraseña de PostgreSQL
- `POSTGRES_DB`: Nombre de la base de datos

## Despliegue con Docker

Para construir y ejecutar la aplicación usando Docker:

```bash
docker build -t backend-bodega .
docker-compose up
```

## Notas Adicionales

- La base de datos se inicializa automáticamente al iniciar el contenedor
- Se recomienda usar el script `seed_data.py` para poblar la base de datos con datos de prueba:
```bash
docker-compose exec api python seed_data.py
```
- La API sigue las especificaciones de OpenAPI y está documentada en `/docs`
- Los endpoints principales están disponibles en la documentación de Swagger UI 