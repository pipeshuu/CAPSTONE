from fastapi import APIRouter, Depends, HTTPException, Path, Body, UploadFile, File, status, Form
from fastapi.openapi.utils import get_openapi
from sqlalchemy.orm import Session
from typing import List, Optional, Dict, Any
from ....models.models import Producto as ProductoModel
from ....schemas.producto import Producto, ProductoCreate, ProductoForm
from ....database import get_db
from ....models.auth import Usuario
from .auth import get_current_user
from .... import models, schemas
from ....utils.s3 import upload_file_to_s3, delete_file_from_s3

router = APIRouter()

@router.post("/", 
         response_model=Producto,
         summary="Crear un nuevo producto",
         description="Crea un nuevo producto con la información proporcionada. El SKU debe ser único. Permite subir una imagen junto con los datos del producto.",
         openapi_extra={
             "requestBody": {
                 "content": {
                     "multipart/form-data": {
                         "schema": {
                             "type": "object",
                             "properties": {
                                 "sku": {"type": "string", "description": "SKU del producto"},
                                 "nombre": {"type": "string", "description": "Nombre del producto"},
                                 "descripcion": {"type": "string", "description": "Descripción del producto"},
                                 "unidad_medida": {"type": "string", "description": "Unidad de medida del producto"},
                                 "peso": {"type": "number", "format": "float", "description": "Peso del producto"},
                                 "categoria_id": {"type": "integer", "description": "ID de la categoría"},
                                 "precio": {"type": "number", "format": "float", "description": "Precio del producto"},
                                 "file": {
                                     "type": "string", 
                                     "format": "binary",
                                     "description": "Imagen del producto (jpg, jpeg, png)"
                                 }
                             },
                             "required": ["sku", "nombre", "categoria_id"]
                         }
                     }
                 }
             }
         }
)
async def create_producto(
    sku: str = Form(..., description="SKU del producto"),
    nombre: str = Form(..., description="Nombre del producto"),
    descripcion: Optional[str] = Form(None, description="Descripción del producto"),
    unidad_medida: Optional[str] = Form(None, description="Unidad de medida del producto"),
    peso: Optional[float] = Form(None, description="Peso del producto"),
    categoria_id: int = Form(..., description="ID de la categoría"),
    precio: Optional[float] = Form(None, description="Precio del producto"),
    file: Optional[UploadFile] = File(None, description="Imagen del producto (opcional)"),
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
):
    try:
        # Verificar si el SKU ya existe
        existing_sku = db.query(ProductoModel).filter(ProductoModel.sku == sku).first()
        if existing_sku:
            raise HTTPException(status_code=400, detail=f"El SKU {sku} ya está en uso por otro producto")
            
        # Crear un objeto con los datos del formulario
        producto_data = ProductoForm(
            sku=sku,
            nombre=nombre,
            descripcion=descripcion,
            unidad_medida=unidad_medida,
            peso=peso,
            categoria_id=categoria_id,
            precio=precio
        )
        
        # Procesar la imagen si se proporcionó
        if file:
            # Verificar que el archivo es una imagen
            content_type = file.content_type
            if not content_type or not content_type.startswith("image/"):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="El archivo debe ser una imagen (jpg, jpeg, png)"
                )
            
            # Subir la imagen a S3
            imagen_url = await upload_file_to_s3(file, folder=f"productos/{sku}")
            
            if not imagen_url:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail="Error al subir la imagen a S3"
                )
            
            # Agregar la URL de la imagen a los datos del producto
            producto_data.imagen_url = imagen_url
        
        # Crear el producto en la base de datos
        db_producto = ProductoModel(**producto_data.to_dict())
        db.add(db_producto)
        db.commit()
        db.refresh(db_producto)
        return db_producto
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/", response_model=List[schemas.Producto],
         summary="Listar todos los productos",
         description="Obtiene una lista de todos los productos con información de sus categorías. Soporta paginación mediante parámetros skip y limit.")
def read_productos(
    skip: int = 0, 
    limit: int = 100, 
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
):
    productos = db.query(models.Producto).join(models.Categoria).offset(skip).limit(limit).all()
    return productos

@router.get("/{producto_identificador}", response_model=schemas.Producto,
         summary="Obtener un producto por ID o SKU",
         description="Recupera un producto usando su ID numérico o su código SKU como identificador.")
def read_producto(
    producto_identificador: str = Path(..., description="ID numérico o código SKU del producto"),
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
):
    try:
        # Verificar si el identificador es un ID (número) o un SKU (texto)
        is_id = producto_identificador.isdigit()
        
        # Buscar el producto según el tipo de identificador
        if is_id:
            producto = db.query(models.Producto).join(models.Categoria).filter(models.Producto.producto_id == int(producto_identificador)).first()
        else:
            producto = db.query(models.Producto).join(models.Categoria).filter(models.Producto.sku == producto_identificador).first()
        
        if producto is None:
            tipo = "ID" if is_id else "SKU"
            raise HTTPException(status_code=404, detail=f"Producto con {tipo} {producto_identificador} no encontrado")
        
        return producto
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.put("/{producto_identificador}", 
         response_model=Producto,
         summary="Actualizar un producto por ID o SKU",
         description="Actualiza un producto usando su ID numérico o su código SKU como identificador. Permite subir una imagen junto con los datos del producto.",
         openapi_extra={
             "requestBody": {
                 "content": {
                     "multipart/form-data": {
                         "schema": {
                             "type": "object",
                             "properties": {
                                 "sku": {"type": "string", "description": "SKU del producto"},
                                 "nombre": {"type": "string", "description": "Nombre del producto"},
                                 "descripcion": {"type": "string", "description": "Descripción del producto"},
                                 "unidad_medida": {"type": "string", "description": "Unidad de medida del producto"},
                                 "peso": {"type": "number", "format": "float", "description": "Peso del producto"},
                                 "categoria_id": {"type": "integer", "description": "ID de la categoría"},
                                 "precio": {"type": "number", "format": "float", "description": "Precio del producto"},
                                 "file": {
                                     "type": "string", 
                                     "format": "binary",
                                     "description": "Imagen del producto (jpg, jpeg, png)"
                                 }
                             },
                             "required": ["sku", "nombre", "categoria_id"]
                         }
                     }
                 }
             }
         }
)
async def update_producto(
    producto_identificador: str = Path(..., description="ID numérico o código SKU del producto"), 
    sku: str = Form(..., description="SKU del producto"),
    nombre: str = Form(..., description="Nombre del producto"),
    descripcion: Optional[str] = Form(None, description="Descripción del producto"),
    unidad_medida: Optional[str] = Form(None, description="Unidad de medida del producto"),
    peso: Optional[float] = Form(None, description="Peso del producto"),
    categoria_id: int = Form(..., description="ID de la categoría"),
    precio: Optional[float] = Form(None, description="Precio del producto"),
    file: Optional[UploadFile] = File(None, description="Imagen del producto (opcional)"),
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
):
    try:
        # Verificar si el identificador es un ID (número) o un SKU (texto)
        is_id = producto_identificador.isdigit()
        
        # Buscar el producto según el tipo de identificador
        if is_id:
            db_producto = db.query(ProductoModel).filter(ProductoModel.producto_id == int(producto_identificador)).first()
        else:
            db_producto = db.query(ProductoModel).filter(ProductoModel.sku == producto_identificador).first()
        
        if db_producto is None:
            tipo = "ID" if is_id else "SKU"
            raise HTTPException(status_code=404, detail=f"Producto con {tipo} {producto_identificador} no encontrado")
        
        # Verificar si el SKU ya existe en otro producto (si se está cambiando el SKU)
        if sku != db_producto.sku:
            existing_sku = db.query(ProductoModel).filter(ProductoModel.sku == sku).first()
            if existing_sku:
                raise HTTPException(status_code=400, detail=f"El SKU {sku} ya está en uso por otro producto")
        
        # Crear un objeto con los datos del formulario
        producto_data = ProductoForm(
            sku=sku,
            nombre=nombre,
            descripcion=descripcion,
            unidad_medida=unidad_medida,
            peso=peso,
            categoria_id=categoria_id,
            precio=precio
        )
        
        # Procesar la imagen si se proporcionó
        if file:
            # Verificar que el archivo es una imagen
            content_type = file.content_type
            if not content_type or not content_type.startswith("image/"):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="El archivo debe ser una imagen (jpg, jpeg, png)"
                )
            
            # Si el producto ya tiene una imagen, eliminarla de S3
            if db_producto.imagen_url:
                await delete_file_from_s3(db_producto.imagen_url)
            
            # Subir la nueva imagen a S3
            imagen_url = await upload_file_to_s3(file, folder=f"productos/{sku}")
            
            if not imagen_url:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail="Error al subir la imagen a S3"
                )
            
            # Agregar la URL de la imagen a los datos del producto
            producto_data.imagen_url = imagen_url
        
        # Actualizar los campos del producto
        for key, value in producto_data.to_dict().items():
            if value is not None:  # Solo actualizar campos no nulos
                setattr(db_producto, key, value)
        
        db.commit()
        db.refresh(db_producto)
        return db_producto
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@router.delete("/{producto_identificador}",
              summary="Eliminar un producto por ID o SKU",
              description="Elimina un producto usando su ID numérico o su código SKU como identificador.")
def delete_producto(
    producto_identificador: str = Path(..., description="ID numérico o código SKU del producto"),
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
):
    try:
        # Verificar si el identificador es un ID (número) o un SKU (texto)
        is_id = producto_identificador.isdigit()
        
        # Buscar el producto según el tipo de identificador
        if is_id:
            db_producto = db.query(ProductoModel).filter(ProductoModel.producto_id == int(producto_identificador)).first()
        else:
            db_producto = db.query(ProductoModel).filter(ProductoModel.sku == producto_identificador).first()
        
        if db_producto is None:
            tipo = "ID" if is_id else "SKU"
            raise HTTPException(status_code=404, detail=f"Producto con {tipo} {producto_identificador} no encontrado")
        
        # Verificar si el producto está siendo usado en detalles de órdenes de compra
        detalles = db.query(models.DetalleOC).filter(models.DetalleOC.producto_id == db_producto.producto_id).all()
        if detalles:
            # Opción 1: Rechazar la eliminación
            raise HTTPException(
                status_code=400, 
                detail="No se puede eliminar el producto porque está en uso en órdenes de compra"
            )
            
            # Opción 2: Si prefieres eliminar las referencias en cascada, descomenta estas líneas
            # for detalle in detalles:
            #     db.delete(detalle)
        
        # Verificar si el producto está siendo usado en inventario
        inventarios = db.query(models.Inventario).filter(models.Inventario.producto_id == db_producto.producto_id).all()
        if inventarios:
            # Opción 1: Rechazar la eliminación
            raise HTTPException(
                status_code=400, 
                detail="No se puede eliminar el producto porque está en uso en inventario"
            )
            
            # Opción 2: Si prefieres eliminar las referencias en cascada, descomenta estas líneas
            # for inventario in inventarios:
            #     db.delete(inventario)
        
        # Eliminar la imagen de S3 si existe
        if db_producto.imagen_url:
            delete_file_from_s3(db_producto.imagen_url)
            
        # Si no hay referencias o se han eliminado, eliminar el producto
        db.delete(db_producto)
        db.commit()
        return {"message": f"Producto {db_producto.nombre} eliminado exitosamente"}
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e)) 