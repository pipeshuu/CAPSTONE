from datetime import timedelta
from fastapi import APIRouter, Depends, HTTPException, status, Query
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from typing import Any
from ....core.config import settings
from ....core.security import verify_password, create_access_token, get_password_hash
from ....models.auth import Usuario
from ....schemas.auth import Token, UsuarioCreate, Usuario as UsuarioSchema, UsuarioList
from ....database import get_db
from jose import jwt, JWTError
import uuid

router = APIRouter()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl=f"{settings.API_V1_STR}/auth/login")

async def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db)
) -> Usuario:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        usuario_id: str = payload.get("sub")
        if usuario_id is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception
    
    usuario = db.query(Usuario).filter(Usuario.usuario_id == usuario_id).first()
    if usuario is None:
        raise credentials_exception
    return usuario

async def get_current_admin_user(
    current_user: Usuario = Depends(get_current_user)
) -> Usuario:
    if not current_user.es_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="El usuario no tiene permisos de administrador"
        )
    return current_user

@router.get("/users", response_model=UsuarioList)
async def list_usuarios(
    db: Session = Depends(get_db),
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=100),
    current_user: Usuario = Depends(get_current_admin_user)
) -> Any:
    """
    Devuelve la lista de usuarios.
    Solo accesible para administradores.
    """
    usuarios = db.query(Usuario).offset(skip).limit(limit).all()
    total = db.query(Usuario).count()
    return {"items": usuarios, "total": total}

@router.get("/users/{usuario_id}", response_model=UsuarioSchema)
async def get_usuario(
    usuario_id: str,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Obtiene un usuario por ID.
    """
    # Solo los administradores pueden ver cualquier usuario
    # Los usuarios regulares solo pueden ver su propia información
    if not current_user.es_admin and current_user.usuario_id != usuario_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No tiene permisos para acceder a esta información"
        )
    
    usuario = db.query(Usuario).filter(Usuario.usuario_id == usuario_id).first()
    if not usuario:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")
    
    return usuario

@router.post("/register", response_model=UsuarioSchema)
def register(usuario: UsuarioCreate, db: Session = Depends(get_db)):
    db_usuario = db.query(Usuario).filter(Usuario.email == usuario.email).first()
    if db_usuario:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already registered"
        )
    
    hashed_password = get_password_hash(usuario.password)
    db_usuario = Usuario(
        usuario_id=str(uuid.uuid4()),
        email=usuario.email,
        hashed_password=hashed_password,
        nombre=usuario.nombre,
        apellidos=usuario.apellidos
    )
    db.add(db_usuario)
    db.commit()
    db.refresh(db_usuario)
    return db_usuario

@router.post("/login", response_model=Token)
def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db)
):
    usuario = db.query(Usuario).filter(Usuario.email == form_data.username).first()
    if not usuario or not verify_password(form_data.password, usuario.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": usuario.usuario_id}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}

@router.get("/me", response_model=UsuarioSchema)
async def get_user_me(
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Obtiene información del usuario actual.
    """
    return current_user 