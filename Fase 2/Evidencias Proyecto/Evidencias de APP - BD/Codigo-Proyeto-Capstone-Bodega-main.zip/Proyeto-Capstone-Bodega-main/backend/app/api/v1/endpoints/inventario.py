from typing import Any, List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status, Response
from sqlalchemy.orm import Session, joinedload
from sqlalchemy.sql import func, select, join
from sqlalchemy.exc import IntegrityError

from ....database import get_db
from ....models.models import Inventario, Producto, Bodega, Movimiento
from ....models.auth import Usuario
from .auth import get_current_user
from ....schemas.inventario import (
    InventarioBase,
    InventarioCreate,
    InventarioUpdate,
    InventarioList,
    InventarioDetalle,
    InventarioBodega,
    InventarioBodegaList
)

router = APIRouter()

@router.get("/", response_model=InventarioList)
def get_inventarios(
    db: Session = Depends(get_db),
    skip: int = 0,
    limit: int = 100,
    producto_id: Optional[int] = None,
    bodega_id: Optional[int] = None,
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Obtener lista de inventarios con filtros opcionales.
    """
    query = db.query(Inventario)
    
    # Aplicar filtros si están presentes
    if producto_id:
        query = query.filter(Inventario.producto_id == producto_id)
    if bodega_id:
        query = query.filter(Inventario.bodega_id == bodega_id)
    
    total = query.count()
    inventarios = query.offset(skip).limit(limit).all()
    
    return {
        "items": inventarios,
        "total": total
    }

@router.get("/{inv_id}", response_model=InventarioDetalle)
def get_inventario(
    *,
    db: Session = Depends(get_db),
    inv_id: int,
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Obtener un inventario por su ID con detalles del producto y bodega.
    """
    inventario = db.query(Inventario).filter(Inventario.inv_id == inv_id).first()
    if not inventario:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Inventario con ID {inv_id} no encontrado"
        )
    
    # Obtener datos del producto
    producto = db.query(Producto).filter(Producto.producto_id == inventario.producto_id).first()
    producto_dict = {
        "producto_id": producto.producto_id,
        "sku": producto.sku,
        "nombre": producto.nombre,
        "descripcion": producto.descripcion,
        "unidad_medida": producto.unidad_medida,
        "categoria_id": producto.categoria_id
    }
    
    # Obtener datos de la bodega
    bodega = db.query(Bodega).filter(Bodega.bodega_id == inventario.bodega_id).first()
    bodega_dict = {
        "bodega_id": bodega.bodega_id,
        "nombre": bodega.nombre,
        "direccion": bodega.direccion,
        "tipo": bodega.tipo
    }
    
    # Construir respuesta combinada
    result = {
        "inv_id": inventario.inv_id,
        "producto_id": inventario.producto_id,
        "bodega_id": inventario.bodega_id,
        "codigo_posicion": inventario.codigo_posicion,
        "cantidad_actual": inventario.cantidad_actual,
        "cantidad_maxima": inventario.cantidad_maxima,
        "producto": producto_dict,
        "bodega": bodega_dict
    }
    
    return result

@router.post("/", response_model=InventarioBase, status_code=status.HTTP_201_CREATED)
def create_inventario(
    *,
    db: Session = Depends(get_db),
    inventario_in: InventarioCreate,
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Crear un nuevo registro de inventario.
    """
    # Verificar si existe el producto
    producto = db.query(Producto).filter(Producto.producto_id == inventario_in.producto_id).first()
    if not producto:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Producto con ID {inventario_in.producto_id} no encontrado"
        )
    
    # Verificar si existe la bodega
    bodega = db.query(Bodega).filter(Bodega.bodega_id == inventario_in.bodega_id).first()
    if not bodega:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Bodega con ID {inventario_in.bodega_id} no encontrada"
        )
    
    # Verificar si ya existe un inventario para ese producto con ese código de posición en esa bodega
    existing = db.query(Inventario).filter(
        Inventario.producto_id == inventario_in.producto_id,
        Inventario.bodega_id == inventario_in.bodega_id,
        Inventario.codigo_posicion == inventario_in.codigo_posicion
    ).first()
    
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Ya existe un registro de inventario para el producto {producto.nombre} en la posición {inventario_in.codigo_posicion} de la bodega {bodega.nombre}"
        )
    
    # Crear el nuevo registro de inventario
    db_inventario = Inventario(
        producto_id=inventario_in.producto_id,
        bodega_id=inventario_in.bodega_id,
        codigo_posicion=inventario_in.codigo_posicion,
        cantidad_actual=inventario_in.cantidad_actual,
        cantidad_maxima=inventario_in.cantidad_maxima
    )
    
    try:
        db.add(db_inventario)
        db.commit()
        db.refresh(db_inventario)
        return db_inventario
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Error de integridad al crear el inventario"
        )

@router.put("/{inv_id}", response_model=InventarioBase)
def update_inventario(
    *,
    db: Session = Depends(get_db),
    inv_id: int,
    inventario_in: InventarioUpdate,
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Actualizar un registro de inventario.
    """
    inventario = db.query(Inventario).filter(Inventario.inv_id == inv_id).first()
    if not inventario:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Inventario con ID {inv_id} no encontrado"
        )
    
    update_data = inventario_in.model_dump(exclude_unset=True)
    
    # Si se cambia el producto_id, verificar que exista
    if "producto_id" in update_data:
        producto = db.query(Producto).filter(Producto.producto_id == update_data["producto_id"]).first()
        if not producto:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Producto con ID {update_data['producto_id']} no encontrado"
            )
    
    # Si se cambia la bodega_id, verificar que exista
    if "bodega_id" in update_data:
        bodega = db.query(Bodega).filter(Bodega.bodega_id == update_data["bodega_id"]).first()
        if not bodega:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Bodega con ID {update_data['bodega_id']} no encontrada"
            )
    
    # Actualizar el inventario
    for field, value in update_data.items():
        setattr(inventario, field, value)
    
    try:
        db.add(inventario)
        db.commit()
        db.refresh(inventario)
        return inventario
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Error de integridad al actualizar el inventario"
        )

@router.delete("/{inv_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_inventario(
    *,
    db: Session = Depends(get_db),
    inv_id: int,
    current_user: Usuario = Depends(get_current_user)
):
    """
    Eliminar un registro de inventario.
    """
    inventario = db.query(Inventario).filter(Inventario.inv_id == inv_id).first()
    if not inventario:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Inventario con ID {inv_id} no encontrado"
        )
    
    # Verificar si hay movimientos asociados a este inventario
    movimiento_count = db.query(Movimiento).filter(Movimiento.inv_id == inv_id).count()
    if movimiento_count > 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"No se puede eliminar el inventario porque tiene {movimiento_count} movimientos asociados"
        )
    
    try:
        db.delete(inventario)
        db.commit()
        return Response(status_code=status.HTTP_204_NO_CONTENT)
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Error al eliminar el inventario: {str(e)}"
        )

@router.get("/por-producto/{producto_id}", response_model=List[InventarioBase])
def get_inventario_por_producto(
    *,
    db: Session = Depends(get_db),
    producto_id: int,
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Obtener todos los registros de inventario para un producto específico.
    """
    inventarios = db.query(Inventario).filter(Inventario.producto_id == producto_id).all()
    return inventarios

@router.get("/por-bodega/{bodega_id}", response_model=InventarioBodegaList)
def get_inventario_por_bodega(
    *,
    db: Session = Depends(get_db),
    bodega_id: int,
    skip: int = 0,
    limit: int = 100,
    incluir_bodegas_hijas: bool = False,
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Obtener todos los registros de inventario para una bodega específica.
    Opcionalmente incluye inventarios en bodegas hijas.
    """
    # Obtener todas las bodegas hijas si se solicita
    bodega_ids = [bodega_id]
    if incluir_bodegas_hijas:
        # Función recursiva para obtener todas las bodegas hijas
        def get_sub_bodegas(parent_id, ids_list):
            sub_bodegas = db.query(Bodega.bodega_id).filter(Bodega.parent_bodega_id == parent_id).all()
            for sub in sub_bodegas:
                sub_id = sub.bodega_id
                ids_list.append(sub_id)
                get_sub_bodegas(sub_id, ids_list)
        
        get_sub_bodegas(bodega_id, bodega_ids)
    
    # Consulta de inventario incluyendo producto y bodega
    query = (
        db.query(Inventario)
        .join(Producto, Inventario.producto_id == Producto.producto_id)
        .join(Bodega, Inventario.bodega_id == Bodega.bodega_id)
        .filter(Inventario.bodega_id.in_(bodega_ids))
        .options(
            joinedload(Inventario.producto),
            joinedload(Inventario.bodega)
        )
    )
    
    total = query.count()
    
    # Aplicar paginación
    inventarios = query.offset(skip).limit(limit).all()
    
    # Construir la respuesta
    result_items = []
    for inv in inventarios:
        item = {
            "inv_id": inv.inv_id,
            "codigo_posicion": inv.codigo_posicion,
            "cantidad_actual": inv.cantidad_actual,
            "cantidad_maxima": inv.cantidad_maxima,
            "producto": {
                "producto_id": inv.producto.producto_id,
                "sku": inv.producto.sku,
                "nombre": inv.producto.nombre,
                "descripcion": inv.producto.descripcion,
                "unidad_medida": inv.producto.unidad_medida,
                "categoria_id": inv.producto.categoria_id
            },
            "bodega": {
                "bodega_id": inv.bodega.bodega_id,
                "nombre": inv.bodega.nombre,
                "direccion": inv.bodega.direccion,
                "tipo": inv.bodega.tipo
            }
        }
        result_items.append(item)
    
    return {
        "items": result_items,
        "total": total
    }

@router.put("/{inv_id}/ajustar-cantidad", response_model=InventarioBase)
def ajustar_cantidad(
    *,
    db: Session = Depends(get_db),
    inv_id: int,
    cantidad: int = Query(..., description="Cantidad a ajustar (positivo para aumentar, negativo para disminuir)"),
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Ajustar la cantidad de un inventario y registrar el movimiento.
    """
    inventario = db.query(Inventario).filter(Inventario.inv_id == inv_id).first()
    if not inventario:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Inventario con ID {inv_id} no encontrado"
        )
    
    # Determinar tipo de movimiento
    tipo_mov = "ENTRADA" if cantidad > 0 else "SALIDA"
    
    # Verificar que hay suficiente stock para salidas
    if tipo_mov == "SALIDA" and abs(cantidad) > inventario.cantidad_actual:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Stock insuficiente. Cantidad actual: {inventario.cantidad_actual}, Cantidad solicitada: {abs(cantidad)}"
        )
    
    # Actualizar cantidad
    nueva_cantidad = inventario.cantidad_actual + cantidad
    inventario.cantidad_actual = nueva_cantidad
    
    # Registrar movimiento
    movimiento = Movimiento(
        inv_id=inv_id,
        empleado_id=current_user.empleado_id if hasattr(current_user, 'empleado_id') else None,
        tipo_mov=tipo_mov,
        cantidad=abs(cantidad),
        referencia=f"Ajuste manual por usuario {current_user.usuario_id}"
    )
    
    try:
        db.add(inventario)
        db.add(movimiento)
        db.commit()
        db.refresh(inventario)
        return inventario
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Error al ajustar el inventario: {str(e)}"
        ) 