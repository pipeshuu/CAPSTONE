from typing import Any, List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, Path
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from ....database import get_db
from ....models.models import Empleado
from ....models.auth import Usuario
from ....schemas.empleado import Empleado as EmpleadoSchema, EmpleadoCreate, EmpleadoUpdate, EmpleadoList, EmpleadoWithUsuario
from ....api.v1.endpoints.auth import get_current_user

router = APIRouter()

@router.get("/", response_model=EmpleadoList)
def get_empleados(
    db: Session = Depends(get_db),
    skip: int = 0,
    limit: int = 100,
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Obtiene todos los empleados.
    """
    empleados = db.query(Empleado).offset(skip).limit(limit).all()
    total = db.query(Empleado).count()
    return {"items": empleados, "total": total}

@router.post("/", response_model=EmpleadoSchema)
def create_empleado(
    *,
    db: Session = Depends(get_db),
    empleado_in: EmpleadoCreate,
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Crea un nuevo empleado.
    """
    try:
        empleado = Empleado(
            nombre=empleado_in.nombre,
            apellidos=empleado_in.apellidos,
            cargo=empleado_in.cargo,
            usuario_sistema=empleado_in.usuario_sistema,
            bodega_id=empleado_in.bodega_id
        )
        db.add(empleado)
        db.commit()
        db.refresh(empleado)
        return empleado
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=400,
            detail="El usuario_sistema ya existe o la bodega no existe"
        )

@router.get("/{empleado_id}", response_model=EmpleadoWithUsuario)
def get_empleado(
    *,
    db: Session = Depends(get_db),
    empleado_id: int = Path(...),
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Obtiene un empleado por ID.
    """
    empleado = db.query(Empleado).filter(Empleado.empleado_id == empleado_id).first()
    if not empleado:
        raise HTTPException(status_code=404, detail="Empleado no encontrado")
    return empleado

@router.put("/{empleado_id}", response_model=EmpleadoSchema)
def update_empleado(
    *,
    db: Session = Depends(get_db),
    empleado_id: int = Path(...),
    empleado_in: EmpleadoUpdate,
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Actualiza un empleado.
    """
    empleado = db.query(Empleado).filter(Empleado.empleado_id == empleado_id).first()
    if not empleado:
        raise HTTPException(status_code=404, detail="Empleado no encontrado")
    
    update_data = empleado_in.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(empleado, field, value)
    
    try:
        db.add(empleado)
        db.commit()
        db.refresh(empleado)
        return empleado
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=400,
            detail="Error de integridad de datos"
        )

@router.delete("/{empleado_id}", response_model=EmpleadoSchema)
def delete_empleado(
    *,
    db: Session = Depends(get_db),
    empleado_id: int = Path(...),
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Elimina un empleado.
    """
    empleado = db.query(Empleado).filter(Empleado.empleado_id == empleado_id).first()
    if not empleado:
        raise HTTPException(status_code=404, detail="Empleado no encontrado")
    
    db.delete(empleado)
    db.commit()
    return empleado

@router.post("/{empleado_id}/assign-user/{usuario_id}", response_model=EmpleadoWithUsuario)
def assign_usuario_to_empleado(
    *,
    db: Session = Depends(get_db),
    empleado_id: int = Path(...),
    usuario_id: str = Path(...),
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Asigna un usuario a un empleado.
    """
    # Verificar si el empleado existe
    empleado = db.query(Empleado).filter(Empleado.empleado_id == empleado_id).first()
    if not empleado:
        raise HTTPException(status_code=404, detail="Empleado no encontrado")
    
    # Verificar si el usuario existe
    usuario = db.query(Usuario).filter(Usuario.usuario_id == usuario_id).first()
    if not usuario:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")
    
    # Verificar si el usuario ya está asignado a otro empleado
    empleado_existente = db.query(Empleado).filter(Empleado.usuario_id == usuario_id).first()
    if empleado_existente and empleado_existente.empleado_id != empleado_id:
        raise HTTPException(
            status_code=400,
            detail="Este usuario ya está asignado a otro empleado"
        )
    
    try:
        # Asignar el usuario al empleado
        empleado.usuario_id = usuario_id
        db.add(empleado)
        db.commit()
        db.refresh(empleado)
        return empleado
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=400,
            detail="Error de integridad de datos"
        )

@router.post("/users/{usuario_id}/convert-to-empleado", response_model=EmpleadoWithUsuario)
def convert_usuario_to_empleado(
    *,
    db: Session = Depends(get_db),
    usuario_id: str = Path(...),
    empleado_in: EmpleadoCreate,
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Convierte un usuario en empleado.
    """
    # Verificar si el usuario existe
    usuario = db.query(Usuario).filter(Usuario.usuario_id == usuario_id).first()
    if not usuario:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")
    
    # Verificar si el usuario ya está asignado a un empleado
    empleado_existente = db.query(Empleado).filter(Empleado.usuario_id == usuario_id).first()
    if empleado_existente:
        raise HTTPException(
            status_code=400,
            detail="Este usuario ya es un empleado"
        )
    
    try:
        # Crear un nuevo empleado con los datos del usuario
        empleado = Empleado(
            nombre=empleado_in.nombre or usuario.nombre,
            apellidos=empleado_in.apellidos or usuario.apellidos,
            cargo=empleado_in.cargo,
            usuario_sistema=empleado_in.usuario_sistema,
            bodega_id=empleado_in.bodega_id,
            usuario_id=usuario_id
        )
        db.add(empleado)
        db.commit()
        db.refresh(empleado)
        return empleado
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=400,
            detail="Error de integridad de datos"
        ) 