from fastapi import APIRouter, Depends, HTTPException, Path, Body
from sqlalchemy.orm import Session
from typing import List
from .... import models, schemas
from ....database import get_db
from ....models.auth import Usuario
from .auth import get_current_user

router = APIRouter()

@router.post("/", response_model=schemas.Categoria,
         summary="Crear una nueva categoría",
         description="Crea una nueva categoría de productos. El nombre debe tener al menos 3 caracteres.")
def create_categoria(
    categoria: schemas.CategoriaCreate = Body(..., description="Datos de la nueva categoría"), 
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
):
    try:
        db_categoria = models.Categoria(**categoria.model_dump())
        db.add(db_categoria)
        db.commit()
        db.refresh(db_categoria)
        return db_categoria
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/", response_model=List[schemas.Categoria],
         summary="Listar todas las categorías",
         description="Obtiene una lista de todas las categorías. Soporta paginación mediante parámetros skip y limit.")
def read_categorias(
    skip: int = 0, 
    limit: int = 100, 
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
):
    try:
        categorias = db.query(models.Categoria).offset(skip).limit(limit).all()
        return categorias
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/{categoria_id}", response_model=schemas.Categoria,
         summary="Obtener una categoría específica",
         description="Recupera la información de una categoría por su ID.")
def read_categoria(
    categoria_id: int = Path(..., description="ID de la categoría"),
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
):
    try:
        db_categoria = db.query(models.Categoria).filter(models.Categoria.categoria_id == categoria_id).first()
        if db_categoria is None:
            raise HTTPException(status_code=404, detail="Categoria no encontrada")
        return db_categoria
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.put("/{categoria_id}", response_model=schemas.Categoria,
         summary="Actualizar una categoría",
         description="Actualiza la información de una categoría existente.")
def update_categoria(
    categoria_id: int = Path(..., description="ID de la categoría"),
    categoria: schemas.CategoriaCreate = Body(..., description="Datos actualizados de la categoría"),
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
):
    try:
        db_categoria = db.query(models.Categoria).filter(models.Categoria.categoria_id == categoria_id).first()
        if db_categoria is None:
            raise HTTPException(status_code=404, detail="Categoria no encontrada")
        
        for key, value in categoria.model_dump().items():
            setattr(db_categoria, key, value)
        
        db.commit()
        db.refresh(db_categoria)
        return db_categoria
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@router.delete("/{categoria_id}",
              summary="Eliminar una categoría",
              description="Elimina una categoría existente. No es posible eliminar categorías que tengan productos asociados.")
def delete_categoria(
    categoria_id: int = Path(..., description="ID de la categoría"),
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
):
    try:
        # Verificar si la categoría existe
        db_categoria = db.query(models.Categoria).filter(models.Categoria.categoria_id == categoria_id).first()
        if db_categoria is None:
            raise HTTPException(status_code=404, detail="Categoria no encontrada")
        
        # Verificar si la categoría está siendo usada en productos
        productos = db.query(models.Producto).filter(models.Producto.categoria_id == categoria_id).all()
        if productos:
            # Opción 1: Rechazar la eliminación
            raise HTTPException(
                status_code=400, 
                detail=f"No se puede eliminar la categoría porque está en uso en {len(productos)} productos"
            )
            
            # Opción 2: Si prefieres eliminar las referencias en cascada, descomenta estas líneas
            # for producto in productos:
            #     db.delete(producto)
        
        # Si no hay referencias o se han eliminado, eliminar la categoría
        db.delete(db_categoria)
        db.commit()
        return {"message": "Categoria eliminada exitosamente"}
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e)) 