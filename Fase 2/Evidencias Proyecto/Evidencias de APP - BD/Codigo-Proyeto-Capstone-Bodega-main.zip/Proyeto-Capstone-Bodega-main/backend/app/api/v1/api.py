from fastapi import APIRouter
from .endpoints import productos, categoria, inventario, bodega, empleado

api_router = APIRouter()
api_router.include_router(productos.router, prefix="/productos", tags=["productos"])
api_router.include_router(categoria.router, prefix="/categorias", tags=["categorias"])
api_router.include_router(inventario.router, prefix="/inventario", tags=["inventario"])
api_router.include_router(bodega.router, prefix="/bodegas", tags=["bodegas"])
api_router.include_router(empleado.router, prefix="/empleados", tags=["empleados"]) 