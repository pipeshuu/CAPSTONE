from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from ....database import get_db
from ....models.models import Bodega
from ....schemas.bodega import BodegaCreate, Bodega as BodegaSchema
from ....models.auth import Usuario
from .auth import get_current_user

router = APIRouter()

@router.post("/", response_model=BodegaSchema, status_code=status.HTTP_201_CREATED)
def create_bodega(
    bodega: BodegaCreate, 
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
):
    """
    Crear una nueva bodega
    """
    db_bodega = Bodega(
        nombre=bodega.nombre,
        direccion=bodega.direccion,
        tipo=bodega.tipo,
        parent_bodega_id=bodega.parent_bodega_id
    )
    db.add(db_bodega)
    db.commit()
    db.refresh(db_bodega)
    return db_bodega

@router.get("/", response_model=List[BodegaSchema])
def read_bodegas(
    skip: int = 0, 
    limit: int = 100, 
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
):
    """
    Obtener lista de bodegas
    """
    bodegas = db.query(Bodega).offset(skip).limit(limit).all()
    return bodegas

@router.get("/{bodega_id}", response_model=BodegaSchema)
def read_bodega(
    bodega_id: int, 
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
):
    """
    Obtener una bodega específica por ID
    """
    db_bodega = db.query(Bodega).filter(Bodega.bodega_id == bodega_id).first()
    if db_bodega is None:
        raise HTTPException(status_code=404, detail="Bodega no encontrada")
    return db_bodega

@router.put("/{bodega_id}", response_model=BodegaSchema)
def update_bodega(
    bodega_id: int, 
    bodega: BodegaCreate, 
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
):
    """
    Actualizar una bodega
    """
    db_bodega = db.query(Bodega).filter(Bodega.bodega_id == bodega_id).first()
    if db_bodega is None:
        raise HTTPException(status_code=404, detail="Bodega no encontrada")
    
    # Actualizar campos
    for key, value in bodega.model_dump().items():
        setattr(db_bodega, key, value)
    
    db.commit()
    db.refresh(db_bodega)
    return db_bodega

@router.delete("/{bodega_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_bodega(
    bodega_id: int, 
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
):
    """
    Eliminar una bodega
    """
    db_bodega = db.query(Bodega).filter(Bodega.bodega_id == bodega_id).first()
    if db_bodega is None:
        raise HTTPException(status_code=404, detail="Bodega no encontrada")
    
    db.delete(db_bodega)
    db.commit()
    return None

@router.get("/parent/{parent_id}", response_model=List[BodegaSchema])
def read_sub_bodegas(
    parent_id: int, 
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
):
    """
    Obtener todas las sub-bodegas (bodegas hijas) de una bodega específica
    """
    bodegas = db.query(Bodega).filter(Bodega.parent_bodega_id == parent_id).all()
    return bodegas 