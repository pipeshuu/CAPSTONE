from faker import Faker
from sqlalchemy.orm import Session
from app.models.models import (
    Proveedor, Producto, Bodega, Ubicacion, 
    Empleado, OrdenCompra, DetalleOC, Inventario, Movimiento
)
from app.database import SessionLocal

fake = Faker('es_ES')

def seed_data():
    db = SessionLocal()
    try:
        # Crear proveedores
        proveedores = []
        for _ in range(5):
            proveedor = Proveedor(
                nombre=fake.company(),
                ruc=fake.unique.random_number(digits=11, fix_len=True),
                direccion=fake.address(),
                contacto=fake.name(),
                telefono=fake.phone_number()
            )
            db.add(proveedor)
            proveedores.append(proveedor)
        db.commit()

        # Crear productos
        productos = []
        for _ in range(10):
            producto = Producto(
                sku=fake.unique.random_number(digits=8, fix_len=True),
                nombre=fake.word(),
                descripcion=fake.sentence(),
                unidad_medida=fake.random_element(elements=('unidad', 'kg', 'litro', 'metro')),
                peso=fake.random_number(digits=2) / 10
            )
            db.add(producto)
            productos.append(producto)
        db.commit()

        # Crear bodegas
        bodegas = []
        for _ in range(3):
            bodega = Bodega(
                nombre=fake.company(),
                direccion=fake.address(),
                tipo=fake.random_element(elements=('principal', 'secundaria', 'temporal'))
            )
            db.add(bodega)
            bodegas.append(bodega)
        db.commit()

        # Crear ubicaciones
        ubicaciones = []
        for bodega in bodegas:
            for _ in range(5):
                ubicacion = Ubicacion(
                    bodega_id=bodega.bodega_id,
                    codigo=fake.unique.random_number(digits=4, fix_len=True),
                    descripcion=fake.sentence(),
                    capacidad_max=fake.random_number(digits=3)
                )
                db.add(ubicacion)
                ubicaciones.append(ubicacion)
        db.commit()

        # Crear empleados
        empleados = []
        for bodega in bodegas:
            for _ in range(3):
                empleado = Empleado(
                    nombre=fake.first_name(),
                    apellidos=fake.last_name(),
                    cargo=fake.job(),
                    usuario_sistema=fake.unique.user_name(),
                    bodega_id=bodega.bodega_id
                )
                db.add(empleado)
                empleados.append(empleado)
        db.commit()

        # Crear órdenes de compra
        ordenes_compra = []
        for proveedor in proveedores:
            for _ in range(2):
                orden = OrdenCompra(
                    proveedor_id=proveedor.proveedor_id,
                    estado=fake.random_element(elements=('pendiente', 'completada', 'cancelada'))
                )
                db.add(orden)
                ordenes_compra.append(orden)
        db.commit()

        # Crear detalles de órdenes de compra
        for orden in ordenes_compra:
            for _ in range(3):
                producto = fake.random_element(elements=productos)
                detalle = DetalleOC(
                    oc_id=orden.oc_id,
                    producto_id=producto.producto_id,
                    cantidad=fake.random_number(digits=2),
                    precio_unitario=fake.random_number(digits=3) / 100
                )
                db.add(detalle)
        db.commit()

        # Crear inventarios
        for producto in productos:
            for ubicacion in ubicaciones:
                inventario = Inventario(
                    producto_id=producto.producto_id,
                    ubicacion_id=ubicacion.ubicacion_id,
                    cantidad_actual=fake.random_number(digits=2)
                )
                db.add(inventario)
        db.commit()

        # Crear movimientos
        for inventario in db.query(Inventario).all():
            for _ in range(2):
                empleado = fake.random_element(elements=empleados)
                movimiento = Movimiento(
                    inv_id=inventario.inv_id,
                    empleado_id=empleado.empleado_id,
                    tipo_mov=fake.random_element(elements=('entrada', 'salida')),
                    cantidad=fake.random_number(digits=2),
                    referencia=fake.sentence()
                )
                db.add(movimiento)
        db.commit()

        print("Datos de prueba creados exitosamente!")
    except Exception as e:
        print(f"Error al crear datos de prueba: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    seed_data() 