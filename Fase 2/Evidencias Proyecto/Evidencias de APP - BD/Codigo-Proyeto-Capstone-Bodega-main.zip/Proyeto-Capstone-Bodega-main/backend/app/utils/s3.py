import boto3
import logging
from botocore.exceptions import NoCredentialsError, ClientError
from ..core.config import settings
import uuid
from typing import Optional
from fastapi import UploadFile

# Configurar logging
logger = logging.getLogger(__name__)

def get_s3_client():
    """
    Crea y devuelve un cliente de S3.
    """
    return boto3.client(
        's3',
        aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
        aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
        region_name=settings.AWS_REGION
    )

async def upload_file_to_s3(file: UploadFile, folder: str = "productos") -> Optional[str]:
    """
    Sube un archivo a S3 y devuelve la URL.
    
    Args:
        file: El archivo a subir
        folder: La carpeta en el bucket de S3 (por defecto: "productos")
        
    Returns:
        La URL del archivo subido o None si falla
    """
    try:
        # Generar un nombre único para el archivo
        file_extension = file.filename.split(".")[-1] if "." in file.filename else ""
        unique_filename = f"{folder}/{uuid.uuid4()}.{file_extension}"
        
        # Leer el contenido del archivo
        contents = await file.read()
        
        # Subir a S3
        s3_client = get_s3_client()
        s3_client.put_object(
            Bucket=settings.S3_BUCKET_NAME,
            Key=unique_filename,
            Body=contents,
            ContentType=file.content_type
        )
        
        # Generar la URL
        url = f"https://{settings.S3_BUCKET_NAME}.s3.{settings.AWS_REGION}.amazonaws.com/{unique_filename}"
        
        # Devolver el archivo al inicio para posibles lecturas posteriores
        await file.seek(0)
        
        return url
    
    except NoCredentialsError:
        logger.error("Credenciales no disponibles")
        return None
    except ClientError as e:
        logger.error(f"Error de AWS: {str(e)}")
        return None
    except Exception as e:
        logger.error(f"Error al subir archivo: {str(e)}")
        return None

async def delete_file_from_s3(file_url: str) -> bool:
    """
    Elimina un archivo de S3 a partir de su URL.
    
    Args:
        file_url: La URL del archivo a eliminar
        
    Returns:
        True si se eliminó correctamente, False en caso contrario
    """
    try:
        # Extraer la clave del archivo de la URL
        key = file_url.split(f"{settings.S3_BUCKET_NAME}.s3.{settings.AWS_REGION}.amazonaws.com/")[1]
        
        # Eliminar de S3
        s3_client = get_s3_client()
        s3_client.delete_object(
            Bucket=settings.S3_BUCKET_NAME,
            Key=key
        )
        
        return True
    
    except NoCredentialsError:
        logger.error("Credenciales no disponibles")
        return False
    except ClientError as e:
        logger.error(f"Error de AWS: {str(e)}")
        return False
    except Exception as e:
        logger.error(f"Error al eliminar archivo: {str(e)}")
        return False 