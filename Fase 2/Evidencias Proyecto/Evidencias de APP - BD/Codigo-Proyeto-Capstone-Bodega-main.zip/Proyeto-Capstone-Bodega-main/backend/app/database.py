from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy import text
import logging

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

SQLALCHEMY_DATABASE_URL = "postgresql://postgres:postgres@db:5432/bodega_db"

engine = create_engine(SQLALCHEMY_DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def init_db():
    try:
        # Crear todas las tablas
        Base.metadata.create_all(bind=engine)
        logger.info("Tablas creadas exitosamente")
        
        # Verificar y agregar columna categoria_id si no existe
        with engine.connect() as conn:
            # Verificar si la columna categoria_id existe
            result = conn.execute(text("""
                SELECT column_name 
                FROM information_schema.columns 
                WHERE table_name = 'producto' 
                AND column_name = 'categoria_id'
            """))
            
            if not result.fetchone():
                logger.info("Agregando columna categoria_id a la tabla producto")
                # Agregar la columna si no existe
                conn.execute(text("""
                    ALTER TABLE producto 
                    ADD COLUMN categoria_id BIGINT,
                    ADD CONSTRAINT producto_categoria_id_foreign 
                    FOREIGN KEY (categoria_id) REFERENCES categoria(categoria_id)
                """))
                conn.commit()
                logger.info("Columna categoria_id agregada exitosamente")
            else:
                logger.info("La columna categoria_id ya existe")
                
            # Verificar si la columna imagen_url existe
            result = conn.execute(text("""
                SELECT column_name 
                FROM information_schema.columns 
                WHERE table_name = 'producto' 
                AND column_name = 'imagen_url'
            """))
            
            if not result.fetchone():
                # Agregar la columna si no existe
                conn.execute(text("""
                    ALTER TABLE producto 
                    ADD COLUMN imagen_url VARCHAR(255)
                """))
                conn.commit()
                logger.info("Columna imagen_url agregada exitosamente")
            
            # Modificar la foreign key de movimiento para permitir el cascade delete
            try:
                # Primero eliminamos la constraint existente
                conn.execute(text("""
                    ALTER TABLE movimiento DROP CONSTRAINT IF EXISTS movimiento_inv_id_foreign
                """))
                # Luego creamos la nueva con ON DELETE CASCADE
                conn.execute(text("""
                    ALTER TABLE movimiento ADD CONSTRAINT movimiento_inv_id_foreign 
                    FOREIGN KEY (inv_id) REFERENCES inventario(inv_id) ON DELETE CASCADE
                """))
                conn.commit()
                logger.info("Foreign key para movimiento actualizada con ON DELETE CASCADE")
            except Exception as e:
                logger.error(f"Error al actualizar la constraint de movimiento: {str(e)}")
                
    except Exception as e:
        logger.error(f"Error al inicializar la base de datos: {str(e)}")
        raise 