from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .models.models import Base
from .database import engine, init_db
from .api.v1.api import api_router
from .api.v1.endpoints import auth
from .core.config import settings
from fastapi.openapi.utils import get_openapi

app = FastAPI(
    title=settings.PROJECT_NAME,
    description="API para el sistema de bodega",
    version="1.0.0"
)

# Personalizar la documentación OpenAPI para mejorar la visualización de form-data
def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    
    openapi_schema = get_openapi(
        title=app.title,
        version=app.version,
        description=app.description,
        routes=app.routes,
    )
    
    # Personalización adicional del esquema si es necesario
    # ...
    
    app.openapi_schema = openapi_schema
    return app.openapi_schema

app.openapi = custom_openapi

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.BACKEND_CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Inicializar la base de datos
init_db()

# Incluir los routers
app.include_router(auth.router, prefix=f"{settings.API_V1_STR}/auth", tags=["auth"])
app.include_router(api_router, prefix=settings.API_V1_STR)

@app.get("/")
async def root():
    return {"message": "¡Bienvenido a la API de Bodega!"}

@app.get("/hello/{name}")
async def say_hello(name: str):
    return {"message": f"¡Hola {name}!"} 