from pydantic_settings import BaseSettings
from typing import List
import os
from dotenv import load_dotenv

load_dotenv()

class Settings(BaseSettings):
    # Configuración de la API
    API_V1_STR: str = "/api/v1"
    PROJECT_NAME: str = "Bodega API"
    
    # Configuración de CORS
    BACKEND_CORS_ORIGINS: List[str] = ["*"]
    
    # Configuración de seguridad
    SECRET_KEY: str = os.getenv("SECRET_KEY", "your-secret-key")
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1000
    
    # Configuración de S3
    AWS_ACCESS_KEY_ID: str = os.getenv("AWS_ACCESS_KEY_ID", "AKIASJFAPUGBVLS3YWMS")
    AWS_SECRET_ACCESS_KEY: str = os.getenv("AWS_SECRET_ACCESS_KEY", "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")
    AWS_REGION: str = os.getenv("AWS_REGION", "us-east-1")
    S3_BUCKET_NAME: str = os.getenv("S3_BUCKET_NAME", "proyecto-capstone-2025")
    
    # Configuración de la base de datos
    DATABASE_URL: str = "postgresql://postgres:postgres@db:5432/bodega_db"
    
    class Config:
        env_file = ".env"

settings = Settings() 