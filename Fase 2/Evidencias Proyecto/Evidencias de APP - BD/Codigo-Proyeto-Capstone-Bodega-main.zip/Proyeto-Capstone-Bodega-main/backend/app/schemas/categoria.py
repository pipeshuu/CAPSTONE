from pydantic import BaseModel, Field, validator
from typing import Optional
import re

class CategoriaBase(BaseModel):
    nombre: str = Field(..., min_length=1, strip_whitespace=True)
    descripcion: str = Field(..., min_length=1, strip_whitespace=True)

    @validator('nombre', 'descripcion')
    def validate_not_empty(cls, v):
        if not v or not v.strip():
            raise ValueError('El campo no puede estar vacío')
        return v.strip()

    @validator('nombre')
    def validate_nombre_length(cls, v):
        if len(v) < 3:
            raise ValueError('El nombre debe tener al menos 3 caracteres')
        return v

class CategoriaCreate(CategoriaBase):
    pass

class Categoria(CategoriaBase):
    categoria_id: int

    class Config:
        from_attributes = True 