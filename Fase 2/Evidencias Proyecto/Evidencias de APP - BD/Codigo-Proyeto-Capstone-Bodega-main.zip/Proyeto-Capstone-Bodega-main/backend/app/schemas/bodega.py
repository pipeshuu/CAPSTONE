from pydantic import BaseModel
from typing import Optional

class BodegaBase(BaseModel):
    nombre: str
    direccion: Optional[str] = None
    tipo: str
    parent_bodega_id: Optional[int] = None

class BodegaCreate(BodegaBase):
    pass

class Bodega(BodegaBase):
    bodega_id: int

    class Config:
        from_attributes = True 