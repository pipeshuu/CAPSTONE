from pydantic import BaseModel
from typing import Optional

class SolicitudBase(BaseModel):
    bodega_id: int
    estado: str

class SolicitudCreate(SolicitudBase):
    pass

class Solicitud(SolicitudBase):
    solicitud_id: int

    class Config:
        from_attributes = True 