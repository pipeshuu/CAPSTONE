from pydantic import BaseModel
from typing import Optional, List
from .auth import Usuario

class EmpleadoBase(BaseModel):
    nombre: str
    apellidos: str
    cargo: str
    usuario_sistema: str
    bodega_id: int

class EmpleadoCreate(EmpleadoBase):
    pass

class EmpleadoUpdate(BaseModel):
    nombre: Optional[str] = None
    apellidos: Optional[str] = None
    cargo: Optional[str] = None
    usuario_sistema: Optional[str] = None
    bodega_id: Optional[int] = None
    usuario_id: Optional[str] = None

class EmpleadoInDB(EmpleadoBase):
    empleado_id: int
    usuario_id: Optional[str] = None
    
    class Config:
        from_attributes = True

class Empleado(EmpleadoInDB):
    pass

class EmpleadoWithUsuario(Empleado):
    usuario: Optional[Usuario] = None

class EmpleadoList(BaseModel):
    items: List[Empleado]
    total: int 