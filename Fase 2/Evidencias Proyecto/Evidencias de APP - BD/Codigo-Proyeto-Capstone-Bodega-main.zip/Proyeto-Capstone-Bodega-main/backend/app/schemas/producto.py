from pydantic import BaseModel
from typing import Optional, List, ForwardRef
from pydantic.fields import Field

class ProductoBase(BaseModel):
    sku: str
    nombre: str
    descripcion: Optional[str] = None
    unidad_medida: Optional[str] = None
    peso: Optional[float] = None
    categoria_id: int
    imagen_url: Optional[str] = None
    precio: Optional[float] = None

class ProductoCreate(ProductoBase):
    pass

# Referencia adelantada para Categoria
CategoriaRef = ForwardRef('Categoria')

class Producto(ProductoBase):
    producto_id: int
    categoria: CategoriaRef

    class Config:
        from_attributes = True

# Diccionario para usar con Form data
class ProductoForm:
    def __init__(
        self,
        sku: str,
        nombre: str,
        descripcion: Optional[str] = None,
        unidad_medida: Optional[str] = None,
        peso: Optional[float] = None,
        categoria_id: int = None,
        imagen_url: Optional[str] = None,
        precio: Optional[float] = None
    ):
        self.sku = sku
        self.nombre = nombre
        self.descripcion = descripcion
        self.unidad_medida = unidad_medida
        self.peso = peso if peso is not None else 0.0
        self.categoria_id = categoria_id
        self.imagen_url = imagen_url
        self.precio = precio

    def to_dict(self):
        return {
            "sku": self.sku,
            "nombre": self.nombre,
            "descripcion": self.descripcion,
            "unidad_medida": self.unidad_medida,
            "peso": self.peso,
            "categoria_id": self.categoria_id,
            "imagen_url": self.imagen_url,
            "precio": self.precio
        }

# Importar Categoria después de definir Producto
from .categoria import Categoria

# Actualizar las referencias adelantadas
Producto.model_rebuild() 