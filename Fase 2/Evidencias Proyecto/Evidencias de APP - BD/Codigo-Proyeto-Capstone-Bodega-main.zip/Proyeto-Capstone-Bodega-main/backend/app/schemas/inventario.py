from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime

# Schema para crear un inventario
class InventarioCreate(BaseModel):
    producto_id: int
    bodega_id: int
    codigo_posicion: str
    cantidad_actual: int
    cantidad_maxima: int

# Schema para actualizar un inventario
class InventarioUpdate(BaseModel):
    producto_id: Optional[int] = None
    bodega_id: Optional[int] = None
    codigo_posicion: Optional[str] = None
    cantidad_actual: Optional[int] = None
    cantidad_maxima: Optional[int] = None

# Schema para la respuesta de inventario
class InventarioBase(BaseModel):
    inv_id: int
    producto_id: int
    bodega_id: int
    codigo_posicion: str
    cantidad_actual: int
    cantidad_maxima: int

    class Config:
        from_attributes = True

# Schema para una respuesta con datos de producto y bodega
class InventarioDetalle(InventarioBase):
    producto: dict
    bodega: dict

# Schema para producto simplificado (usado en InventarioBodega)
class ProductoSimple(BaseModel):
    producto_id: int
    sku: str
    nombre: str
    descripcion: Optional[str] = None
    unidad_medida: Optional[str] = None
    categoria_id: Optional[int] = None

    class Config:
        from_attributes = True

# Schema para bodega simplificada (usado en InventarioBodega)
class BodegaSimple(BaseModel):
    bodega_id: int
    nombre: str
    direccion: Optional[str] = None
    tipo: str

    class Config:
        from_attributes = True

# Schema para inventario con detalles para mostrar en bodega
class InventarioBodega(BaseModel):
    inv_id: int
    codigo_posicion: str
    cantidad_actual: int
    cantidad_maxima: int
    producto: ProductoSimple
    bodega: BodegaSimple

    class Config:
        from_attributes = True

# Schema para una lista de inventarios
class InventarioList(BaseModel):
    items: List[InventarioBase]
    total: int

# Schema para una lista de inventarios de bodega con detalles
class InventarioBodegaList(BaseModel):
    items: List[InventarioBodega]
    total: int 