from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime

class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    usuario_id: Optional[str] = None

class UsuarioBase(BaseModel):
    email: EmailStr
    nombre: str
    apellidos: str

class UsuarioCreate(UsuarioBase):
    password: str

class Usuario(UsuarioBase):
    usuario_id: str
    activo: bool
    es_admin: bool

    class Config:
        from_attributes = True

class UsuarioList(BaseModel):
    items: List[Usuario]
    total: int

class UsuarioLogin(BaseModel):
    email: EmailStr
    password: str 