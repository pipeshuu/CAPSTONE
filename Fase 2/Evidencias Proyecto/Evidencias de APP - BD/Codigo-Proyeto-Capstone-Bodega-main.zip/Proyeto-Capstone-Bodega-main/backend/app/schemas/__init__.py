from .auth import *
from .producto import *
from .bodega import *
from .categoria import *
from .solicitud import *
from .inventario import * 