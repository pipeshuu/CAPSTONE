from sqlalchemy import Column, Integer, String, Float, ForeignKey, DateTime, Numeric, BigInteger, text
from sqlalchemy.orm import relationship
from ..database import Base

class Proveedor(Base):
    __tablename__ = "proveedor"

    proveedor_id = Column(BigInteger, primary_key=True, index=True)
    nombre = Column(String, nullable=False)
    ruc = Column(String(20), unique=True)
    direccion = Column(String)
    contacto = Column(String)
    telefono = Column(String(50))

class Producto(Base):
    __tablename__ = "producto"

    producto_id = Column(BigInteger, primary_key=True, index=True)
    sku = Column(String(100), unique=True, nullable=False)
    nombre = Column(String, nullable=False)
    descripcion = Column(String)
    unidad_medida = Column(String(50))
    peso = Column(Numeric(10, 2))
    categoria_id = Column(BigInteger, ForeignKey("categoria.categoria_id"), nullable=False)
    imagen_url = Column(String, nullable=True)  # URL de la imagen en S3
    precio = Column(Numeric(12, 2), nullable=True)  # Precio del producto

    inventarios = relationship("Inventario", back_populates="producto")
    categoria = relationship("Categoria", back_populates="productos")

class Bodega(Base):
    __tablename__ = "bodega"

    bodega_id = Column(BigInteger, primary_key=True, index=True)
    nombre = Column(String, nullable=False)
    direccion = Column(String)
    tipo = Column(String(20), nullable=False)
    parent_bodega_id = Column(BigInteger, ForeignKey("bodega.bodega_id"))

    empleados = relationship("Empleado", back_populates="bodega")
    bodegas_hijas = relationship("Bodega", back_populates="bodega_padre")
    bodega_padre = relationship("Bodega", remote_side=[bodega_id], back_populates="bodegas_hijas")
    solicitudes = relationship("Solicitud", back_populates="bodega")
    inventarios = relationship("Inventario", back_populates="bodega")

class Empleado(Base):
    __tablename__ = "empleado"

    empleado_id = Column(BigInteger, primary_key=True, index=True)
    nombre = Column(String, nullable=False)
    apellidos = Column(String)
    cargo = Column(String(100))
    usuario_sistema = Column(String(100), unique=True)
    bodega_id = Column(BigInteger, ForeignKey("bodega.bodega_id"), nullable=False)
    usuario_id = Column(String, ForeignKey("usuarios.usuario_id"), nullable=True, unique=True)

    bodega = relationship("Bodega", back_populates="empleados")
    movimientos = relationship("Movimiento", back_populates="empleado")
    usuario = relationship("Usuario", back_populates="empleado")

class Inventario(Base):
    __tablename__ = "inventario"

    inv_id = Column(BigInteger, primary_key=True, index=True)
    producto_id = Column(BigInteger, ForeignKey("producto.producto_id"), nullable=False)
    bodega_id = Column(BigInteger, ForeignKey("bodega.bodega_id"), nullable=False)
    codigo_posicion = Column(String(50), nullable=False)
    cantidad_actual = Column(Integer, nullable=False)
    cantidad_maxima = Column(Integer, nullable=False)

    producto = relationship("Producto", back_populates="inventarios")
    bodega = relationship("Bodega", back_populates="inventarios")
    movimientos = relationship("Movimiento", back_populates="inventario", cascade="all, delete-orphan")

class Movimiento(Base):
    __tablename__ = "movimiento"

    mov_id = Column(BigInteger, primary_key=True, index=True)
    inv_id = Column(BigInteger, ForeignKey("inventario.inv_id"), nullable=False)
    empleado_id = Column(BigInteger, ForeignKey("empleado.empleado_id"), nullable=False)
    tipo_mov = Column(String(20), nullable=False)
    cantidad = Column(Integer, nullable=False)
    fecha_hora = Column(DateTime(timezone=True), nullable=False, server_default=text("now()"))
    referencia = Column(String)

    inventario = relationship("Inventario", back_populates="movimientos")
    empleado = relationship("Empleado", back_populates="movimientos")

class Categoria(Base):
    __tablename__ = "categoria"

    categoria_id = Column(BigInteger, primary_key=True, index=True)
    nombre = Column(String(255), nullable=False)
    descripcion = Column(String(255), nullable=False)

    productos = relationship("Producto", back_populates="categoria")

class Solicitud(Base):
    __tablename__ = "solicitud"

    solicitud_id = Column(BigInteger, primary_key=True, index=True)
    bodega_id = Column(BigInteger, ForeignKey("bodega.bodega_id"), nullable=False)
    estado = Column(String(255), nullable=False)

    bodega = relationship("Bodega", back_populates="solicitudes") 