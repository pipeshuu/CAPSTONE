from sqlalchemy import Column, String, Boolean
from sqlalchemy.orm import relationship
from ..database import Base

class Usuario(Base):
    __tablename__ = "usuarios"

    usuario_id = Column(String, primary_key=True, index=True)
    email = Column(String, unique=True, index=True)
    hashed_password = Column(String)
    nombre = Column(String)
    apellidos = Column(String)
    activo = Column(Boolean, default=True)
    es_admin = Column(Boolean, default=False)
    
    empleado = relationship("Empleado", back_populates="usuario", uselist=False) 