import { Component, OnInit, signal, ViewChild } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Table, TableModule } from 'primeng/table';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { RippleModule } from 'primeng/ripple';
import { ToastModule } from 'primeng/toast';
import { ToolbarModule } from 'primeng/toolbar';
import { InputTextModule } from 'primeng/inputtext';
import { TextareaModule } from 'primeng/textarea';
import { SelectModule } from 'primeng/select';
import { RadioButtonModule } from 'primeng/radiobutton';
import { InputNumberModule } from 'primeng/inputnumber';
import { DialogModule } from 'primeng/dialog';
import { TagModule } from 'primeng/tag';
import { InputIconModule } from 'primeng/inputicon';
import { IconFieldModule } from 'primeng/iconfield';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { DropdownModule } from 'primeng/dropdown';
import { Bodega, BodegaService } from '../../services/bodega.service';

interface Column {
    field: string;
    header: string;
    customExportHeader?: string;
}

interface ExportColumn {
    title: string;
    dataKey: string;
}

@Component({
    selector: 'app-bodegas',
    standalone: true,
    imports: [
        CommonModule,
        TableModule,
        FormsModule,
        ButtonModule,
        RippleModule,
        ToastModule,
        ToolbarModule,
        InputTextModule,
        TextareaModule,
        SelectModule,
        RadioButtonModule,
        InputNumberModule,
        DialogModule,
        TagModule,
        InputIconModule,
        IconFieldModule,
        ConfirmDialogModule,
        DropdownModule
    ],
    providers: [MessageService, ConfirmationService],
    template: `
        <p-toast></p-toast>
        
        <p-toolbar styleClass="mb-6">
            <ng-template #start>
                <p-button label="Nueva" icon="pi pi-plus" severity="secondary" class="mr-2" (onClick)="openNew()" />
                <p-button severity="secondary" label="Eliminar" icon="pi pi-trash" outlined (onClick)="deleteSelectedBodegas()" [disabled]="!selectedBodegas || !selectedBodegas.length" />
            </ng-template>

            <ng-template #end>
                <p-button label="Exportar" icon="pi pi-upload" severity="secondary" (onClick)="exportCSV()" />
            </ng-template>
        </p-toolbar>

        <p-table
            #dt
            [value]="bodegas()"
            [rows]="10"
            [columns]="cols"
            [paginator]="true"
            [globalFilterFields]="['nombre', 'tipo', 'direccion']"
            [tableStyle]="{ 'min-width': '75rem' }"
            [(selection)]="selectedBodegas"
            [rowHover]="true"
            dataKey="bodega_id"
            currentPageReportTemplate="Mostrando {first} a {last} de {totalRecords} bodegas"
            [showCurrentPageReport]="true"
            [rowsPerPageOptions]="[10, 20, 30]"
            [loading]="loading"
        >
            <ng-template #caption>
                <div class="flex items-center justify-between">
                    <h5 class="m-0">Gestión de Bodegas</h5>
                    <p-iconfield>
                        <p-inputicon styleClass="pi pi-search" />
                        <input pInputText type="text" (input)="onGlobalFilter(dt, $event)" placeholder="Buscar..." />
                    </p-iconfield>
                </div>
            </ng-template>
            <ng-template #header>
                <tr>
                    <th style="width: 3rem">
                        <p-tableHeaderCheckbox />
                    </th>
                    <th pSortableColumn="bodega_id" style="min-width: 6rem">
                        ID
                        <p-sortIcon field="bodega_id" />
                    </th>
                    <th pSortableColumn="nombre" style="min-width:16rem">
                        Nombre
                        <p-sortIcon field="nombre" />
                    </th>
                    <th pSortableColumn="direccion" style="min-width: 16rem">
                        Dirección
                        <p-sortIcon field="direccion" />
                    </th>
                    <th pSortableColumn="tipo" style="min-width: 8rem">
                        Tipo
                        <p-sortIcon field="tipo" />
                    </th>
                    <th pSortableColumn="parent_bodega_id" style="min-width: 10rem">
                        Bodega Padre
                        <p-sortIcon field="parent_bodega_id" />
                    </th>
                    <th style="min-width: 10rem"></th>
                </tr>
            </ng-template>
            <ng-template #body let-bodega>
                <tr>
                    <td style="width: 3rem">
                        <p-tableCheckbox [value]="bodega" />
                    </td>
                    <td style="min-width: 6rem">{{ bodega.bodega_id }}</td>
                    <td style="min-width: 16rem">{{ bodega.nombre }}</td>
                    <td style="min-width: 16rem">{{ bodega.direccion }}</td>
                    <td style="min-width: 8rem">
                        <p-tag [value]="bodega.tipo" [severity]="getTipoSeverity(bodega.tipo)" />
                    </td>
                    <td style="min-width: 10rem">{{ getBodegaPadreNombre(bodega.parent_bodega_id) }}</td>
                    <td>
                        <p-button icon="pi pi-pencil" class="mr-2" [rounded]="true" [outlined]="true" (click)="editBodega(bodega)" />
                        <p-button icon="pi pi-trash" severity="danger" [rounded]="true" [outlined]="true" (click)="deleteBodega(bodega)" />
                    </td>
                </tr>
            </ng-template>
        </p-table>

        <p-dialog [(visible)]="bodegaDialog" [style]="{ width: '550px' }" header="Detalles de Bodega" [modal]="true">
            <ng-template #content>
                <div class="flex flex-col gap-6">
                    <div class="grid grid-cols-12 gap-4">
                        <div class="col-span-12">
                            <label for="nombre" class="block font-bold mb-3">Nombre</label>
                            <input type="text" pInputText id="nombre" [(ngModel)]="bodega.nombre" required autofocus class="w-full" />
                            <small class="text-red-500" *ngIf="submitted && !bodega.nombre">Nombre es requerido.</small>
                        </div>
                    </div>

                    <div class="grid grid-cols-12 gap-4">
                        <div class="col-span-12">
                            <label for="direccion" class="block font-bold mb-3">Dirección</label>
                            <input type="text" pInputText id="direccion" [(ngModel)]="bodega.direccion" class="w-full" />
                        </div>
                    </div>

                    <div class="grid grid-cols-12 gap-4">
                        <div class="col-span-6">
                            <label for="tipo" class="block font-bold mb-3">Tipo</label>
                            <p-dropdown [(ngModel)]="bodega.tipo" 
                                       [options]="tiposBodega" 
                                       optionLabel="label" 
                                       optionValue="value" 
                                       placeholder="Seleccione Tipo" 
                                       [style]="{'width':'100%'}" 
                                       [showClear]="false" 
                                       appendTo="body" 
                                       required>
                            </p-dropdown>
                            <small class="text-red-500" *ngIf="submitted && !bodega.tipo">Tipo es requerido.</small>
                        </div>
                    </div>

                    <div class="grid grid-cols-12 gap-4">
                        <div class="col-span-12">
                            <label for="parent_bodega_id" class="block font-bold mb-3">Bodega Padre</label>
                            <p-dropdown [(ngModel)]="bodega.parent_bodega_id" 
                                       [options]="bodegasPadre" 
                                       optionLabel="label" 
                                       optionValue="value" 
                                       placeholder="Seleccione Bodega Padre" 
                                       [style]="{'width':'100%'}" 
                                       [filter]="true" 
                                       filterBy="label" 
                                       [showClear]="true" 
                                       appendTo="body">
                            </p-dropdown>
                        </div>
                    </div>
                </div>
            </ng-template>

            <ng-template #footer>
                <p-button label="Cancelar" icon="pi pi-times" text (click)="hideDialog()" />
                <p-button label="Guardar" icon="pi pi-check" (click)="saveBodega()" />
            </ng-template>
        </p-dialog>

        <p-confirmdialog [style]="{ width: '450px' }" />
    `
})
export class Bodegas implements OnInit {
    bodegaDialog: boolean = false;

    bodegas = signal<Bodega[]>([]);
    
    bodega: Bodega = {
        nombre: '',
        tipo: 'ALMACEN',
        direccion: ''
    };

    selectedBodegas: Bodega[] | null = null;

    submitted: boolean = false;

    loading: boolean = true;
    
    tiposBodega: any[] = [];
    bodegasPadre: any[] = [];

    @ViewChild('dt') dt!: Table;

    exportColumns!: ExportColumn[];

    cols!: Column[];

    constructor(
        private bodegaService: BodegaService,
        private messageService: MessageService,
        private confirmationService: ConfirmationService
    ) {}

    exportCSV() {
        this.dt.exportCSV();
    }

    ngOnInit() {
        this.loadData();
        this.tiposBodega = this.bodegaService.getTiposBodega();

        this.cols = [
            { field: 'bodega_id', header: 'ID' },
            { field: 'nombre', header: 'Nombre' },
            { field: 'direccion', header: 'Dirección' },
            { field: 'tipo', header: 'Tipo' },
            { field: 'parent_bodega_id', header: 'Bodega Padre' }
        ];

        this.exportColumns = this.cols.map((col) => ({ title: col.header, dataKey: col.field }));
    }

    loadData() {
        this.loading = true;
        this.bodegaService.getBodegas()
            .then(data => {
                this.bodegas.set(data);
                this.updateBodegasPadre();
                this.loading = false;
            })
            .catch(error => {
                console.error('Error al cargar bodegas:', error);
                this.messageService.add({ 
                    severity: 'error', 
                    summary: 'Error', 
                    detail: 'Error al cargar bodegas', 
                    life: 3000 
                });
                this.loading = false;
            });
    }

    updateBodegasPadre() {
        // Crear lista para dropdown de bodegas padre, excluyendo la bodega actual si está en edición
        this.bodegasPadre = this.bodegas().map(b => ({
            label: b.nombre,
            value: b.bodega_id
        }));

        // Añadir opción para "Sin bodega padre"
        this.bodegasPadre.unshift({
            label: 'Ninguna (Bodega principal)',
            value: null
        });
    }

    onGlobalFilter(table: Table, event: Event) {
        table.filterGlobal((event.target as HTMLInputElement).value, 'contains');
    }

    openNew() {
        this.bodega = {
            nombre: '',
            tipo: 'CENTRAL',
            direccion: ''
        };
        this.submitted = false;
        this.bodegaDialog = true;
    }

    editBodega(bodega: Bodega) {
        this.bodega = { ...bodega };
        this.bodegaDialog = true;
    }

    deleteSelectedBodegas() {
        this.confirmationService.confirm({
            message: '¿Está seguro de eliminar las bodegas seleccionadas?',
            header: 'Confirmar',
            icon: 'pi pi-exclamation-triangle',
            accept: () => {
                if (this.selectedBodegas && this.selectedBodegas.length > 0) {
                    const deletePromises = this.selectedBodegas
                        .filter(bodega => bodega.bodega_id)
                        .map(bodega => this.bodegaService.deleteBodega(bodega.bodega_id!));
                    
                    Promise.all(deletePromises)
                        .then(() => {
                            this.loadData();
                            this.messageService.add({ 
                                severity: 'success', 
                                summary: 'Éxito', 
                                detail: 'Bodegas eliminadas correctamente', 
                                life: 3000 
                            });
                            this.selectedBodegas = null;
                        })
                        .catch(error => {
                            console.error('Error al eliminar bodegas:', error);
                            this.messageService.add({ 
                                severity: 'error', 
                                summary: 'Error', 
                                detail: 'No se pudieron eliminar todas las bodegas', 
                                life: 3000 
                            });
                        });
                }
            }
        });
    }

    hideDialog() {
        this.bodegaDialog = false;
        this.submitted = false;
    }

    deleteBodega(bodega: Bodega) {
        this.confirmationService.confirm({
            message: `¿Está seguro de eliminar la bodega "${bodega.nombre}"?`,
            header: 'Confirmar',
            icon: 'pi pi-exclamation-triangle',
            accept: () => {
                if (bodega.bodega_id) {
                    this.bodegaService.deleteBodega(bodega.bodega_id)
                        .then(() => {
                            this.loadData();
                            this.messageService.add({ 
                                severity: 'success', 
                                summary: 'Éxito', 
                                detail: 'Bodega eliminada correctamente', 
                                life: 3000 
                            });
                        })
                        .catch(error => {
                            console.error('Error al eliminar bodega:', error);
                            this.messageService.add({ 
                                severity: 'error', 
                                summary: 'Error', 
                                detail: 'No se pudo eliminar la bodega', 
                                life: 3000 
                            });
                        });
                }
            }
        });
    }

    saveBodega() {
        this.submitted = true;

        if (!this.bodega.nombre || !this.bodega.tipo) {
            return;
        }

        const saveOperation = this.bodega.bodega_id
            ? this.bodegaService.updateBodega(this.bodega)
            : this.bodegaService.createBodega(this.bodega);

        saveOperation
            .then(() => {
                this.loadData();
                this.messageService.add({ 
                    severity: 'success', 
                    summary: 'Éxito', 
                    detail: `Bodega ${this.bodega.bodega_id ? 'actualizada' : 'creada'} correctamente`, 
                    life: 3000 
                });
                this.bodegaDialog = false;
                this.bodega = {
                    nombre: '',
                    tipo: 'CENTRAL',
                    direccion: ''
                };
            })
            .catch(error => {
                console.error('Error al guardar bodega:', error);
                this.messageService.add({ 
                    severity: 'error', 
                    summary: 'Error', 
                    detail: `No se pudo ${this.bodega.bodega_id ? 'actualizar' : 'crear'} la bodega`, 
                    life: 3000 
                });
            });
    }

    getTipoSeverity(tipo: string): 'success' | 'info' | 'warn' | 'danger' | 'secondary' | 'contrast' | undefined {
        switch (tipo) {
            case 'CENTRAL':
                return 'info';
            case 'SECUNDARIA':
                return 'success';
            default:
                return 'secondary';
        }
    }

    getBodegaPadreNombre(id: number | null | undefined): string {
        if (id === null || id === undefined) {
            return 'Ninguna';
        }
        
        const bodega = this.bodegas().find(b => b.bodega_id === id);
        return bodega ? bodega.nombre : `Bodega #${id}`;
    }
} 