import { Component, OnInit, signal, ViewChild } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Table, TableModule } from 'primeng/table';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { RippleModule } from 'primeng/ripple';
import { ToastModule } from 'primeng/toast';
import { ToolbarModule } from 'primeng/toolbar';
import { InputTextModule } from 'primeng/inputtext';
import { TextareaModule } from 'primeng/textarea';
import { RadioButtonModule } from 'primeng/radiobutton';
import { InputNumberModule } from 'primeng/inputnumber';
import { DialogModule } from 'primeng/dialog';
import { TagModule } from 'primeng/tag';
import { InputIconModule } from 'primeng/inputicon';
import { IconFieldModule } from 'primeng/iconfield';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { DropdownModule } from 'primeng/dropdown';
import { SplitButtonModule } from 'primeng/splitbutton';
import { CalendarModule } from 'primeng/calendar';
import { TableModule as TableNgModule } from 'primeng/table';
import { Envio, EnvioItem, EnvioService } from '../../services/envio.service';
import { BodegaService } from '../../services/bodega.service';
import { Router } from '@angular/router';
import { ProductoService } from '../../services/producto.service';

interface Column {
    field: string;
    header: string;
    customExportHeader?: string;
}

interface ExportColumn {
    title: string;
    dataKey: string;
}

@Component({
    selector: 'app-envios',
    standalone: true,
    imports: [
        CommonModule,
        TableModule,
        FormsModule,
        ButtonModule,
        RippleModule,
        ToastModule,
        ToolbarModule,
        InputTextModule,
        TextareaModule,
        RadioButtonModule,
        InputNumberModule,
        DialogModule,
        TagModule,
        InputIconModule,
        IconFieldModule,
        ConfirmDialogModule,
        DropdownModule,
        SplitButtonModule,
        CalendarModule,
        TableNgModule
    ],
    providers: [MessageService, ConfirmationService, DatePipe],
    template: `
        <p-toast></p-toast>
        <p-confirmDialog header="Confirmación" icon="pi pi-exclamation-triangle"></p-confirmDialog>
        
        <div class="card">
            <p-toolbar styleClass="mb-4">
                <ng-template pTemplate="start">
                    <button pButton pRipple label="Nuevo" icon="pi pi-plus" class="p-button-success mr-2" (click)="openNew()"></button>
                    <button pButton pRipple label="Eliminar" icon="pi pi-trash" class="p-button-danger" (click)="deleteSelectedEnvios()" [disabled]="!selectedEnvios || !selectedEnvios.length"></button>
                </ng-template>

                <ng-template pTemplate="end">
                    <button pButton pRipple label="Exportar" icon="pi pi-upload" class="p-button-help" (click)="exportCSV()"></button>
                </ng-template>
            </p-toolbar>

            <p-table
                #dt
                [value]="envios()"
                [rows]="10"
                [paginator]="true"
                [globalFilterFields]="['envio_id', 'fecha_creacion', 'estado', 'bodega_origen_id', 'bodega_destino_id', 'codigo_seguimiento']"
                [tableStyle]="{ 'min-width': '75rem' }"
                [(selection)]="selectedEnvios"
                [rowHover]="true"
                dataKey="envio_id"
                currentPageReportTemplate="Mostrando {first} a {last} de {totalRecords} envíos"
                [showCurrentPageReport]="true"
                [rowsPerPageOptions]="[10, 20, 30]"
                [loading]="loading"
            >
                <ng-template pTemplate="caption">
                    <div class="flex flex-wrap justify-content-between align-items-center">
                        <h5 class="m-0">Gestión de Envíos</h5>
                        <span class="p-input-icon-left">
                            <i class="pi pi-search"></i>
                            <input pInputText type="text" (input)="onGlobalFilter(dt, $event)" placeholder="Buscar..." />
                        </span>
                    </div>
                </ng-template>
                <ng-template pTemplate="header">
                    <tr>
                        <th style="width: 3rem">
                            <p-tableHeaderCheckbox></p-tableHeaderCheckbox>
                        </th>
                        <th pSortableColumn="envio_id" style="min-width:5rem">ID <p-sortIcon field="envio_id"></p-sortIcon></th>
                        <th pSortableColumn="fecha_creacion" style="min-width:10rem">Fecha Creación <p-sortIcon field="fecha_creacion"></p-sortIcon></th>
                        <th pSortableColumn="fecha_envio" style="min-width:10rem">Fecha Envío <p-sortIcon field="fecha_envio"></p-sortIcon></th>
                        <th pSortableColumn="bodega_origen_id" style="min-width:12rem">Origen <p-sortIcon field="bodega_origen_id"></p-sortIcon></th>
                        <th pSortableColumn="bodega_destino_id" style="min-width:12rem">Destino <p-sortIcon field="bodega_destino_id"></p-sortIcon></th>
                        <th pSortableColumn="codigo_seguimiento" style="min-width:10rem">Código <p-sortIcon field="codigo_seguimiento"></p-sortIcon></th>
                        <th pSortableColumn="estado" style="min-width:8rem">Estado <p-sortIcon field="estado"></p-sortIcon></th>
                        <th style="min-width:10rem">Acciones</th>
                    </tr>
                </ng-template>
                <ng-template pTemplate="body" let-envio>
                    <tr>
                        <td>
                            <p-tableCheckbox [value]="envio"></p-tableCheckbox>
                        </td>
                        <td>{{ envio.envio_id }}</td>
                        <td>{{ envio.fecha_creacion | date:'dd/MM/yyyy' }}</td>
                        <td>{{ envio.fecha_envio | date:'dd/MM/yyyy' }}</td>
                        <td>{{ getBodegaNombre(envio.bodega_origen_id) }}</td>
                        <td>{{ getBodegaNombre(envio.bodega_destino_id) }}</td>
                        <td>{{ envio.codigo_seguimiento }}</td>
                        <td>
                            <p-tag [value]="getEstadoLabel(envio.estado)" [severity]="getEstadoSeverity(envio.estado)"></p-tag>
                        </td>
                        <td>
                            <div class="flex">
                                <button pButton pRipple icon="pi pi-pencil" class="p-button-rounded p-button-success mr-2" (click)="editEnvio(envio)"></button>
                                <button pButton pRipple icon="pi pi-trash" class="p-button-rounded p-button-danger mr-2" (click)="confirmDelete(envio)"></button>
                                <button pButton pRipple icon="pi pi-eye" class="p-button-rounded p-button-info" (click)="viewEnvioDetail(envio)"></button>
                            </div>
                        </td>
                    </tr>
                </ng-template>
                <ng-template pTemplate="summary">
                    <div class="flex align-items-center justify-content-between">
                        En total hay {{ envios().length || 0 }} envíos.
                    </div>
                </ng-template>
            </p-table>
        </div>

        <!-- Diálogo de Crear/Editar Envío -->
        <p-dialog [(visible)]="envioDialog" [style]="{ width: '700px' }" header="Detalles de Envío" [modal]="true" styleClass="p-fluid">
            <ng-template pTemplate="content">
                <div class="grid">
                    <div class="col-12 md:col-6">
                        <div class="field">
                            <label for="bodega_origen_id">Bodega Origen</label>
                            <p-dropdown [(ngModel)]="envio.bodega_origen_id" 
                                      [options]="bodegas" 
                                      optionLabel="label" 
                                      optionValue="value" 
                                      placeholder="Seleccione Bodega" 
                                      [filter]="true" 
                                      filterBy="label" 
                                      [showClear]="false" 
                                      appendTo="body" 
                                      required>
                            </p-dropdown>
                            <small class="p-error" *ngIf="submitted && !envio.bodega_origen_id">Bodega origen es requerida.</small>
                        </div>
                    </div>
                    <div class="col-12 md:col-6">
                        <div class="field">
                            <label for="bodega_destino_id">Bodega Destino</label>
                            <p-dropdown [(ngModel)]="envio.bodega_destino_id" 
                                      [options]="bodegas" 
                                      optionLabel="label" 
                                      optionValue="value" 
                                      placeholder="Seleccione Bodega" 
                                      [filter]="true" 
                                      filterBy="label" 
                                      [showClear]="false" 
                                      appendTo="body" 
                                      required>
                            </p-dropdown>
                            <small class="p-error" *ngIf="submitted && !envio.bodega_destino_id">Bodega destino es requerida.</small>
                        </div>
                    </div>

                    <div class="col-12 md:col-6">
                        <div class="field">
                            <label for="codigo_seguimiento">Código de Seguimiento</label>
                            <input pInputText id="codigo_seguimiento" [(ngModel)]="envio.codigo_seguimiento" required />
                            <small class="p-error" *ngIf="submitted && !envio.codigo_seguimiento">Código de seguimiento es requerido.</small>
                        </div>
                    </div>
                    <div class="col-12 md:col-6">
                        <div class="field">
                            <label for="estado">Estado</label>
                            <p-dropdown [(ngModel)]="envio.estado" 
                                      [options]="estadosEnvio" 
                                      optionLabel="label" 
                                      optionValue="value" 
                                      placeholder="Seleccione Estado" 
                                      [showClear]="false" 
                                      appendTo="body" 
                                      required>
                            </p-dropdown>
                            <small class="p-error" *ngIf="submitted && !envio.estado">Estado es requerido.</small>
                        </div>
                    </div>

                    <div class="col-12 md:col-6" *ngIf="envio.estado === 'EN_TRANSITO' || envio.estado === 'ENTREGADO'">
                        <div class="field">
                            <label for="fecha_envio">Fecha de Envío</label>
                            <p-calendar [(ngModel)]="envio.fecha_envio" 
                                      [showIcon]="true"
                                      [showButtonBar]="true"
                                      dateFormat="dd/mm/yy"
                                      appendTo="body"
                                      placeholder="Seleccione fecha">
                            </p-calendar>
                        </div>
                    </div>
                    <div class="col-12 md:col-6" *ngIf="envio.estado === 'ENTREGADO'">
                        <div class="field">
                            <label for="fecha_recepcion">Fecha de Recepción</label>
                            <p-calendar [(ngModel)]="envio.fecha_recepcion" 
                                      [showIcon]="true"
                                      [showButtonBar]="true"
                                      dateFormat="dd/mm/yy"
                                      appendTo="body"
                                      placeholder="Seleccione fecha">
                            </p-calendar>
                        </div>
                    </div>

                    <div class="col-12">
                        <div class="field">
                            <label for="notas">Notas</label>
                            <textarea pInputTextarea id="notas" [(ngModel)]="envio.notas" rows="3"></textarea>
                        </div>
                    </div>
                </div>

                <h5>Productos del Envío</h5>
                <p-table [value]="envio.items" [tableStyle]="{ 'min-width': '50rem' }">
                    <ng-template pTemplate="header">
                        <tr>
                            <th>Producto</th>
                            <th>Cantidad</th>
                            <th>Observación</th>
                            <th style="width:8rem"></th>
                        </tr>
                    </ng-template>
                    <ng-template pTemplate="body" let-item let-index="rowIndex">
                        <tr>
                            <td>
                                <p-dropdown [(ngModel)]="item.producto_id" 
                                          [options]="productos" 
                                          optionLabel="label" 
                                          optionValue="value" 
                                          placeholder="Seleccione Producto" 
                                          [filter]="true" 
                                          filterBy="label" 
                                          [showClear]="false" 
                                          appendTo="body" 
                                          required 
                                          (onChange)="onProductoChange(item)">
                                </p-dropdown>
                            </td>
                            <td>
                                <p-inputNumber [(ngModel)]="item.cantidad" 
                                            [min]="1" 
                                            [showButtons]="true" 
                                            buttonLayout="horizontal" 
                                            inputId="cantidad"
                                            spinnerMode="horizontal" 
                                            decrementButtonClass="p-button-danger" 
                                            incrementButtonClass="p-button-success"
                                            incrementButtonIcon="pi pi-plus" 
                                            decrementButtonIcon="pi pi-minus">
                                </p-inputNumber>
                            </td>
                            <td>
                                <input pInputText [(ngModel)]="item.observacion" placeholder="Observación" />
                            </td>
                            <td class="text-center">
                                <button pButton pRipple icon="pi pi-trash" class="p-button-rounded p-button-danger" (click)="removeItem(index)"></button>
                            </td>
                        </tr>
                    </ng-template>
                    <ng-template pTemplate="footer">
                        <tr>
                            <td colspan="4" class="text-right">
                                <button pButton pRipple label="Agregar Producto" icon="pi pi-plus" class="p-button-success" (click)="addNewItem()"></button>
                            </td>
                        </tr>
                    </ng-template>
                </p-table>
            </ng-template>

            <ng-template pTemplate="footer">
                <button pButton pRipple label="Cancelar" icon="pi pi-times" class="p-button-text" (click)="hideDialog()"></button>
                <button pButton pRipple label="Guardar" icon="pi pi-check" class="p-button-text" (click)="saveEnvio()"></button>
            </ng-template>
        </p-dialog>

        <!-- Diálogo de Detalle de Envío -->
        <p-dialog [(visible)]="envioViewDialog" [style]="{ width: '700px' }" header="Detalle de Envío" [modal]="true" styleClass="p-fluid">
            <ng-template pTemplate="content">
                <div *ngIf="envioView" class="grid">
                    <div class="col-12 md:col-6">
                        <div class="field">
                            <label class="font-bold">ID</label>
                            <p>{{ envioView.envio_id }}</p>
                        </div>
                    </div>
                    <div class="col-12 md:col-6">
                        <div class="field">
                            <label class="font-bold">Código de Seguimiento</label>
                            <p>{{ envioView.codigo_seguimiento }}</p>
                        </div>
                    </div>
                    <div class="col-12 md:col-6">
                        <div class="field">
                            <label class="font-bold">Fecha de Creación</label>
                            <p>{{ envioView.fecha_creacion | date:'dd/MM/yyyy' }}</p>
                        </div>
                    </div>
                    <div class="col-12 md:col-6">
                        <div class="field">
                            <label class="font-bold">Estado</label>
                            <p><p-tag [value]="getEstadoLabel(envioView.estado)" [severity]="getEstadoSeverity(envioView.estado)"></p-tag></p>
                        </div>
                    </div>
                    <div class="col-12 md:col-6">
                        <div class="field">
                            <label class="font-bold">Bodega Origen</label>
                            <p>{{ getBodegaNombre(envioView.bodega_origen_id) }}</p>
                        </div>
                    </div>
                    <div class="col-12 md:col-6">
                        <div class="field">
                            <label class="font-bold">Bodega Destino</label>
                            <p>{{ getBodegaNombre(envioView.bodega_destino_id) }}</p>
                        </div>
                    </div>

                    <div class="col-12 md:col-6" *ngIf="envioView.fecha_envio">
                        <div class="field">
                            <label class="font-bold">Fecha de Envío</label>
                            <p>{{ envioView.fecha_envio | date:'dd/MM/yyyy' }}</p>
                        </div>
                    </div>
                    <div class="col-12 md:col-6" *ngIf="envioView.fecha_recepcion">
                        <div class="field">
                            <label class="font-bold">Fecha de Recepción</label>
                            <p>{{ envioView.fecha_recepcion | date:'dd/MM/yyyy' }}</p>
                        </div>
                    </div>

                    <div class="col-12" *ngIf="envioView.notas">
                        <div class="field">
                            <label class="font-bold">Notas</label>
                            <p>{{ envioView.notas }}</p>
                        </div>
                    </div>
                    
                    <div class="col-12" *ngIf="envioView.items && envioView.items.length > 0">
                        <h5>Productos</h5>
                        <p-table [value]="envioView.items" [tableStyle]="{ 'min-width': '50rem' }">
                            <ng-template pTemplate="header">
                                <tr>
                                    <th>Producto</th>
                                    <th>Cantidad</th>
                                    <th>Observación</th>
                                </tr>
                            </ng-template>
                            <ng-template pTemplate="body" let-item>
                                <tr>
                                    <td>{{ getProductoNombre(item.producto_id) }}</td>
                                    <td>{{ item.cantidad }}</td>
                                    <td>{{ item.observacion }}</td>
                                </tr>
                            </ng-template>
                        </p-table>
                    </div>
                </div>
            </ng-template>

            <ng-template pTemplate="footer">
                <button pButton pRipple label="Cerrar" icon="pi pi-times" class="p-button-text" (click)="hideViewDialog()"></button>
            </ng-template>
        </p-dialog>
    `
})
export class Envios implements OnInit {
    envios = signal<Envio[]>([]);
    envioDialog: boolean = false;
    envioViewDialog: boolean = false;
    envio: Envio = this.getEmptyEnvio();
    envioView: Envio | null = null;
    selectedEnvios: Envio[] = [];
    submitted: boolean = false;
    loading: boolean = true;
    bodegas: any[] = [];
    productos: any[] = [];
    estadosEnvio: any[] = [];
    cols: Column[] = [];
    exportColumns: ExportColumn[] = [];

    @ViewChild('dt') table!: Table;

    constructor(
        private envioService: EnvioService,
        private bodegaService: BodegaService,
        private productoService: ProductoService,
        private messageService: MessageService,
        private confirmationService: ConfirmationService,
        private datePipe: DatePipe,
        private router: Router
    ) {}

    ngOnInit(): void {
        this.loadEnvios();
        this.loadBodegas();
        this.loadProductos();
        this.estadosEnvio = this.envioService.getEstadosEnvio();

        this.cols = [
            { field: 'envio_id', header: 'ID' },
            { field: 'fecha_creacion', header: 'Fecha Creación' },
            { field: 'bodega_origen_id', header: 'Origen' },
            { field: 'bodega_destino_id', header: 'Destino' },
            { field: 'estado', header: 'Estado' },
            { field: 'codigo_seguimiento', header: 'Código' }
        ];

        this.exportColumns = this.cols.map(col => ({
            title: col.header,
            dataKey: col.field
        }));
    }

    async loadEnvios() {
        this.loading = true;
        try {
            const data = await this.envioService.getEnvios();
            this.envios.set(data);
        } catch (error) {
            this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Error al cargar envíos', life: 3000 });
        } finally {
            this.loading = false;
        }
    }

    async loadBodegas() {
        try {
            const bodegas = await this.bodegaService.getBodegas();
            this.bodegas = bodegas.map(bodega => ({
                label: `${bodega.nombre} (${bodega.direccion || 'Sin dirección'})`,
                value: bodega.bodega_id
            }));
        } catch (error) {
            this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Error al cargar bodegas', life: 3000 });
        }
    }

    async loadProductos() {
        try {
            // Simulación de carga de productos, reemplazar cuando se implemente el servicio
            const demoProductos: Array<{producto_id: number, nombre: string}> = [
                { producto_id: 1, nombre: 'Producto 1' },
                { producto_id: 2, nombre: 'Producto 2' },
                { producto_id: 3, nombre: 'Producto 3' }
            ];
            
            this.productos = demoProductos.map((producto) => ({
                label: producto.nombre,
                value: producto.producto_id
            }));
        } catch (error) {
            this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Error al cargar productos', life: 3000 });
        }
    }

    getEmptyEnvio(): Envio {
        return {
            fecha_creacion: new Date(),
            bodega_origen_id: 0,
            bodega_destino_id: 0,
            estado: 'PENDIENTE',
            items: [this.getEmptyEnvioItem()]
        };
    }

    getEmptyEnvioItem(): EnvioItem {
        return {
            producto_id: 0,
            cantidad: 1
        };
    }

    openNew() {
        this.envio = this.getEmptyEnvio();
        this.submitted = false;
        this.envioDialog = true;
    }

    hideDialog() {
        this.envioDialog = false;
        this.submitted = false;
    }

    hideViewDialog() {
        this.envioViewDialog = false;
        this.envioView = null;
    }

    getBodegaNombre(bodegaId: number): string {
        const bodega = this.bodegas.find(b => b.value === bodegaId);
        return bodega ? bodega.label : `Bodega #${bodegaId}`;
    }

    getProductoNombre(productoId: number): string {
        const producto = this.productos.find(p => p.value === productoId);
        return producto ? producto.label : `Producto #${productoId}`;
    }

    getEstadoLabel(estado: string): string {
        const estadoObj = this.estadosEnvio.find(e => e.value === estado);
        return estadoObj ? estadoObj.label : estado;
    }

    getEstadoSeverity(estado: string): 'success' | 'info' | 'warn' | 'danger' | 'secondary' {
        switch (estado) {
            case 'PENDIENTE':
                return 'warn';
            case 'EN_TRANSITO':
                return 'info';
            case 'ENTREGADO':
                return 'success';
            case 'CANCELADO':
                return 'danger';
            default:
                return 'secondary';
        }
    }

    editEnvio(envio: Envio) {
        // Clonar el envío para no modificar el original hasta guardar
        this.envio = { ...envio, items: [...envio.items] };
        this.envioDialog = true;
    }

    viewEnvioDetail(envio: Envio) {
        this.envioView = { ...envio };
        this.envioViewDialog = true;
    }

    deleteSelectedEnvios() {
        this.confirmationService.confirm({
            message: '¿Está seguro que desea eliminar los envíos seleccionados?',
            header: 'Confirmar',
            icon: 'pi pi-exclamation-triangle',
            accept: () => {
                this.deleteMultipleEnvios();
            }
        });
    }

    async deleteMultipleEnvios() {
        try {
            for (const envio of this.selectedEnvios) {
                if (envio.envio_id) {
                    await this.envioService.deleteEnvio(envio.envio_id);
                }
            }
            
            await this.loadEnvios();
            this.selectedEnvios = [];
            this.messageService.add({ severity: 'success', summary: 'Exitoso', detail: 'Envíos eliminados', life: 3000 });
        } catch (error) {
            this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Error al eliminar envíos', life: 3000 });
        }
    }

    confirmDelete(envio: Envio) {
        this.confirmationService.confirm({
            message: '¿Está seguro que desea eliminar este envío?',
            header: 'Confirmar',
            icon: 'pi pi-exclamation-triangle',
            accept: () => {
                this.deleteEnvio(envio);
            }
        });
    }

    async deleteEnvio(envio: Envio) {
        if (!envio.envio_id) return;
        
        try {
            await this.envioService.deleteEnvio(envio.envio_id);
            await this.loadEnvios();
            this.messageService.add({ severity: 'success', summary: 'Exitoso', detail: 'Envío eliminado', life: 3000 });
        } catch (error) {
            this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Error al eliminar el envío', life: 3000 });
        }
    }

    async saveEnvio() {
        this.submitted = true;

        // Validaciones básicas
        if (!this.envio.bodega_origen_id || !this.envio.bodega_destino_id || !this.envio.estado) {
            return;
        }

        if (this.envio.bodega_origen_id === this.envio.bodega_destino_id) {
            this.messageService.add({ severity: 'error', summary: 'Error', detail: 'La bodega origen y destino no pueden ser la misma', life: 3000 });
            return;
        }

        if (!this.envio.items || this.envio.items.length === 0) {
            this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Debe agregar al menos un producto al envío', life: 3000 });
            return;
        }

        // Validar que todos los productos tengan ID y cantidad
        const invalidItems = this.envio.items.filter(item => !item.producto_id || !item.cantidad);
        if (invalidItems.length > 0) {
            this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Todos los productos deben tener ID y cantidad', life: 3000 });
            return;
        }

        try {
            if (this.envio.envio_id) {
                // Actualizar
                await this.envioService.updateEnvio(this.envio);
                this.messageService.add({ severity: 'success', summary: 'Exitoso', detail: 'Envío actualizado', life: 3000 });
            } else {
                // Crear nuevo
                await this.envioService.createEnvio(this.envio);
                this.messageService.add({ severity: 'success', summary: 'Exitoso', detail: 'Envío creado', life: 3000 });
            }
            
            await this.loadEnvios();
            this.envioDialog = false;
            this.envio = this.getEmptyEnvio();
        } catch (error) {
            this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Error al guardar el envío', life: 3000 });
        }
    }

    addNewItem() {
        this.envio.items.push(this.getEmptyEnvioItem());
    }

    removeItem(index: number) {
        this.envio.items.splice(index, 1);
        
        // Siempre debe haber al menos un item
        if (this.envio.items.length === 0) {
            this.addNewItem();
        }
    }

    onProductoChange(item: EnvioItem) {
        // Aquí podría cargar datos adicionales del producto seleccionado si es necesario
    }

    onGlobalFilter(table: Table, event: Event) {
        table.filterGlobal((event.target as HTMLInputElement).value, 'contains');
    }

    exportCSV() {
        this.table.exportCSV();
    }
} 