import { Component, OnInit, signal, ViewChild } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Table, TableModule } from 'primeng/table';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { RippleModule } from 'primeng/ripple';
import { ToastModule } from 'primeng/toast';
import { ToolbarModule } from 'primeng/toolbar';
import { InputTextModule } from 'primeng/inputtext';
import { TextareaModule } from 'primeng/textarea';
import { SelectModule } from 'primeng/select';
import { RadioButtonModule } from 'primeng/radiobutton';
import { InputNumberModule } from 'primeng/inputnumber';
import { DialogModule } from 'primeng/dialog';
import { TagModule } from 'primeng/tag';
import { InputIconModule } from 'primeng/inputicon';
import { IconFieldModule } from 'primeng/iconfield';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { DropdownModule } from 'primeng/dropdown';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { InventarioService, ItemInventario } from '../../services/inventario.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../environments/environment';

interface Column {
    field: string;
    header: string;
    customExportHeader?: string;
}

interface ExportColumn {
    title: string;
    dataKey: string;
}

@Component({
    selector: 'app-inventario',
    standalone: true,
    imports: [
        CommonModule,
        TableModule,
        FormsModule,
        ButtonModule,
        RippleModule,
        ToastModule,
        ToolbarModule,
        InputTextModule,
        TextareaModule,
        SelectModule,
        RadioButtonModule,
        InputNumberModule,
        DialogModule,
        TagModule,
        InputIconModule,
        IconFieldModule,
        ConfirmDialogModule,
        DropdownModule,
        ProgressSpinnerModule
    ],
    providers: [MessageService, ConfirmationService],
    template: `
        <p-toast></p-toast>
        
        <p-toolbar styleClass="mb-6">
            <ng-template #start>
                <p-button label="Nuevo" icon="pi pi-plus" severity="secondary" class="mr-2" (onClick)="openNew()" />
                <p-button severity="secondary" label="Eliminar" icon="pi pi-trash" outlined (onClick)="deleteSelectedItems()" [disabled]="!selectedItems || !selectedItems.length" />
            </ng-template>

            <ng-template #end>
                <p-button label="Exportar" icon="pi pi-upload" severity="secondary" (onClick)="exportCSV()" />
            </ng-template>
        </p-toolbar>

        <div *ngIf="isLoading" class="flex justify-content-center align-items-center my-5">
            <p-progressSpinner strokeWidth="4" class="mr-2"></p-progressSpinner>
            <span>Cargando datos de inventario...</span>
        </div>

        <div *ngIf="!isLoading && errorMessage" class="p-4 my-5 border-round bg-red-50 border-left-4 border-red-500">
            <h3 class="text-red-900 m-0 mb-2">Error al cargar datos</h3>
            <p class="text-red-700 m-0">{{ errorMessage }}</p>
            <p-button label="Reintentar" icon="pi pi-refresh" styleClass="mt-3 p-button-sm" severity="danger" (onClick)="loadData()"></p-button>
        </div>

        <p-table
            #dt
            [value]="items()"
            [rows]="10"
            [columns]="cols"
            [paginator]="true"
            [globalFilterFields]="['nombre', 'codigo_posicion', 'categoria', 'estado']"
            [tableStyle]="{ 'min-width': '75rem' }"
            [(selection)]="selectedItems"
            [rowHover]="true"
            dataKey="id"
            currentPageReportTemplate="Mostrando {first} a {last} de {totalRecords} items"
            [showCurrentPageReport]="true"
            [rowsPerPageOptions]="[10, 20, 30]"
            *ngIf="!isLoading && !errorMessage && items().length > 0"
        >
            <ng-template #caption>
                <div class="flex items-center justify-between">
                    <h5 class="m-0">Gestión de Inventario</h5>
                    <p-iconfield>
                        <p-inputicon styleClass="pi pi-search" />
                        <input pInputText type="text" (input)="onGlobalFilter(dt, $event)" placeholder="Buscar..." />
                    </p-iconfield>
                </div>
            </ng-template>
            <ng-template #header>
                <tr>
                    <th style="width: 3rem">
                        <p-tableHeaderCheckbox />
                    </th>
                    <th pSortableColumn="codigo_posicion" style="min-width: 10rem">
                        Posición
                        <p-sortIcon field="codigo_posicion" />
                    </th>
                    <th pSortableColumn="nombre" style="min-width:16rem">
                        Nombre
                        <p-sortIcon field="nombre" />
                    </th>
                    <th pSortableColumn="categoria" style="min-width: 10rem">
                        Categoría
                        <p-sortIcon field="categoria" />
                    </th>
                    <th pSortableColumn="cantidad" style="min-width: 8rem">
                        Cantidad
                        <p-sortIcon field="cantidad" />
                    </th>
                    <th pSortableColumn="precio_total" style="min-width: 8rem">
                        Precio Total
                        <p-sortIcon field="precio_total" />
                    </th>
                    <th pSortableColumn="estado" style="min-width: 12rem">
                        Estado
                        <p-sortIcon field="estado" />
                    </th>
                    <th style="min-width: 12rem"></th>
                </tr>
            </ng-template>
            <ng-template #body let-item>
                <tr>
                    <td style="width: 3rem">
                        <p-tableCheckbox [value]="item" />
                    </td>
                    <td style="min-width: 10rem">{{ item.codigo_posicion }}</td>
                    <td style="min-width: 16rem">{{ item.nombre }}</td>
                    <td>{{ item.categoria }}</td>
                    <td>{{ item.cantidad }}</td>
                    <td>{{ item.precio_total | currency: 'CLP' }}</td>
                    <td>
                        <p-tag [value]="item.estado" [severity]="getSeverity(item.estado)" />
                    </td>
                    <td>
                        <p-button icon="pi pi-pencil" class="mr-2" [rounded]="true" [outlined]="true" (click)="editItem(item)" />
                        <p-button icon="pi pi-trash" severity="danger" [rounded]="true" [outlined]="true" (click)="deleteItem(item)" />
                    </td>
                </tr>
            </ng-template>
            <ng-template #emptymessage>
                <tr>
                    <td colspan="8" class="text-center p-4">No se encontraron elementos de inventario.</td>
                </tr>
            </ng-template>
        </p-table>

        <div *ngIf="!isLoading && !errorMessage && items().length === 0" class="p-4 my-5 border-round bg-blue-50 text-center">
            <p class="text-blue-700 m-0 mb-3">No hay elementos de inventario disponibles.</p>
            <p-button label="Agregar Nuevo Item" icon="pi pi-plus" severity="info" (onClick)="openNew()"></p-button>
        </div>

        <p-dialog [(visible)]="itemDialog" [style]="{ width: '550px' }" header="Detalles del Inventario" [modal]="true">
            <ng-template #content>
                <div class="flex flex-col gap-6">
                    <div class="grid grid-cols-12 gap-4">
                        <div class="col-span-12">
                            <label for="producto" class="block font-bold mb-3">Producto</label>
                            <p-dropdown [(ngModel)]="item.producto_id" 
                                        [options]="productos" 
                                        optionLabel="label" 
                                        optionValue="value" 
                                        placeholder="Seleccione Producto" 
                                        [style]="{'width':'100%'}" 
                                        [filter]="true" 
                                        filterBy="label" 
                                        [showClear]="true" 
                                        appendTo="body"
                                        (onChange)="calcularPrecioTotal()">
                                <ng-template pTemplate="selectedItem">
                                    <div class="flex align-items-center gap-2" *ngIf="item.producto_id">
                                        <img 
                                            [src]="getProductoImagen(item.producto_id)" 
                                            [alt]="getProductoLabel(item.producto_id)"
                                            style="width: 32px; height: 32px; object-fit: contain;"
                                            class="mr-2 rounded"
                                        />
                                        <div>{{ getProductoLabel(item.producto_id) }}</div>
                                    </div>
                                </ng-template>
                                <ng-template let-producto pTemplate="item">
                                    <div class="flex align-items-center gap-2">
                                        <img 
                                            [src]="producto.imagen" 
                                            [alt]="producto.label"
                                            style="width: 32px; height: 32px; object-fit: contain;"
                                            class="mr-2 rounded"
                                        />
                                        <div>{{ producto.label }}</div>
                                    </div>
                                </ng-template>
                            </p-dropdown>
                            <small class="text-red-500" *ngIf="submitted && !item.producto_id">Producto es requerido.</small>
                        </div>
                    </div>

                    <div class="grid grid-cols-12 gap-4">
                        <div class="col-span-12">
                            <label for="bodega" class="block font-bold mb-3">Bodega</label>
                            <p-dropdown [(ngModel)]="item.bodega_id" 
                                       [options]="bodegas" 
                                       optionLabel="label" 
                                       optionValue="value" 
                                       placeholder="Seleccione Bodega" 
                                       [style]="{'width':'100%'}" 
                                       [filter]="true" 
                                       filterBy="label" 
                                       [showClear]="true" 
                                       appendTo="body">
                                <ng-template pTemplate="selectedItem">
                                    <div class="flex align-items-center gap-2" *ngIf="item.bodega_id">
                                        <div>{{ getBodegaLabel(item.bodega_id) }}</div>
                                    </div>
                                </ng-template>
                                <ng-template let-bodega pTemplate="item">
                                    <div class="flex align-items-center gap-2">
                                        <div>{{ bodega.label }}</div>
                                    </div>
                                </ng-template>
                            </p-dropdown>
                            <small class="text-red-500" *ngIf="submitted && !item.bodega_id">Bodega es requerida.</small>
                        </div>
                    </div>

                    <div class="grid grid-cols-12 gap-4">
                        <div class="col-span-12">
                            <label for="codigo_posicion" class="block font-bold mb-3">Código de Posición</label>
                            <input id="codigo_posicion" pInputText [(ngModel)]="item.codigo_posicion" required="true" class="w-full" />
                            <small class="text-red-500" *ngIf="submitted && !item.codigo_posicion">Código de posición es requerido.</small>
                        </div>
                    </div>

                    <div class="grid grid-cols-12 gap-4">
                        <div class="col-span-6">
                            <label for="cantidad" class="block font-bold mb-3">Cantidad Actual</label>
                            <p-inputnumber id="cantidad" [(ngModel)]="item.cantidad" (ngModelChange)="calcularPrecioTotal(); calcularEstado()" fluid min="0" required="true" />
                            <small class="text-red-500" *ngIf="submitted && (item.cantidad === undefined || item.cantidad < 0)">Cantidad válida es requerida.</small>
                        </div>
                        <div class="col-span-6">
                            <label for="cantidad_maxima" class="block font-bold mb-3">Cantidad Máxima</label>
                            <p-inputnumber id="cantidad_maxima" [(ngModel)]="item.cantidad_maxima" (ngModelChange)="calcularEstado()" fluid min="0" />
                        </div>
                    </div>

                    <div>
                        <label for="estado" class="block font-bold mb-3">Estado</label>
                        <p-tag [value]="item.estado || 'DISPONIBLE'" [severity]="getSeverity(item.estado || 'DISPONIBLE')" />
                        <small class="block mt-2 text-gray-500">El estado se calcula automáticamente basado en la cantidad actual y máxima.</small>
                    </div>
                </div>
            </ng-template>

            <ng-template #footer>
                <p-button label="Cancelar" icon="pi pi-times" text (click)="hideDialog()" />
                <p-button label="Guardar" icon="pi pi-check" (click)="saveItem()" />
            </ng-template>
        </p-dialog>

        <p-confirmdialog [style]="{ width: '450px' }" />
    `
})
export class Inventario implements OnInit {
    itemDialog: boolean = false;

    items = signal<ItemInventario[]>([]);
    
    // Indicadores de estado
    isLoading: boolean = true;
    errorMessage: string = '';
    
    // ID de bodega por defecto
    bodegaId = 1;

    item!: ItemInventario;

    selectedItems!: ItemInventario[] | null;

    submitted: boolean = false;

    estados!: any[];

    categorias!: string[];
    
    productos: any[] = [];
    productosPrecios: Map<number, number> = new Map(); // Mapa para almacenar los precios de los productos
    bodegas: any[] = [];

    @ViewChild('dt') dt!: Table;

    exportColumns!: ExportColumn[];

    cols!: Column[];

    constructor(
        private inventarioService: InventarioService,
        private messageService: MessageService,
        private confirmationService: ConfirmationService,
        private http: HttpClient
    ) {}

    exportCSV() {
        this.dt.exportCSV();
    }

    ngOnInit() {
        // Definir las columnas para la tabla
        this.cols = [
            { field: 'codigo_posicion', header: 'Posición' },
            { field: 'nombre', header: 'Nombre' },
            { field: 'categoria', header: 'Categoría' },
            { field: 'cantidad', header: 'Cantidad' },
            { field: 'precio_total', header: 'Precio Total' },
            { field: 'estado', header: 'Estado' }
        ];
        
        // Cargar datos estáticos
        this.estados = this.inventarioService.getEstadosInventario();
        this.categorias = this.inventarioService.getCategorias();
        
        // Cargar datos dinámicos
        this.loadData();
        this.loadBodegas();
    }

    loadData() {
        this.isLoading = true;
        this.errorMessage = '';
        
        // Primero cargar productos para tener los precios
        this.loadProductos().then(() => {
            // Luego cargar inventario para la bodega con ID 1
            this.inventarioService.getInventarioItems(this.bodegaId)
                .then((data) => {
                    this.items.set(data);
                    this.isLoading = false;
                    // Actualizar los precios totales basados en los productos cargados
                    setTimeout(() => this.updateItemsPrecioTotal(), 100);
                })
                .catch((error) => {
                    this.isLoading = false;
                    this.errorMessage = 'No se pudo cargar el inventario. Por favor, intente nuevamente.';
                    this.messageService.add({ 
                        severity: 'error', 
                        summary: 'Error', 
                        detail: 'No se pudo cargar el inventario desde el servidor', 
                        life: 5000 
                    });
                    console.error('Error al cargar inventario:', error);
                });
        }).catch(error => {
            this.isLoading = false;
            this.errorMessage = 'No se pudo cargar la información de productos. Por favor, intente nuevamente.';
            console.error('Error en carga inicial:', error);
        });
    }
    
    // Cargar productos para selección
    loadProductos(): Promise<void> {
        const headers = new HttpHeaders({
            'Authorization': `Bearer ${localStorage.getItem('access_token')}`
        });
        
        return new Promise((resolve, reject) => {
            this.http.get(`${environment.apiUrl}/productos`, { headers })
                .subscribe({
                    next: (response: any) => {
                        console.log('Respuesta de productos:', response);
                        
                        // Guardar los productos y sus precios
                        if (Array.isArray(response)) {
                            // Si la respuesta es un array directo de productos
                            this.productos = response.map((p: any) => ({
                                value: p.producto_id,
                                label: `${p.sku} - ${p.nombre}`,
                                imagen: p.imagen_url || 'assets/images/product-placeholder.svg'
                            }));
                            
                            // Guardar los precios en el mapa
                            response.forEach((p: any) => {
                                if (p.producto_id && p.precio !== undefined) {
                                    this.productosPrecios.set(p.producto_id, p.precio);
                                }
                            });
                        } else if (response && response.items && Array.isArray(response.items)) {
                            // Si la respuesta tiene un formato de paginación con "items"
                            this.productos = response.items.map((p: any) => ({
                                value: p.producto_id,
                                label: `${p.sku} - ${p.nombre}`,
                                imagen: p.imagen_url || 'assets/images/product-placeholder.svg'
                            }));
                            
                            // Guardar los precios en el mapa
                            response.items.forEach((p: any) => {
                                if (p.producto_id && p.precio !== undefined) {
                                    this.productosPrecios.set(p.producto_id, p.precio);
                                }
                            });
                        } else {
                            console.error('Formato de respuesta de productos no reconocido:', response);
                            this.messageService.add({ 
                                severity: 'warn', 
                                summary: 'Advertencia', 
                                detail: 'No se pudieron cargar los productos correctamente', 
                                life: 5000 
                            });
                            reject(new Error('Formato de respuesta de productos no reconocido'));
                            return;
                        }
                        
                        // Actualizar los precios totales de los items existentes
                        this.updateItemsPrecioTotal();
                        resolve();
                    },
                    error: (err) => {
                        console.error('Error al cargar productos:', err);
                        this.messageService.add({ 
                            severity: 'error', 
                            summary: 'Error', 
                            detail: 'No se pudieron cargar los productos desde el servidor', 
                            life: 5000 
                        });
                        reject(err);
                    }
                });
        });
    }
    
    // Método para actualizar precios totales después de cargar los productos
    updateItemsPrecioTotal() {
        const currentItems = [...this.items()];
        currentItems.forEach(item => {
            if (item.producto_id && item.cantidad) {
                const precio = this.productosPrecios.get(item.producto_id) || 0;
                item.precio_total = precio * item.cantidad;
            }
        });
        this.items.set(currentItems);
    }
    
    // Cargar bodegas para selección
    loadBodegas() {
        const headers = new HttpHeaders({
            'Authorization': `Bearer ${localStorage.getItem('access_token')}`
        });
        
        // Endpoint para bodegas
        this.http.get(`${environment.apiUrl}/bodegas`, { headers })
            .subscribe({
                next: (response: any) => {
                    console.log('Respuesta de bodegas:', response);
                    
                    if (response && Array.isArray(response)) {
                        // Si la respuesta es un array directo de bodegas
                        this.bodegas = response.map((b: any) => ({
                            value: b.bodega_id,
                            label: b.nombre || `Bodega ${b.bodega_id}`
                        }));
                    } else if (response && response.items && Array.isArray(response.items)) {
                        // Si la respuesta tiene un formato de paginación con "items"
                        this.bodegas = response.items.map((b: any) => ({
                            value: b.bodega_id,
                            label: b.nombre || `Bodega ${b.bodega_id}`
                        }));
                    } else {
                        console.error('Formato de respuesta de bodegas no reconocido:', response);
                        this.messageService.add({ 
                            severity: 'warn', 
                            summary: 'Advertencia', 
                            detail: 'No se pudieron cargar las bodegas correctamente', 
                            life: 5000 
                        });
                    }
                },
                error: (err) => {
                    console.error('Error al cargar bodegas:', err);
                    this.messageService.add({ 
                        severity: 'error', 
                        summary: 'Error', 
                        detail: 'No se pudieron cargar las bodegas desde el servidor', 
                        life: 5000 
                    });
                }
            });
    }

    onGlobalFilter(table: Table, event: Event) {
        table.filterGlobal((event.target as HTMLInputElement).value, 'contains');
    }

    openNew() {
        this.item = {
            fechaIngreso: new Date(),
            estado: 'DISPONIBLE',
            cantidad: 0,
            cantidad_maxima: 100,
            precio_total: 0,
            codigo_posicion: '',
            bodega_id: this.bodegaId // Default to bodegaId
        };
        this.calcularEstado(); // Calcular el estado inicial
        this.submitted = false;
        this.itemDialog = true;
    }

    editItem(item: ItemInventario) {
        this.item = { ...item };
        this.calcularEstado();
        this.calcularPrecioTotal(); // Calcular el precio total
        this.itemDialog = true;
    }

    deleteSelectedItems() {
        this.confirmationService.confirm({
            message: '¿Está seguro que desea eliminar los items seleccionados?',
            header: 'Confirmar',
            icon: 'pi pi-exclamation-triangle',
            accept: async () => {
                if (this.selectedItems && this.selectedItems.length > 0) {
                    try {
                        // Eliminar cada item seleccionado
                        for (const item of this.selectedItems) {
                            if (item.inv_id) {
                                await this.inventarioService.deleteInventarioItem(item.inv_id);
                            }
                        }
                        
                        // Actualizar la lista de items
                        this.loadData();
                        
                        this.selectedItems = null;
                        this.messageService.add({ severity: 'success', summary: 'Exitoso', detail: 'Items Eliminados', life: 3000 });
                    } catch (error) {
                        console.error('Error al eliminar items:', error);
                        this.messageService.add({ severity: 'error', summary: 'Error', detail: 'No se pudieron eliminar los items seleccionados', life: 3000 });
                    }
                }
            }
        });
    }

    hideDialog() {
        this.itemDialog = false;
        this.submitted = false;
    }

    deleteItem(item: ItemInventario) {
        this.confirmationService.confirm({
            message: '¿Está seguro que desea eliminar ' + item.nombre + '?',
            header: 'Confirmar',
            icon: 'pi pi-exclamation-triangle',
            accept: async () => {
                try {
                    if (item.inv_id) {
                        await this.inventarioService.deleteInventarioItem(item.inv_id);
                        this.loadData();
                        this.messageService.add({ severity: 'success', summary: 'Exitoso', detail: 'Item Eliminado', life: 3000 });
                    }
                } catch (error) {
                    console.error('Error al eliminar item:', error);
                    this.messageService.add({ severity: 'error', summary: 'Error', detail: 'No se pudo eliminar el item', life: 3000 });
                }
            }
        });
    }

    findIndexById(id: string): number {
        let index = -1;
        for (let i = 0; i < this.items().length; i++) {
            if (this.items()[i].id === id) {
                index = i;
                break;
            }
        }

        return index;
    }

    createId(): string {
        return this.inventarioService.generateId();
    }

    getSeverity(status: string) {
        switch (status) {
            case 'DISPONIBLE':
                return 'success';
            case 'POCAS_EXISTENCIAS':
                return 'warn';
            case 'AGOTADO':
                return 'danger';
            default:
                return 'info';
        }
    }

    saveItem() {
        this.submitted = true;

        if (!this.item.producto_id) {
            this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Debe seleccionar un producto', life: 3000 });
            return;
        }

        if (!this.item.bodega_id) {
            this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Debe seleccionar una bodega', life: 3000 });
            return;
        }

        if (!this.item.codigo_posicion) {
            this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Debe ingresar un código de posición', life: 3000 });
            return;
        }

        if (this.item.cantidad === undefined || this.item.cantidad < 0) {
            this.messageService.add({ severity: 'error', summary: 'Error', detail: 'La cantidad debe ser un número positivo', life: 3000 });
            return;
        }

        // Asegurar que el estado esté actualizado según las cantidades
        this.calcularEstado();

        try {
            if (this.item.inv_id) {
                // Actualizar item existente
                this.inventarioService.updateInventarioItem(this.item)
                    .then(() => {
                        // Recargar inventario para la bodega específica
                        this.loadData();
                        this.messageService.add({ severity: 'success', summary: 'Exitoso', detail: 'Item Actualizado', life: 3000 });
                        this.itemDialog = false;
                        this.item = {
                            codigo_posicion: '',
                            precio_total: 0,
                            bodega_id: this.bodegaId
                        };
                    })
                    .catch(error => {
                        console.error('Error al actualizar:', error);
                        this.messageService.add({ severity: 'error', summary: 'Error', detail: 'No se pudo actualizar el item', life: 3000 });
                    });
            } else {
                // Crear nuevo item
                this.inventarioService.createInventarioItem(this.item)
                    .then(() => {
                        // Recargar inventario para la bodega específica
                        this.loadData();
                        this.messageService.add({ severity: 'success', summary: 'Exitoso', detail: 'Item Creado', life: 3000 });
                        this.itemDialog = false;
                        this.item = {
                            codigo_posicion: '',
                            precio_total: 0,
                            bodega_id: this.bodegaId
                        };
                    })
                    .catch(error => {
                        console.error('Error al crear:', error);
                        this.messageService.add({ severity: 'error', summary: 'Error', detail: 'No se pudo crear el item', life: 3000 });
                    });
            }
        } catch (error) {
            console.error('Error al guardar item:', error);
            this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Error al guardar el item', life: 3000 });
        }
    }

    getProductoLabel(productoId: number): string {
        const producto = this.productos.find(p => p.value === productoId);
        return producto ? producto.label : '';
    }

    getBodegaLabel(bodegaId: number): string {
        const bodega = this.bodegas.find(b => b.value === bodegaId);
        return bodega ? bodega.label : '';
    }

    getProductoImagen(productoId: number): string {
        const producto = this.productos.find(p => p.value === productoId);
        return producto ? producto.imagen : 'assets/images/product-placeholder.svg';
    }

    calcularEstado() {
        if (!this.item || this.item.cantidad === undefined || this.item.cantidad_maxima === undefined) {
            return;
        }
        
        // Determinar el estado basado en las cantidades
        if (this.item.cantidad <= 0) {
            this.item.estado = 'AGOTADO';
        } else if (this.item.cantidad < (this.item.cantidad_maxima * 0.2)) {
            this.item.estado = 'POCAS_EXISTENCIAS';
        } else {
            this.item.estado = 'DISPONIBLE';
        }
    }

    calcularPrecioTotal() {
        if (!this.item || !this.item.producto_id || this.item.cantidad === undefined) {
            if (this.item) {
                this.item.precio_total = 0;
            }
            return;
        }
        
        const precio = this.productosPrecios.get(this.item.producto_id) || 0;
        this.item.precio_total = precio * this.item.cantidad;
    }
} 