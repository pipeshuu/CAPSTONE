import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { BehaviorSubject, Observable, catchError, firstValueFrom, map, of, tap, throwError } from 'rxjs';

interface EstadoInventario {
    label: string;
    value: string;
}

// Interfaces adaptadas al modelo del backend
export interface ProductoBackend {
    producto_id: number;
    sku: string;
    nombre: string;
    descripcion?: string;
    unidad_medida?: string;
    categoria_id?: number | null;
    peso?: number;
    imagen_url?: string;
    precio?: number;
}

export interface BodegaBackend {
    bodega_id: number;
    nombre: string;
    direccion?: string;
    tipo: string;
    parent_bodega_id?: number;
}

export interface InventarioBackend {
    inv_id: number;
    producto_id: number;
    bodega_id: number;
    codigo_posicion: string;
    cantidad_actual: number;
    cantidad_maxima: number;
    producto?: ProductoBackend;
    bodega?: BodegaBackend;
}

export interface InventarioBodegaItem {
    inv_id: number;
    codigo_posicion: string;
    cantidad_actual: number;
    cantidad_maxima: number;
    producto: ProductoBackend;
    bodega: BodegaBackend;
}

export interface InventarioBodegaResponse {
    items: InventarioBodegaItem[];
    total: number;
}

export interface InventarioListResponse {
    items: InventarioBackend[];
    total: number;
}

// Interfaces para el frontend (mantiene compatibilidad con la UI actual)
export interface ItemInventario {
    id?: string;
    codigo_posicion: string;
    nombre?: string;
    descripcion?: string;
    precio?: number;
    precio_total: number;
    cantidad?: number;
    estado?: string;
    categoria?: string;
    imagen?: string;
    fechaIngreso?: Date;
    fechaVencimiento?: Date | null;
    // Campos adicionales para mapeo con el backend
    inv_id?: number;
    producto_id?: number;
    bodega_id: number;
    cantidad_maxima?: number;
}

@Injectable({
    providedIn: 'root'
})
export class InventarioService {
    private apiUrl = `${environment.apiUrl}/inventario`;
    private productosUrl = `${environment.apiUrl}/productos`;
    private categoriasUrl = `${environment.apiUrl}/categorias`;
    private bodegasUrl = `${environment.apiUrl}/bodegas`;
    
    // ID de bodega por defecto
    private defaultBodegaId = 1;
    
    private inventarioSource = new BehaviorSubject<ItemInventario[]>([]);
    inventario$ = this.inventarioSource.asObservable();
    
    private categoriasCache: any[] = [];
    private productosCache: ProductoBackend[] = [];
    private bodegasCache: BodegaBackend[] = [];

    constructor(private http: HttpClient) {
        // Carga inicial de datos
        this.loadInventario();
    }

    // Obtener el token desde el localStorage
    private getAuthHeaders(): HttpHeaders {
        const token = localStorage.getItem('access_token');
        return new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        });
    }

    // Método para cargar datos del inventario desde la API por bodega
    async loadInventario(bodegaId: number = this.defaultBodegaId) {
        try {
            // Primero cargamos las categorías para el mapeo
            if (this.categoriasCache.length === 0) {
                await this.loadCategorias();
            }
            
            // Si no tenemos bodegas cargadas, las cargamos
            if (this.bodegasCache.length === 0) {
                await this.loadBodegas();
            }
            
            // Ahora cargamos el inventario por bodega
            const response = await firstValueFrom(
                this.http.get<InventarioBodegaResponse>(
                    `${this.apiUrl}/por-bodega/${bodegaId}`,
                    { headers: this.getAuthHeaders() }
                )
            );
            
            // Mapeamos la respuesta al formato que espera nuestro frontend
            const mappedItems = this.mapInventarioBodegaToItemInventario(response.items || []);
            this.inventarioSource.next(mappedItems);
            return mappedItems;
        } catch (error) {
            console.error('Error al cargar el inventario:', error);
            // No usamos datos demo, simplemente devolvemos un array vacío
            this.inventarioSource.next([]);
            throw error;
        }
    }

    // Método para obtener los items del inventario (compatible con la implementación actual)
    getInventarioItems(bodegaId: number = this.defaultBodegaId): Promise<ItemInventario[]> {
        return firstValueFrom(this.inventario$).then(items => {
            // Si no hay datos, los cargamos
            if (items.length === 0) {
                return this.loadInventario(bodegaId);
            }
            return items;
        });
    }

    // Método para crear un nuevo item de inventario
    async createInventarioItem(item: ItemInventario): Promise<ItemInventario> {
        // Mapear del formato frontend al backend
        const backendItem = {
            producto_id: item.producto_id,
            bodega_id: item.bodega_id,
            codigo_posicion: item.codigo_posicion,
            cantidad_actual: item.cantidad || 0,
            cantidad_maxima: item.cantidad_maxima || 100
        };

        try {
            const result = await firstValueFrom(
                this.http.post<InventarioBackend>(this.apiUrl, backendItem, { headers: this.getAuthHeaders() })
            );
            
            // Actualizar la lista
            await this.loadInventario();
            
            // Devolver el item mapeado
            return this.mapSingleInventarioToItemInventario(result);
        } catch (error) {
            console.error('Error al crear item de inventario:', error);
            throw error;
        }
    }

    // Método para actualizar un item existente
    async updateInventarioItem(item: ItemInventario): Promise<ItemInventario> {
        if (!item.inv_id) {
            throw new Error('El item debe tener un inv_id');
        }

        // Mapear del formato frontend al backend
        const backendItem = {
            producto_id: item.producto_id,
            bodega_id: item.bodega_id,
            codigo_posicion: item.codigo_posicion,
            cantidad_actual: item.cantidad || 0,
            cantidad_maxima: item.cantidad_maxima || 100
        };

        try {
            const result = await firstValueFrom(
                this.http.put<InventarioBackend>(`${this.apiUrl}/${item.inv_id}`, backendItem, { headers: this.getAuthHeaders() })
            );
            
            // Actualizar la lista
            await this.loadInventario();
            
            // Devolver el item mapeado
            return this.mapSingleInventarioToItemInventario(result);
        } catch (error) {
            console.error('Error al actualizar item de inventario:', error);
            throw error;
        }
    }

    // Método para eliminar un item
    async deleteInventarioItem(inv_id: number): Promise<void> {
        try {
            await firstValueFrom(
                this.http.delete(`${this.apiUrl}/${inv_id}`, { headers: this.getAuthHeaders() })
            );
            
            // Actualizar la lista
            await this.loadInventario();
        } catch (error) {
            console.error('Error al eliminar item de inventario:', error);
            throw error;
        }
    }

    // Métodos auxiliares
    private async loadCategorias() {
        try {
            this.categoriasCache = await firstValueFrom(
                this.http.get<any[]>(this.categoriasUrl, { headers: this.getAuthHeaders() })
            );
        } catch (error) {
            console.error('Error al cargar categorías:', error);
            this.categoriasCache = [];
            throw error;
        }
    }

    private async loadBodegas() {
        try {
            const response = await firstValueFrom(
                this.http.get<any>(this.bodegasUrl, { headers: this.getAuthHeaders() })
            );
            
            if (response && Array.isArray(response)) {
                this.bodegasCache = response;
            } else if (response && response.items && Array.isArray(response.items)) {
                this.bodegasCache = response.items;
            } else {
                this.bodegasCache = [];
            }
        } catch (error) {
            console.error('Error al cargar bodegas:', error);
            this.bodegasCache = [];
            throw error;
        }
    }

    private async loadProductos() {
        try {
            const response = await firstValueFrom(
                this.http.get<any>(this.productosUrl, { headers: this.getAuthHeaders() })
            );
            
            if (Array.isArray(response)) {
                // Podemos tener información de precio en cada producto
                this.productosCache = response.map((p: any) => ({
                    ...p,
                    // Si el producto no tiene precio, asignamos 0
                    precio: p.precio || 0
                }));
            } else if (response && response.items && Array.isArray(response.items)) {
                this.productosCache = response.items.map((p: any) => ({
                    ...p,
                    precio: p.precio || 0
                }));
            } else {
                this.productosCache = [];
            }
        } catch (error) {
            console.error('Error al cargar productos:', error);
            this.productosCache = [];
            throw error;
        }
    }

    private handleError(error: any) {
        console.error('Error en la operación:', error);
        let errorMessage = 'Error en la operación';
        
        if (error.error instanceof ErrorEvent) {
            // Error del lado del cliente
            errorMessage = `Error: ${error.error.message}`;
        } else if (error.status) {
            // Error devuelto por el servidor
            errorMessage = `Error ${error.status}: ${error.error?.detail || error.statusText}`;
        }
        
        return throwError(() => new Error(errorMessage));
    }

    // Mapear de InventarioBodegaItem[] a ItemInventario[]
    private mapInventarioBodegaToItemInventario(items: InventarioBodegaItem[]): ItemInventario[] {
        return items.map(item => {
            const producto = item.producto || {} as ProductoBackend;
            const bodega = item.bodega || {} as BodegaBackend;
            
            // Determinar el estado basado en cantidad_actual y cantidad_maxima
            let estado = 'DISPONIBLE';
            if (item.cantidad_actual <= 0) {
                estado = 'AGOTADO';
            } else if (item.cantidad_actual < (item.cantidad_maxima * 0.2)) {
                estado = 'POCAS_EXISTENCIAS';
            }
            
            // Calcular precio total
            const precioUnitario = producto.precio || 0;
            const precioTotal = precioUnitario * item.cantidad_actual;
            
            return {
                id: `${item.inv_id}`,
                inv_id: item.inv_id,
                producto_id: producto.producto_id,
                bodega_id: bodega.bodega_id,
                codigo_posicion: item.codigo_posicion,
                nombre: producto.nombre,
                descripcion: producto.descripcion,
                categoria: this.getCategoriaNameById(producto.categoria_id),
                cantidad: item.cantidad_actual,
                cantidad_maxima: item.cantidad_maxima,
                precio: precioUnitario,
                precio_total: precioTotal,
                estado: estado,
                imagen: producto.imagen_url,
                fechaIngreso: new Date()
            };
        });
    }

    // Mapear de InventarioBackend[] a ItemInventario[]
    private mapInventarioToItemInventario(items: InventarioBackend[]): ItemInventario[] {
        return items.map(item => this.mapSingleInventarioToItemInventario(item));
    }

    // Mapear un único InventarioBackend a ItemInventario
    private mapSingleInventarioToItemInventario(item: InventarioBackend): ItemInventario {
        // Si tenemos el producto completo en el item
        if (item.producto) {
            const producto = item.producto;
            const bodega = item.bodega || {} as BodegaBackend;
            
            // Determinar el estado basado en cantidad_actual y cantidad_maxima
            let estado = 'DISPONIBLE';
            if (item.cantidad_actual <= 0) {
                estado = 'AGOTADO';
            } else if (item.cantidad_actual < (item.cantidad_maxima * 0.2)) {
                estado = 'POCAS_EXISTENCIAS';
            }
            
            // Calcular precio total
            const precioUnitario = producto.precio || 0;
            const precioTotal = precioUnitario * item.cantidad_actual;
            
            return {
                id: `${item.inv_id}`,
                inv_id: item.inv_id,
                producto_id: producto.producto_id,
                bodega_id: item.bodega_id,
                codigo_posicion: item.codigo_posicion,
                nombre: producto.nombre,
                descripcion: producto.descripcion,
                categoria: this.getCategoriaNameById(producto.categoria_id),
                cantidad: item.cantidad_actual,
                cantidad_maxima: item.cantidad_maxima,
                precio: precioUnitario,
                precio_total: precioTotal,
                estado: estado,
                imagen: producto.imagen_url,
                fechaIngreso: new Date()
            };
        } 
        // Si solo tenemos el ID del producto, buscamos en la caché
        else {
            // Buscar el producto en la caché
            const producto = this.productosCache.find(p => p.producto_id === item.producto_id) || {} as ProductoBackend;
            
            // Determinar el estado
            let estado = 'DISPONIBLE';
            if (item.cantidad_actual <= 0) {
                estado = 'AGOTADO';
            } else if (item.cantidad_actual < (item.cantidad_maxima * 0.2)) {
                estado = 'POCAS_EXISTENCIAS';
            }
            
            // Si no tenemos precio en el producto, usamos 0
            const precioUnitario = producto.precio || 0;
            const precioTotal = precioUnitario * item.cantidad_actual;
            
            return {
                id: `${item.inv_id}`,
                inv_id: item.inv_id,
                producto_id: item.producto_id,
                bodega_id: item.bodega_id,
                codigo_posicion: item.codigo_posicion,
                nombre: producto.nombre || `Producto ${item.producto_id}`,
                descripcion: producto.descripcion,
                categoria: this.getCategoriaNameById(producto.categoria_id),
                cantidad: item.cantidad_actual,
                cantidad_maxima: item.cantidad_maxima,
                precio: precioUnitario,
                precio_total: precioTotal,
                estado: estado,
                imagen: producto.imagen_url,
                fechaIngreso: new Date()
            };
        }
    }

    // Obtener el nombre de la categoría a partir de su ID
    private getCategoriaNameById(categoriaId?: number | null): string {
        if (!categoriaId) return 'Sin categoría';
        
        const categoria = this.categoriasCache.find(c => c.categoria_id === categoriaId);
        return categoria ? categoria.nombre : 'Sin categoría';
    }

    // Métodos públicos
    getEstadosInventario(): EstadoInventario[] {
        return [
            { label: 'Disponible', value: 'DISPONIBLE' },
            { label: 'Pocas Existencias', value: 'POCAS_EXISTENCIAS' },
            { label: 'Agotado', value: 'AGOTADO' }
        ];
    }

    getCategorias(): string[] {
        return this.categoriasCache.map(c => c.nombre || 'Sin nombre');
    }

    generateId(): string {
        let id = '';
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        
        for (let i = 0; i < 10; i++) {
            id += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        
        return id;
    }
} 