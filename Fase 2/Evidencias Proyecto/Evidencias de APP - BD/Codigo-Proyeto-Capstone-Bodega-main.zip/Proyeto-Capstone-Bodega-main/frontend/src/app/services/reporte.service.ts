import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { BehaviorSubject, Observable, firstValueFrom, throwError } from 'rxjs';

export interface Reporte {
    reporte_id?: number;
    titulo: string;
    descripcion?: string;
    tipo: string;
    fecha_creacion?: Date;
    usuario_id?: number;
    usuario?: string;
    estado: string;
    datos?: any;
}

export interface ReporteResponse {
    items: Reporte[];
    total: number;
}

@Injectable({
    providedIn: 'root'
})
export class ReporteService {
    private apiUrl = `${environment.apiUrl}/reportes`;
    private reportesSource = new BehaviorSubject<Reporte[]>([]);
    reportes$ = this.reportesSource.asObservable();

    constructor(private http: HttpClient) {
        // Carga inicial de datos
        this.loadReportes();
    }

    // Obtener el token desde el localStorage
    private getAuthHeaders(): HttpHeaders {
        const token = localStorage.getItem('access_token');
        return new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        });
    }

    // Método para cargar datos de reportes desde la API
    async loadReportes(): Promise<Reporte[]> {
        try {
            const headers = this.getAuthHeaders();
            const response = await firstValueFrom(
                this.http.get<ReporteResponse>(this.apiUrl, { headers })
            );
            
            const reportes = Array.isArray(response) ? response : 
                            (response.items ? response.items : []);
            
            this.reportesSource.next(reportes);
            return reportes;
        } catch (error) {
            console.error('Error al cargar reportes:', error);
            // En caso de error, usar datos de demostración
            const demoReportes = this.getDemoReportes();
            this.reportesSource.next(demoReportes);
            return demoReportes;
        }
    }

    // Método para obtener todos los reportes
    getReportes(): Promise<Reporte[]> {
        return firstValueFrom(this.reportes$).then(reportes => {
            if (reportes.length === 0) {
                return this.loadReportes();
            }
            return reportes;
        });
    }

    // Método para obtener un reporte por ID
    async getReporte(id: number): Promise<Reporte | undefined> {
        try {
            const headers = this.getAuthHeaders();
            return await firstValueFrom(
                this.http.get<Reporte>(`${this.apiUrl}/${id}`, { headers })
            );
        } catch (error) {
            console.error(`Error al obtener reporte con ID ${id}:`, error);
            throw error;
        }
    }

    // Método para crear un nuevo reporte
    async createReporte(reporte: Reporte): Promise<Reporte> {
        try {
            const headers = this.getAuthHeaders();
            const newReporte = await firstValueFrom(
                this.http.post<Reporte>(this.apiUrl, reporte, { headers })
            );
            await this.loadReportes(); // Recargar lista
            return newReporte;
        } catch (error) {
            console.error('Error al crear reporte:', error);
            throw error;
        }
    }

    // Método para actualizar un reporte existente
    async updateReporte(reporte: Reporte): Promise<Reporte> {
        if (!reporte.reporte_id) {
            throw new Error('El reporte debe tener un ID');
        }

        try {
            const headers = this.getAuthHeaders();
            const updatedReporte = await firstValueFrom(
                this.http.put<Reporte>(`${this.apiUrl}/${reporte.reporte_id}`, reporte, { headers })
            );
            await this.loadReportes(); // Recargar lista
            return updatedReporte;
        } catch (error) {
            console.error(`Error al actualizar reporte con ID ${reporte.reporte_id}:`, error);
            throw error;
        }
    }

    // Método para eliminar un reporte
    async deleteReporte(id: number): Promise<void> {
        try {
            const headers = this.getAuthHeaders();
            await firstValueFrom(
                this.http.delete(`${this.apiUrl}/${id}`, { headers })
            );
            await this.loadReportes(); // Recargar lista
        } catch (error) {
            console.error(`Error al eliminar reporte con ID ${id}:`, error);
            throw error;
        }
    }

    // Método para descargar un reporte en PDF, Excel, etc.
    async downloadReporte(id: number, formato: string): Promise<Blob> {
        try {
            const headers = this.getAuthHeaders();
            const response = await firstValueFrom(
                this.http.get(`${this.apiUrl}/${id}/download?formato=${formato}`, {
                    headers,
                    responseType: 'blob'
                })
            );
            return response;
        } catch (error) {
            console.error(`Error al descargar reporte con ID ${id}:`, error);
            throw error;
        }
    }

    // Métodos para datos estáticos (compatibilidad y fallback)
    getTiposReporte(): { label: string, value: string }[] {
        return [
            { label: 'Inventario', value: 'INVENTARIO' },
            { label: 'Ventas', value: 'VENTAS' },
            { label: 'Productos', value: 'PRODUCTOS' },
            { label: 'Empleados', value: 'EMPLEADOS' },
            { label: 'Bodegas', value: 'BODEGAS' }
        ];
    }

    getEstadosReporte(): { label: string, value: string }[] {
        return [
            { label: 'Pendiente', value: 'PENDIENTE' },
            { label: 'Generado', value: 'GENERADO' },
            { label: 'Error', value: 'ERROR' }
        ];
    }

    // Método para datos de demostración (solo para fallback)
    getDemoReportes(): Reporte[] {
        return [
            {
                reporte_id: 1,
                titulo: 'Reporte de Inventario Mensual',
                descripcion: 'Inventario total de todas las bodegas',
                tipo: 'INVENTARIO',
                fecha_creacion: new Date('2023-12-01'),
                usuario_id: 1,
                usuario: 'Admin',
                estado: 'GENERADO'
            },
            {
                reporte_id: 2,
                titulo: 'Ventas del Trimestre',
                descripcion: 'Análisis de ventas del último trimestre',
                tipo: 'VENTAS',
                fecha_creacion: new Date('2023-11-15'),
                usuario_id: 1,
                usuario: 'Admin',
                estado: 'GENERADO'
            },
            {
                reporte_id: 3,
                titulo: 'Productos con Bajo Stock',
                descripcion: 'Listado de productos con stock bajo',
                tipo: 'PRODUCTOS',
                fecha_creacion: new Date('2023-12-10'),
                usuario_id: 2,
                usuario: 'Supervisor',
                estado: 'PENDIENTE'
            }
        ];
    }

    // Manejo de errores
    private handleError(error: any) {
        let errorMessage = '';
        if (error.error instanceof ErrorEvent) {
            // Error del cliente
            errorMessage = `Error: ${error.error.message}`;
        } else {
            // Error del servidor
            errorMessage = `Código de error: ${error.status}\nMensaje: ${error.message}`;
        }
        console.error(errorMessage);
        return throwError(() => new Error(errorMessage));
    }
} 