import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { BehaviorSubject, Observable, firstValueFrom, throwError } from 'rxjs';

export interface Bodega {
    bodega_id?: number;
    nombre: string;
    direccion?: string;
    tipo: string;
    parent_bodega_id?: number | null;
    bodegas_hijas?: Bodega[];
    bodega_padre?: Bodega | null;
}

export interface BodegaResponse {
    items: Bodega[];
    total: number;
}

@Injectable({
    providedIn: 'root'
})
export class BodegaService {
    private apiUrl = `${environment.apiUrl}/bodegas`;
    private bodegasSource = new BehaviorSubject<Bodega[]>([]);
    bodegas$ = this.bodegasSource.asObservable();

    constructor(private http: HttpClient) {
        // Carga inicial de datos
        this.loadBodegas();
    }

    // Obtener el token desde el localStorage
    private getAuthHeaders(): HttpHeaders {
        const token = localStorage.getItem('access_token');
        return new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        });
    }

    // Método para cargar datos de bodegas desde la API
    async loadBodegas(): Promise<Bodega[]> {
        try {
            const headers = this.getAuthHeaders();
            const response = await firstValueFrom(
                this.http.get<BodegaResponse>(this.apiUrl, { headers })
            );
            
            const bodegas = Array.isArray(response) ? response : 
                            (response.items ? response.items : []);
            
            this.bodegasSource.next(bodegas);
            return bodegas;
        } catch (error) {
            console.error('Error al cargar bodegas:', error);
            // En caso de error, usar datos de demostración
            const demoBodegas = this.getDemoBodegas();
            this.bodegasSource.next(demoBodegas);
            return demoBodegas;
        }
    }

    // Método para obtener todas las bodegas
    getBodegas(): Promise<Bodega[]> {
        return firstValueFrom(this.bodegas$).then(bodegas => {
            if (bodegas.length === 0) {
                return this.loadBodegas();
            }
            return bodegas;
        });
    }

    // Método para obtener una bodega por ID
    async getBodega(id: number): Promise<Bodega | undefined> {
        try {
            const headers = this.getAuthHeaders();
            return await firstValueFrom(
                this.http.get<Bodega>(`${this.apiUrl}/${id}`, { headers })
            );
        } catch (error) {
            console.error(`Error al obtener bodega con ID ${id}:`, error);
            throw error;
        }
    }

    // Método para crear una nueva bodega
    async createBodega(bodega: Bodega): Promise<Bodega> {
        try {
            const headers = this.getAuthHeaders();
            const newBodega = await firstValueFrom(
                this.http.post<Bodega>(this.apiUrl, bodega, { headers })
            );
            await this.loadBodegas(); // Recargar lista
            return newBodega;
        } catch (error) {
            console.error('Error al crear bodega:', error);
            throw error;
        }
    }

    // Método para actualizar una bodega existente
    async updateBodega(bodega: Bodega): Promise<Bodega> {
        if (!bodega.bodega_id) {
            throw new Error('La bodega debe tener un ID');
        }

        try {
            const headers = this.getAuthHeaders();
            const updatedBodega = await firstValueFrom(
                this.http.put<Bodega>(`${this.apiUrl}/${bodega.bodega_id}`, bodega, { headers })
            );
            await this.loadBodegas(); // Recargar lista
            return updatedBodega;
        } catch (error) {
            console.error(`Error al actualizar bodega con ID ${bodega.bodega_id}:`, error);
            throw error;
        }
    }

    // Método para eliminar una bodega
    async deleteBodega(id: number): Promise<void> {
        try {
            const headers = this.getAuthHeaders();
            await firstValueFrom(
                this.http.delete(`${this.apiUrl}/${id}`, { headers })
            );
            await this.loadBodegas(); // Recargar lista
        } catch (error) {
            console.error(`Error al eliminar bodega con ID ${id}:`, error);
            throw error;
        }
    }

    // Métodos para datos estáticos (compatibilidad y fallback)
    getTiposBodega(): { label: string, value: string }[] {
        return [
            { label: 'Central', value: 'CENTRAL' },
            { label: 'Secundaria', value: 'SECUNDARIA' }
        ];
    }

    // Método para datos de demostración (solo para fallback)
    getDemoBodegas(): Bodega[] {
        return [
            {
                bodega_id: 1,
                nombre: 'Bodega Central',
                direccion: 'Av. Central 123',
                tipo: 'CENTRAL',
                parent_bodega_id: null
            },
            {
                bodega_id: 2,
                nombre: 'Bodega Secundaria Norte',
                direccion: 'Calle Norte 456',
                tipo: 'SECUNDARIA',
                parent_bodega_id: 1
            },
            {
                bodega_id: 3,
                nombre: 'Bodega Secundaria Sur',
                direccion: 'Plaza Central 789',
                tipo: 'SECUNDARIA',
                parent_bodega_id: 1
            }
        ];
    }

    // Manejo de errores
    private handleError(error: any) {
        let errorMessage = '';
        if (error.error instanceof ErrorEvent) {
            // Error del cliente
            errorMessage = `Error: ${error.error.message}`;
        } else {
            // Error del servidor
            errorMessage = `Código de error: ${error.status}\nMensaje: ${error.message}`;
        }
        console.error(errorMessage);
        return throwError(() => new Error(errorMessage));
    }
} 