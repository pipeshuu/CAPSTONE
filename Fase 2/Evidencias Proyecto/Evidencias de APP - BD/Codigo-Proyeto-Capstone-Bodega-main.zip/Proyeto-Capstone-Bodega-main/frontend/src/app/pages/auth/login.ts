import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { InputTextModule } from 'primeng/inputtext';
import { PasswordModule } from 'primeng/password';
import { RippleModule } from 'primeng/ripple';
import { MessageService } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { AppFloatingConfigurator } from '../../layout/component/app.floatingconfigurator';
import { AuthService } from '../../services/auth.service';

@Component({
    selector: 'app-login',
    standalone: true,
    imports: [
        ButtonModule,
        CheckboxModule,
        InputTextModule,
        PasswordModule,
        FormsModule,
        RouterModule,
        RippleModule,
        AppFloatingConfigurator,
        ToastModule
    ],
    providers: [MessageService],
    template: `
        <p-toast></p-toast>
        <app-floating-configurator />
        <div class="bg-surface-50 dark:bg-surface-950 flex items-center justify-center min-h-screen min-w-[100vw] overflow-hidden">
            <div class="flex flex-col items-center justify-center">
                <div style="border-radius: 56px; padding: 0.3rem; background: linear-gradient(180deg, var(--primary-color) 10%, rgba(33, 150, 243, 0) 30%)">
                    <div class="w-full bg-surface-0 dark:bg-surface-900 py-20 px-8 sm:px-20" style="border-radius: 53px">
                        <div class="text-center mb-8">
                        
                            <svg viewBox="0 0 200 200"  xmlns="http://www.w3.org/2000/svg" class="mb-8 w-16 shrink-0 mx-auto">
                                <!-- Estructura de bodega estilizada -->
                                <rect x="40" y="80" width="120" height="80" rx="4" fill="#2C3E50" />
                                <!-- Techo de líneas firmes -->
                                <path d="M40 80 L100 40 L160 80" fill="#34495E" />
                                 <!-- Puerta central -->
                               <rect x="90" y="120" width="20" height="40" rx="2" fill="#BDC3C7" />
                                 <!-- Líneas de fachada (más corporativo) -->
                               <line x1="60" y1="80" x2="60" y2="160" stroke="#ECF0F1" stroke-width="2" />
                                  <line x1="140" y1="80" x2="140" y2="160" stroke="#ECF0F1" stroke-width="2" />
                                 <!-- Línea de base -->
                                 <line x1="40" y1="160" x2="160" y2="160" stroke="#ECF0F1" stroke-width="2" />
                            </svg>
                            <div class="text-surface-900 dark:text-surface-0 text-3xl font-medium mb-4">Bienvenido a Bodega !</div>
                            <span class="text-muted-color font-medium">Inicia sesión para continuar</span>
                        </div>

                        <div>
                            <label for="username1" class="block text-surface-900 dark:text-surface-0 text-xl font-medium mb-2">Usuario</label>
                            <input pInputText id="username1" type="text" placeholder="Nombre de usuario" class="w-full md:w-[30rem] mb-8" [(ngModel)]="username" />

                            <label for="password1" class="block text-surface-900 dark:text-surface-0 font-medium text-xl mb-2">Contraseña</label>
                            <p-password id="password1" [(ngModel)]="password" placeholder="Contraseña" [toggleMask]="true" styleClass="mb-4" [fluid]="true" [feedback]="false"></p-password>

                            <div class="flex items-center justify-between mt-2 mb-8 gap-8">
                                <div class="flex items-center">
                                    <p-checkbox [(ngModel)]="checked" id="rememberme1" binary class="mr-2"></p-checkbox>
                                    <label for="rememberme1">Recordarme</label>
                                </div>
                                <span class="font-medium no-underline ml-2 text-right cursor-pointer text-primary">                     </span>
                            </div>
                            <p-button label="Iniciar Sesión" styleClass="w-full" (onClick)="onLogin()"></p-button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `
})
export class Login {
    username: string = '';
    password: string = '';
    checked: boolean = false;

    constructor(
        private authService: AuthService,
        private messageService: MessageService,
        private router: Router
    ) {}

    onLogin(): void {
        if (!this.username || !this.password) {
            this.messageService.add({
                severity: 'error',
                summary: 'Error',
                detail: 'Por favor ingresa tu usuario y contraseña'
            });
            return;
        }

        this.authService.login(this.username, this.password).subscribe({
            next: () => {
                this.messageService.add({
                    severity: 'success',
                    summary: 'Éxito',
                    detail: 'Inicio de sesión exitoso'
                });
                this.router.navigate(['/dashboard']);
            },
            error: (error) => {
                this.messageService.add({
                    severity: 'error',
                    summary: 'Error',
                    detail: error.error?.detail || 'Error al iniciar sesión'
                });
            }
        });
    }
}
