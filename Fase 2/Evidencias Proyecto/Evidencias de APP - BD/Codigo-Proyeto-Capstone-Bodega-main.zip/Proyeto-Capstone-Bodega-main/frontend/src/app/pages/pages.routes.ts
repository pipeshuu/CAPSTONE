import { Routes } from '@angular/router';
import { Documentation } from './documentation/documentation';
import { Crud } from './crud/crud';
import { Empty } from './empty/empty';
import { Profile } from './profile/profile';
import { Productos } from './productos/productos';
import { Inventario } from './inventario/inventario';
import { Bodegas } from './bodegas/bodegas';
import { Empleados } from './empleados/empleados';
import { Reportes } from './reportes/reportes';
import { Solicitudes } from './solicitudes/solicitudes';
import { Envios } from './envios/envios';

export default [
    { path: 'documentation', component: Documentation },
    { path: 'crud', component: Crud },
    { path: 'productos', component: Productos },
    { path: 'inventario', component: Inventario },
    { path: 'bodegas', component: Bodegas },
    { path: 'empleados', component: Empleados },
    { path: 'reportes', component: Reportes },
    { path: 'solicitudes', component: Solicitudes },
    { path: 'envios', component: Envios },
    { path: 'empty', component: Empty },
    { path: 'profile', component: Profile },
    { path: '**', redirectTo: '/notfound' }
] as Routes;
