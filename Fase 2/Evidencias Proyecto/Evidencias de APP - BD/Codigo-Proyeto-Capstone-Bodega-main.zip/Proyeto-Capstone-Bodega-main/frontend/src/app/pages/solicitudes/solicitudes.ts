import { Component, OnInit, signal, ViewChild } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Table, TableModule } from 'primeng/table';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { RippleModule } from 'primeng/ripple';
import { ToastModule } from 'primeng/toast';
import { ToolbarModule } from 'primeng/toolbar';
import { InputTextModule } from 'primeng/inputtext';
import { TextareaModule } from 'primeng/textarea';
import { SelectModule } from 'primeng/select';
import { RadioButtonModule } from 'primeng/radiobutton';
import { InputNumberModule } from 'primeng/inputnumber';
import { DialogModule } from 'primeng/dialog';
import { TagModule } from 'primeng/tag';
import { InputIconModule } from 'primeng/inputicon';
import { IconFieldModule } from 'primeng/iconfield';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { DropdownModule } from 'primeng/dropdown';
import { SplitButtonModule } from 'primeng/splitbutton';
import { CalendarModule } from 'primeng/calendar';
import { TableModule as TableNgModule } from 'primeng/table';
import { Solicitud, SolicitudItem, SolicitudService } from '../../services/solicitud.service';
import { BodegaService } from '../../services/bodega.service';

interface Column {
    field: string;
    header: string;
    customExportHeader?: string;
}

interface ExportColumn {
    title: string;
    dataKey: string;
}

@Component({
    selector: 'app-solicitudes',
    standalone: true,
    imports: [
        CommonModule,
        TableModule,
        FormsModule,
        ButtonModule,
        RippleModule,
        ToastModule,
        ToolbarModule,
        InputTextModule,
        TextareaModule,
        SelectModule,
        RadioButtonModule,
        InputNumberModule,
        DialogModule,
        TagModule,
        InputIconModule,
        IconFieldModule,
        ConfirmDialogModule,
        DropdownModule,
        SplitButtonModule,
        CalendarModule,
        TableNgModule
    ],
    providers: [MessageService, ConfirmationService, DatePipe],
    template: `
        <p-toast></p-toast>
        
        <p-toolbar styleClass="mb-6">
            <ng-template #start>
                <p-button label="Nueva" icon="pi pi-plus" severity="secondary" class="mr-2" (onClick)="openNew()" />
                <p-button severity="secondary" label="Eliminar" icon="pi pi-trash" outlined (onClick)="deleteSelectedSolicitudes()" [disabled]="!selectedSolicitudes || !selectedSolicitudes.length" />
            </ng-template>

            <ng-template #end>
                <p-button label="Exportar" icon="pi pi-upload" severity="secondary" (onClick)="exportCSV()" />
            </ng-template>
        </p-toolbar>

        <p-table
            #dt
            [value]="solicitudes()"
            [rows]="10"
            [columns]="cols"
            [paginator]="true"
            [globalFilterFields]="['solicitud_id', 'fecha_creacion', 'estado', 'prioridad', 'justificacion']"
            [tableStyle]="{ 'min-width': '75rem' }"
            [(selection)]="selectedSolicitudes"
            [rowHover]="true"
            dataKey="solicitud_id"
            currentPageReportTemplate="Mostrando {first} a {last} de {totalRecords} solicitudes"
            [showCurrentPageReport]="true"
            [rowsPerPageOptions]="[10, 20, 30]"
            [loading]="loading"
        >
            <ng-template #caption>
                <div class="flex items-center justify-between">
                    <h5 class="m-0">Gestión de Solicitudes</h5>
                    <p-iconfield>
                        <p-inputicon styleClass="pi pi-search" />
                        <input pInputText type="text" (input)="onGlobalFilter(dt, $event)" placeholder="Buscar..." />
                    </p-iconfield>
                </div>
            </ng-template>
            <ng-template #header>
                <tr>
                    <th style="width: 3rem">
                        <p-tableHeaderCheckbox />
                    </th>
                    <th pSortableColumn="solicitud_id" style="min-width: 4rem">
                        ID
                        <p-sortIcon field="solicitud_id" />
                    </th>
                    <th pSortableColumn="fecha_creacion" style="min-width: 8rem">
                        Fecha
                        <p-sortIcon field="fecha_creacion" />
                    </th>
                    <th pSortableColumn="bodega_origen" style="min-width: 10rem">
                        Origen
                        <p-sortIcon field="bodega_origen" />
                    </th>
                    <th pSortableColumn="bodega_destino" style="min-width: 10rem">
                        Destino
                        <p-sortIcon field="bodega_destino" />
                    </th>
                    <th pSortableColumn="prioridad" style="min-width: 6rem">
                        Prioridad
                        <p-sortIcon field="prioridad" />
                    </th>
                    <th pSortableColumn="estado" style="min-width: 6rem">
                        Estado
                        <p-sortIcon field="estado" />
                    </th>
                    <th style="min-width: 10rem"></th>
                </tr>
            </ng-template>
            <ng-template #body let-solicitud>
                <tr>
                    <td style="width: 3rem">
                        <p-tableCheckbox [value]="solicitud" />
                    </td>
                    <td style="min-width: 4rem">{{ solicitud.solicitud_id }}</td>
                    <td style="min-width: 8rem">{{ solicitud.fecha_creacion | date:'dd/MM/yyyy' }}</td>
                    <td style="min-width: 10rem">{{ getBodegaNombre(solicitud.bodega_origen_id) }}</td>
                    <td style="min-width: 10rem">{{ getBodegaNombre(solicitud.bodega_destino_id) }}</td>
                    <td style="min-width: 6rem">
                        <p-tag [value]="solicitud.prioridad" [severity]="getPrioridadSeverity(solicitud.prioridad)" />
                    </td>
                    <td style="min-width: 6rem">
                        <p-tag [value]="solicitud.estado" [severity]="getEstadoSeverity(solicitud.estado)" />
                    </td>
                    <td>
                        <p-splitButton label="Acciones" icon="pi pi-cog" [model]="getAccionesItems(solicitud)" styleClass="p-button-sm"></p-splitButton>
                    </td>
                </tr>
            </ng-template>
        </p-table>

        <!-- Diálogo para crear/editar solicitud -->
        <p-dialog [(visible)]="solicitudDialog" [style]="{ width: '700px' }" header="Detalles de Solicitud" [modal]="true">
            <ng-template #content>
                <div class="flex flex-col gap-6">
                    <div class="grid grid-cols-12 gap-4">
                        <div class="col-span-6">
                            <label for="bodega_origen_id" class="block font-bold mb-3">Bodega Origen</label>
                            <p-dropdown [(ngModel)]="solicitud.bodega_origen_id" 
                                       [options]="bodegas" 
                                       optionLabel="label" 
                                       optionValue="value" 
                                       placeholder="Seleccione Bodega" 
                                       [style]="{'width':'100%'}" 
                                       [filter]="true" 
                                       filterBy="label" 
                                       [showClear]="false" 
                                       appendTo="body" 
                                       required>
                            </p-dropdown>
                            <small class="text-red-500" *ngIf="submitted && !solicitud.bodega_origen_id">Bodega origen es requerida.</small>
                        </div>
                        <div class="col-span-6">
                            <label for="bodega_destino_id" class="block font-bold mb-3">Bodega Destino</label>
                            <p-dropdown [(ngModel)]="solicitud.bodega_destino_id" 
                                       [options]="bodegas" 
                                       optionLabel="label" 
                                       optionValue="value" 
                                       placeholder="Seleccione Bodega" 
                                       [style]="{'width':'100%'}" 
                                       [filter]="true" 
                                       filterBy="label" 
                                       [showClear]="false" 
                                       appendTo="body" 
                                       required>
                            </p-dropdown>
                            <small class="text-red-500" *ngIf="submitted && !solicitud.bodega_destino_id">Bodega destino es requerida.</small>
                        </div>
                    </div>

                    <div class="grid grid-cols-12 gap-4">
                        <div class="col-span-6">
                            <label for="prioridad" class="block font-bold mb-3">Prioridad</label>
                            <p-dropdown [(ngModel)]="solicitud.prioridad" 
                                       [options]="prioridadesSolicitud" 
                                       optionLabel="label" 
                                       optionValue="value" 
                                       placeholder="Seleccione Prioridad" 
                                       [style]="{'width':'100%'}" 
                                       [showClear]="false" 
                                       appendTo="body" 
                                       required>
                            </p-dropdown>
                            <small class="text-red-500" *ngIf="submitted && !solicitud.prioridad">Prioridad es requerida.</small>
                        </div>
                        <div class="col-span-6">
                            <label for="estado" class="block font-bold mb-3">Estado</label>
                            <p-dropdown [(ngModel)]="solicitud.estado" 
                                       [options]="estadosSolicitud" 
                                       optionLabel="label" 
                                       optionValue="value" 
                                       placeholder="Seleccione Estado" 
                                       [style]="{'width':'100%'}" 
                                       [showClear]="false" 
                                       appendTo="body" 
                                       [disabled]="solicitud.solicitud_id ? true : false"
                                       required>
                            </p-dropdown>
                            <small class="text-red-500" *ngIf="submitted && !solicitud.estado">Estado es requerido.</small>
                        </div>
                    </div>

                    <div class="grid grid-cols-12 gap-4">
                        <div class="col-span-12">
                            <label for="justificacion" class="block font-bold mb-3">Justificación</label>
                            <textarea pInputTextarea id="justificacion" [(ngModel)]="solicitud.justificacion" rows="3" class="w-full"></textarea>
                        </div>
                    </div>

                    <div class="grid grid-cols-12 gap-4">
                        <div class="col-span-12">
                            <div class="flex justify-between items-center mb-3">
                                <label class="font-bold">Productos Solicitados</label>
                                <p-button icon="pi pi-plus" label="Agregar" severity="secondary" (onClick)="openNewItem()"></p-button>
                            </div>
                            <p-table [value]="solicitud.items" [tableStyle]="{'min-width': '50rem'}"
                                    [paginator]="solicitud.items.length > 5" [rows]="5" 
                                    [(selection)]="selectedItems" dataKey="item_id">
                                <ng-template pTemplate="header">
                                    <tr>
                                        <th style="width: 3rem">
                                            <p-tableHeaderCheckbox></p-tableHeaderCheckbox>
                                        </th>
                                        <th>Producto</th>
                                        <th>Cantidad</th>
                                        <th>Observación</th>
                                        <th style="width: 5rem"></th>
                                    </tr>
                                </ng-template>
                                <ng-template pTemplate="body" let-item>
                                    <tr>
                                        <td>
                                            <p-tableCheckbox [value]="item"></p-tableCheckbox>
                                        </td>
                                        <td>{{ getProductoNombre(item.producto_id) }}</td>
                                        <td>{{ item.cantidad }}</td>
                                        <td>{{ item.observacion }}</td>
                                        <td>
                                            <button pButton pRipple icon="pi pi-trash" 
                                                    class="p-button-rounded p-button-danger p-button-text" 
                                                    (click)="deleteItem(item)"></button>
                                        </td>
                                    </tr>
                                </ng-template>
                                <ng-template pTemplate="emptymessage">
                                    <tr>
                                        <td colspan="5" class="text-center p-4">No hay productos agregados.</td>
                                    </tr>
                                </ng-template>
                            </p-table>
                        </div>
                    </div>
                </div>
            </ng-template>

            <ng-template #footer>
                <p-button label="Cancelar" icon="pi pi-times" text (click)="hideDialog()" />
                <p-button label="Guardar" icon="pi pi-check" (click)="saveSolicitud()" />
            </ng-template>
        </p-dialog>

        <!-- Diálogo para agregar/editar un ítem de solicitud -->
        <p-dialog [(visible)]="itemDialog" [style]="{ width: '500px' }" header="Agregar Producto" [modal]="true">
            <ng-template #content>
                <div class="flex flex-col gap-6">
                    <div class="grid grid-cols-12 gap-4">
                        <div class="col-span-12">
                            <label for="producto_id" class="block font-bold mb-3">Producto</label>
                            <p-dropdown [(ngModel)]="solicitudItem.producto_id" 
                                      [options]="productos" 
                                      optionLabel="label" 
                                      optionValue="value" 
                                      placeholder="Seleccione Producto" 
                                      [style]="{'width':'100%'}" 
                                      [filter]="true" 
                                      filterBy="label" 
                                      [showClear]="false" 
                                      appendTo="body" 
                                      required>
                            </p-dropdown>
                            <small class="text-red-500" *ngIf="submittedItem && !solicitudItem.producto_id">Producto es requerido.</small>
                        </div>
                    </div>

                    <div class="grid grid-cols-12 gap-4">
                        <div class="col-span-12">
                            <label for="cantidad" class="block font-bold mb-3">Cantidad</label>
                            <p-inputNumber [(ngModel)]="solicitudItem.cantidad" 
                                         [showButtons]="true" 
                                         [min]="1" 
                                         [step]="1"
                                         decrementButtonClass="p-button-danger" 
                                         incrementButtonClass="p-button-success" 
                                         incrementButtonIcon="pi pi-plus" 
                                         decrementButtonIcon="pi pi-minus" 
                                         class="w-full"
                                         required>
                            </p-inputNumber>
                            <small class="text-red-500" *ngIf="submittedItem && solicitudItem.cantidad <= 0">Cantidad debe ser mayor a 0.</small>
                        </div>
                    </div>

                    <div class="grid grid-cols-12 gap-4">
                        <div class="col-span-12">
                            <label for="observacion" class="block font-bold mb-3">Observación</label>
                            <textarea pInputTextarea id="observacion" [(ngModel)]="solicitudItem.observacion" rows="3" class="w-full"></textarea>
                        </div>
                    </div>
                </div>
            </ng-template>

            <ng-template #footer>
                <p-button label="Cancelar" icon="pi pi-times" text (click)="hideItemDialog()" />
                <p-button label="Guardar" icon="pi pi-check" (click)="saveItem()" />
            </ng-template>
        </p-dialog>

        <p-confirmdialog [style]="{ width: '450px' }" />
    `
})
export class Solicitudes implements OnInit {
    solicitudDialog: boolean = false;
    detalleDialog: boolean = false;
    aprobarDialog: boolean = false;
    itemDialog: boolean = false;
    
    solicitudes = signal<Solicitud[]>([]);
    
    solicitud: Solicitud = {
        bodega_origen_id: 0,
        bodega_destino_id: 0,
        estado: 'PENDIENTE',
        prioridad: 'MEDIA',
        items: []
    };

    solicitudItem: SolicitudItem = {
        producto_id: 0,
        cantidad: 1
    };

    selectedSolicitudes: Solicitud[] | null = null;
    selectedItems: SolicitudItem[] | null = null;
    
    bodegas: any[] = [];
    productos: any[] = [];
    estadosSolicitud: any[] = [];
    prioridadesSolicitud: any[] = [];

    submitted: boolean = false;
    submittedItem: boolean = false;
    loading: boolean = true;
    
    @ViewChild('dt') dt!: Table;

    exportColumns!: ExportColumn[];
    cols!: Column[];

    constructor(
        private solicitudService: SolicitudService,
        private bodegaService: BodegaService,
        private messageService: MessageService,
        private confirmationService: ConfirmationService,
        private datePipe: DatePipe
    ) {}

    exportCSV() {
        this.dt.exportCSV();
    }

    ngOnInit() {
        this.loadData();
        this.loadBodegas();
        this.estadosSolicitud = this.solicitudService.getEstadosSolicitud();
        this.prioridadesSolicitud = this.solicitudService.getPrioridadesSolicitud();

        this.cols = [
            { field: 'solicitud_id', header: 'ID' },
            { field: 'fecha_creacion', header: 'Fecha' },
            { field: 'bodega_origen_id', header: 'Origen' },
            { field: 'bodega_destino_id', header: 'Destino' },
            { field: 'prioridad', header: 'Prioridad' },
            { field: 'estado', header: 'Estado' }
        ];

        this.exportColumns = this.cols.map((col) => ({ title: col.header, dataKey: col.field }));
    }

    loadData() {
        this.loading = true;
        this.solicitudService.getSolicitudes()
            .then(data => {
                this.solicitudes.set(data);
                this.loading = false;
            })
            .catch(error => {
                console.error('Error al cargar solicitudes:', error);
                this.messageService.add({ 
                    severity: 'error', 
                    summary: 'Error', 
                    detail: 'Error al cargar solicitudes', 
                    life: 3000 
                });
                this.loading = false;
            });
    }

    loadBodegas() {
        this.bodegaService.getBodegas()
            .then(bodegas => {
                this.bodegas = bodegas.map(bodega => ({
                    label: bodega.nombre,
                    value: bodega.bodega_id
                }));
            })
            .catch(error => {
                console.error('Error al cargar bodegas:', error);
            });
    }

    onGlobalFilter(table: Table, event: Event) {
        table.filterGlobal((event.target as HTMLInputElement).value, 'contains');
    }

    openNew() {
        this.solicitud = {
            bodega_origen_id: 0,
            bodega_destino_id: 0,
            estado: 'PENDIENTE',
            prioridad: 'MEDIA',
            items: []
        };
        this.submitted = false;
        this.solicitudDialog = true;
    }

    openNewItem() {
        this.solicitudItem = {
            producto_id: 0,
            cantidad: 1
        };
        this.submittedItem = false;
        this.itemDialog = true;
    }

    hideDialog() {
        this.solicitudDialog = false;
        this.submitted = false;
    }

    hideItemDialog() {
        this.itemDialog = false;
        this.submittedItem = false;
    }

    editSolicitud(solicitud: Solicitud) {
        this.solicitud = { ...solicitud };
        this.solicitudDialog = true;
    }

    deleteSelectedSolicitudes() {
        this.confirmationService.confirm({
            message: '¿Está seguro de eliminar las solicitudes seleccionadas?',
            header: 'Confirmar',
            icon: 'pi pi-exclamation-triangle',
            accept: () => {
                if (this.selectedSolicitudes && this.selectedSolicitudes.length > 0) {
                    const deletePromises = this.selectedSolicitudes
                        .filter(solicitud => solicitud.solicitud_id)
                        .map(solicitud => this.solicitudService.deleteSolicitud(solicitud.solicitud_id!));
                    
                    Promise.all(deletePromises)
                        .then(() => {
                            this.loadData();
                            this.messageService.add({ 
                                severity: 'success', 
                                summary: 'Éxito', 
                                detail: 'Solicitudes eliminadas correctamente', 
                                life: 3000 
                            });
                            this.selectedSolicitudes = null;
                        })
                        .catch(error => {
                            console.error('Error al eliminar solicitudes:', error);
                            this.messageService.add({ 
                                severity: 'error', 
                                summary: 'Error', 
                                detail: 'No se pudieron eliminar todas las solicitudes', 
                                life: 3000 
                            });
                        });
                }
            }
        });
    }

    deleteSolicitud(solicitud: Solicitud) {
        this.confirmationService.confirm({
            message: `¿Está seguro de eliminar la solicitud #${solicitud.solicitud_id}?`,
            header: 'Confirmar',
            icon: 'pi pi-exclamation-triangle',
            accept: () => {
                if (solicitud.solicitud_id) {
                    this.solicitudService.deleteSolicitud(solicitud.solicitud_id)
                        .then(() => {
                            this.loadData();
                            this.messageService.add({ 
                                severity: 'success', 
                                summary: 'Éxito', 
                                detail: 'Solicitud eliminada correctamente', 
                                life: 3000 
                            });
                        })
                        .catch(error => {
                            console.error('Error al eliminar solicitud:', error);
                            this.messageService.add({ 
                                severity: 'error', 
                                summary: 'Error', 
                                detail: 'No se pudo eliminar la solicitud', 
                                life: 3000 
                            });
                        });
                }
            }
        });
    }

    deleteItem(item: SolicitudItem) {
        this.confirmationService.confirm({
            message: '¿Está seguro de eliminar este producto?',
            header: 'Confirmar',
            icon: 'pi pi-exclamation-triangle',
            accept: () => {
                this.solicitud.items = this.solicitud.items.filter(i => i !== item);
                this.messageService.add({ severity: 'success', summary: 'Éxito', detail: 'Producto eliminado', life: 3000 });
            }
        });
    }

    saveItem() {
        this.submittedItem = true;

        if (!this.solicitudItem.producto_id || this.solicitudItem.cantidad <= 0) {
            return;
        }

        if (this.solicitudItem.item_id) {
            // Actualizar item existente
            const index = this.findItemIndexById(this.solicitudItem.item_id);
            if (index >= 0) {
                this.solicitud.items[index] = { ...this.solicitudItem };
            }
        } else {
            // Crear nuevo item
            // Generar un ID temporal negativo para identificación en el frontend
            this.solicitudItem.item_id = -(this.solicitud.items.length + 1);
            this.solicitud.items.push({ ...this.solicitudItem });
        }

        this.hideItemDialog();
    }

    saveSolicitud() {
        this.submitted = true;

        if (!this.solicitud.bodega_origen_id || !this.solicitud.bodega_destino_id || 
            !this.solicitud.estado || !this.solicitud.prioridad || this.solicitud.items.length === 0) {
            this.messageService.add({ 
                severity: 'error', 
                summary: 'Error', 
                detail: 'Complete todos los campos obligatorios y agregue al menos un producto', 
                life: 3000 
            });
            return;
        }

        const saveOperation = this.solicitud.solicitud_id
            ? this.solicitudService.updateSolicitud(this.solicitud)
            : this.solicitudService.createSolicitud(this.solicitud);

        saveOperation
            .then(() => {
                this.loadData();
                this.messageService.add({ 
                    severity: 'success', 
                    summary: 'Éxito', 
                    detail: `Solicitud ${this.solicitud.solicitud_id ? 'actualizada' : 'creada'} correctamente`, 
                    life: 3000 
                });
                this.hideDialog();
            })
            .catch(error => {
                console.error('Error al guardar solicitud:', error);
                this.messageService.add({ 
                    severity: 'error', 
                    summary: 'Error', 
                    detail: `No se pudo ${this.solicitud.solicitud_id ? 'actualizar' : 'crear'} la solicitud`, 
                    life: 3000 
                });
            });
    }

    findItemIndexById(id: number) {
        return this.solicitud.items.findIndex(item => item.item_id === id);
    }

    getBodegaNombre(id: number): string {
        const bodega = this.bodegas.find(b => b.value === id);
        return bodega ? bodega.label : `Bodega #${id}`;
    }

    getProductoNombre(id: number): string {
        const producto = this.productos.find(p => p.value === id);
        return producto ? producto.label : `Producto #${id}`;
    }

    getPrioridadSeverity(prioridad: string): 'success' | 'info' | 'warn' | 'danger' | 'secondary' | 'contrast' | undefined {
        switch (prioridad) {
            case 'BAJA':
                return 'success';
            case 'MEDIA':
                return 'info';
            case 'ALTA':
                return 'warn';
            case 'URGENTE':
                return 'danger';
            default:
                return 'info';
        }
    }

    getEstadoSeverity(estado: string): 'success' | 'info' | 'warn' | 'danger' | 'secondary' | 'contrast' | undefined {
        switch (estado) {
            case 'PENDIENTE':
                return 'info';
            case 'APROBADA':
                return 'success';
            case 'RECHAZADA':
                return 'danger';
            case 'CANCELADA':
                return 'secondary';
            case 'COMPLETADA':
                return 'contrast';
            default:
                return 'info';
        }
    }

    getAccionesItems(solicitud: Solicitud) {
        const items: {label: string, icon: string, command: () => void, separator?: boolean}[] = [
            {
                label: 'Ver Detalles',
                icon: 'pi pi-eye',
                command: () => {
                    this.verDetalles(solicitud);
                }
            },
            {
                label: 'Editar',
                icon: 'pi pi-pencil',
                command: () => {
                    this.editSolicitud(solicitud);
                }
            },
            {
                label: 'Eliminar',
                icon: 'pi pi-trash',
                command: () => {
                    this.deleteSolicitud(solicitud);
                }
            }
        ];

        // Agregar acciones específicas según el estado
        if (solicitud.estado === 'PENDIENTE') {
            items.push(
                {
                    separator: true,
                    label: '',
                    icon: '',
                    command: () => {}
                },
                {
                    label: 'Aprobar',
                    icon: 'pi pi-check',
                    command: () => {
                        this.aprobarSolicitud(solicitud);
                    }
                },
                {
                    label: 'Rechazar',
                    icon: 'pi pi-times',
                    command: () => {
                        this.rechazarSolicitud(solicitud);
                    }
                }
            );
        }

        return items;
    }

    verDetalles(solicitud: Solicitud) {
        // Implementación pendiente
        console.log('Ver detalles de solicitud', solicitud);
    }

    aprobarSolicitud(solicitud: Solicitud) {
        // Implementación pendiente
        console.log('Aprobar solicitud', solicitud);
    }

    rechazarSolicitud(solicitud: Solicitud) {
        // Implementación pendiente
        console.log('Rechazar solicitud', solicitud);
    }
} 