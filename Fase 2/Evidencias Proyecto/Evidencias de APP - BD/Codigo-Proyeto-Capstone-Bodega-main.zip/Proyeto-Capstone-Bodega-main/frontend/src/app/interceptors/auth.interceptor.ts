import { HttpInterceptorFn, HttpErrorResponse } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';
import { AuthService } from '../services/auth.service';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const authService = inject(AuthService);
  const router = inject(Router);
  const token = authService.getToken();
  
  // Verificamos si el token ya expiró antes de enviar la solicitud
  if (token && authService.isTokenExpired()) {
    // Si el token está expirado, redirigimos al login
    router.navigate(['/auth/login']);
    return next(req);
  }
  
  // Para solicitudes a la API, agregamos el token de autenticación
  if (token && (req.url.includes(window.location.hostname) || req.url.includes('localhost'))) {
    const authReq = req.clone({
      headers: req.headers.set('Authorization', `Bearer ${token}`)
    });
    
    return next(authReq).pipe(
      catchError((error: HttpErrorResponse) => {
        // Si recibimos un 401 Unauthorized, es posible que el token haya expirado
        if (error.status === 401) {
          // Borramos el token y redirigimos al login
          authService.logout();
          router.navigate(['/auth/login']);
        }
        return throwError(() => error);
      })
    );
  }
  
  // Para otras solicitudes, pasamos sin modificar
  return next(req);
}; 