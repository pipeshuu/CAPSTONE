import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { BehaviorSubject, Observable, firstValueFrom, throwError } from 'rxjs';

export interface Empleado {
    empleado_id?: number;
    nombre: string;
    apellidos: string;
    cedula: string;
    telefono?: string;
    email?: string;
    cargo: string;
    bodega_id?: number | null;
    bodega?: any;
    activo: boolean;
    usuario_id?: string;
    usuario_sistema?: string;
}

export interface EmpleadoResponse {
    items: Empleado[];
    total: number;
}

@Injectable({
    providedIn: 'root'
})
export class EmpleadoService {
    private apiUrl = `${environment.apiUrl}/empleados`;
    private empleadosSource = new BehaviorSubject<Empleado[]>([]);
    empleados$ = this.empleadosSource.asObservable();

    constructor(private http: HttpClient) {
        // Carga inicial de datos
        this.loadEmpleados();
    }

    // Obtener el token desde el localStorage
    private getAuthHeaders(): HttpHeaders {
        const token = localStorage.getItem('access_token');
        return new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        });
    }

    // Método para cargar datos de empleados desde la API
    async loadEmpleados(): Promise<Empleado[]> {
        try {
            const headers = this.getAuthHeaders();
            const response = await firstValueFrom(
                this.http.get<EmpleadoResponse>(this.apiUrl, { headers })
            );
            
            const empleados = Array.isArray(response) ? response : 
                            (response.items ? response.items : []);
            
            this.empleadosSource.next(empleados);
            return empleados;
        } catch (error) {
            console.error('Error al cargar empleados:', error);
            // En caso de error, usar datos de demostración
            const demoEmpleados = this.getDemoEmpleados();
            this.empleadosSource.next(demoEmpleados);
            return demoEmpleados;
        }
    }

    // Método para obtener todos los empleados
    getEmpleados(): Promise<Empleado[]> {
        return firstValueFrom(this.empleados$).then(empleados => {
            if (empleados.length === 0) {
                return this.loadEmpleados();
            }
            return empleados;
        });
    }

    // Método para obtener un empleado por ID
    async getEmpleado(id: number): Promise<Empleado | undefined> {
        try {
            const headers = this.getAuthHeaders();
            return await firstValueFrom(
                this.http.get<Empleado>(`${this.apiUrl}/${id}`, { headers })
            );
        } catch (error) {
            console.error(`Error al obtener empleado con ID ${id}:`, error);
            throw error;
        }
    }

    // Método para crear un nuevo empleado
    async createEmpleado(empleado: Empleado): Promise<Empleado> {
        try {
            const headers = this.getAuthHeaders();
            const newEmpleado = await firstValueFrom(
                this.http.post<Empleado>(this.apiUrl, empleado, { headers })
            );
            await this.loadEmpleados(); // Recargar lista
            return newEmpleado;
        } catch (error) {
            console.error('Error al crear empleado:', error);
            throw error;
        }
    }

    // Método para actualizar un empleado existente
    async updateEmpleado(empleado: Empleado): Promise<Empleado> {
        if (!empleado.empleado_id) {
            throw new Error('El empleado debe tener un ID');
        }

        try {
            const headers = this.getAuthHeaders();
            const updatedEmpleado = await firstValueFrom(
                this.http.put<Empleado>(`${this.apiUrl}/${empleado.empleado_id}`, empleado, { headers })
            );
            await this.loadEmpleados(); // Recargar lista
            return updatedEmpleado;
        } catch (error) {
            console.error(`Error al actualizar empleado con ID ${empleado.empleado_id}:`, error);
            throw error;
        }
    }

    // Método para eliminar un empleado
    async deleteEmpleado(id: number): Promise<void> {
        try {
            const headers = this.getAuthHeaders();
            await firstValueFrom(
                this.http.delete(`${this.apiUrl}/${id}`, { headers })
            );
            await this.loadEmpleados(); // Recargar lista
        } catch (error) {
            console.error(`Error al eliminar empleado con ID ${id}:`, error);
            throw error;
        }
    }

    // Métodos para datos estáticos (compatibilidad y fallback)
    getCargos(): { label: string, value: string }[] {
        return [
            { label: 'Gerente', value: 'GERENTE' },
            { label: 'Supervisor', value: 'SUPERVISOR' },
            { label: 'Vendedor', value: 'VENDEDOR' },
            { label: 'Almacenista', value: 'ALMACENISTA' },
            { label: 'Administrativo', value: 'ADMINISTRATIVO' },
            { label: 'Otro', value: 'OTRO' }
        ];
    }

    // Método para datos de demostración (solo para fallback)
    getDemoEmpleados(): Empleado[] {
        return [
            {
                empleado_id: 1,
                nombre: 'Juan',
                apellidos: 'Pérez',
                cedula: '12345678',
                telefono: '555-1234',
                email: 'juan.perez@ejemplo.com',
                cargo: 'GERENTE',
                bodega_id: 1,
                activo: true
            },
            {
                empleado_id: 2,
                nombre: 'María',
                apellidos: 'González',
                cedula: '87654321',
                telefono: '555-5678',
                email: 'maria.gonzalez@ejemplo.com',
                cargo: 'SUPERVISOR',
                bodega_id: 2,
                activo: true
            },
            {
                empleado_id: 3,
                nombre: 'Carlos',
                apellidos: 'Rodríguez',
                cedula: '23456789',
                telefono: '555-9012',
                email: 'carlos.rodriguez@ejemplo.com',
                cargo: 'VENDEDOR',
                bodega_id: 3,
                activo: false
            }
        ];
    }

    // Manejo de errores
    private handleError(error: any) {
        let errorMessage = '';
        if (error.error instanceof ErrorEvent) {
            // Error del cliente
            errorMessage = `Error: ${error.error.message}`;
        } else {
            // Error del servidor
            errorMessage = `Código de error: ${error.status}\nMensaje: ${error.message}`;
        }
        console.error(errorMessage);
        return throwError(() => new Error(errorMessage));
    }
} 