import { Component, OnInit, signal, ViewChild } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Table, TableModule } from 'primeng/table';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { RippleModule } from 'primeng/ripple';
import { ToastModule } from 'primeng/toast';
import { ToolbarModule } from 'primeng/toolbar';
import { InputTextModule } from 'primeng/inputtext';
import { TextareaModule } from 'primeng/textarea';
import { SelectModule } from 'primeng/select';
import { RadioButtonModule } from 'primeng/radiobutton';
import { InputNumberModule } from 'primeng/inputnumber';
import { DialogModule } from 'primeng/dialog';
import { TagModule } from 'primeng/tag';
import { InputIconModule } from 'primeng/inputicon';
import { IconFieldModule } from 'primeng/iconfield';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { DropdownModule } from 'primeng/dropdown';
import { SplitButtonModule } from 'primeng/splitbutton';
import { CalendarModule } from 'primeng/calendar';
import { Reporte, ReporteService } from '../../services/reporte.service';

interface Column {
    field: string;
    header: string;
    customExportHeader?: string;
}

interface ExportColumn {
    title: string;
    dataKey: string;
}

@Component({
    selector: 'app-reportes',
    standalone: true,
    imports: [
        CommonModule,
        TableModule,
        FormsModule,
        ButtonModule,
        RippleModule,
        ToastModule,
        ToolbarModule,
        InputTextModule,
        TextareaModule,
        SelectModule,
        RadioButtonModule,
        InputNumberModule,
        DialogModule,
        TagModule,
        InputIconModule,
        IconFieldModule,
        ConfirmDialogModule,
        DropdownModule,
        SplitButtonModule,
        CalendarModule
    ],
    providers: [MessageService, ConfirmationService, DatePipe],
    template: `
        <p-toast></p-toast>
        
        <p-toolbar styleClass="mb-6">
            <ng-template #start>
                <p-button label="Nuevo" icon="pi pi-plus" severity="secondary" class="mr-2" (onClick)="openNew()" />
                <p-button severity="secondary" label="Eliminar" icon="pi pi-trash" outlined (onClick)="deleteSelectedReportes()" [disabled]="!selectedReportes || !selectedReportes.length" />
            </ng-template>

            <ng-template #end>
                <p-button label="Exportar" icon="pi pi-upload" severity="secondary" (onClick)="exportCSV()" />
            </ng-template>
        </p-toolbar>

        <p-table
            #dt
            [value]="reportes()"
            [rows]="10"
            [columns]="cols"
            [paginator]="true"
            [globalFilterFields]="['titulo', 'tipo', 'estado', 'usuario']"
            [tableStyle]="{ 'min-width': '75rem' }"
            [(selection)]="selectedReportes"
            [rowHover]="true"
            dataKey="reporte_id"
            currentPageReportTemplate="Mostrando {first} a {last} de {totalRecords} reportes"
            [showCurrentPageReport]="true"
            [rowsPerPageOptions]="[10, 20, 30]"
            [loading]="loading"
        >
            <ng-template #caption>
                <div class="flex items-center justify-between">
                    <h5 class="m-0">Gestión de Reportes</h5>
                    <p-iconfield>
                        <p-inputicon styleClass="pi pi-search" />
                        <input pInputText type="text" (input)="onGlobalFilter(dt, $event)" placeholder="Buscar..." />
                    </p-iconfield>
                </div>
            </ng-template>
            <ng-template #header>
                <tr>
                    <th style="width: 3rem">
                        <p-tableHeaderCheckbox />
                    </th>
                    <th pSortableColumn="reporte_id" style="min-width: 4rem">
                        ID
                        <p-sortIcon field="reporte_id" />
                    </th>
                    <th pSortableColumn="titulo" style="min-width: 16rem">
                        Título
                        <p-sortIcon field="titulo" />
                    </th>
                    <th pSortableColumn="tipo" style="min-width: 8rem">
                        Tipo
                        <p-sortIcon field="tipo" />
                    </th>
                    <th pSortableColumn="fecha_creacion" style="min-width: 8rem">
                        Fecha
                        <p-sortIcon field="fecha_creacion" />
                    </th>
                    <th pSortableColumn="usuario" style="min-width: 8rem">
                        Usuario
                        <p-sortIcon field="usuario" />
                    </th>
                    <th pSortableColumn="estado" style="min-width: 6rem">
                        Estado
                        <p-sortIcon field="estado" />
                    </th>
                    <th style="min-width: 10rem"></th>
                </tr>
            </ng-template>
            <ng-template #body let-reporte>
                <tr>
                    <td style="width: 3rem">
                        <p-tableCheckbox [value]="reporte" />
                    </td>
                    <td style="min-width: 4rem">{{ reporte.reporte_id }}</td>
                    <td style="min-width: 16rem">{{ reporte.titulo }}</td>
                    <td style="min-width: 8rem">
                        <p-tag [value]="reporte.tipo" [severity]="getTipoSeverity(reporte.tipo)" />
                    </td>
                    <td style="min-width: 8rem">{{ reporte.fecha_creacion | date:'dd/MM/yyyy' }}</td>
                    <td style="min-width: 8rem">{{ reporte.usuario }}</td>
                    <td style="min-width: 6rem">
                        <p-tag [value]="reporte.estado" [severity]="getEstadoSeverity(reporte.estado)" />
                    </td>
                    <td>
                        <p-splitButton label="Acciones" icon="pi pi-cog" [model]="getAccionesItems(reporte)" styleClass="p-button-sm"></p-splitButton>
                    </td>
                </tr>
            </ng-template>
        </p-table>

        <p-dialog [(visible)]="reporteDialog" [style]="{ width: '650px' }" header="Detalles de Reporte" [modal]="true">
            <ng-template #content>
                <div class="flex flex-col gap-6">
                    <div class="grid grid-cols-12 gap-4">
                        <div class="col-span-12">
                            <label for="titulo" class="block font-bold mb-3">Título</label>
                            <input type="text" pInputText id="titulo" [(ngModel)]="reporte.titulo" required autofocus class="w-full" />
                            <small class="text-red-500" *ngIf="submitted && !reporte.titulo">Título es requerido.</small>
                        </div>
                    </div>

                    <div class="grid grid-cols-12 gap-4">
                        <div class="col-span-12">
                            <label for="descripcion" class="block font-bold mb-3">Descripción</label>
                            <textarea pInputTextarea id="descripcion" [(ngModel)]="reporte.descripcion" rows="3" class="w-full"></textarea>
                        </div>
                    </div>

                    <div class="grid grid-cols-12 gap-4">
                        <div class="col-span-6">
                            <label for="tipo" class="block font-bold mb-3">Tipo</label>
                            <p-dropdown [(ngModel)]="reporte.tipo" 
                                       [options]="tiposReporte" 
                                       optionLabel="label" 
                                       optionValue="value" 
                                       placeholder="Seleccione Tipo" 
                                       [style]="{'width':'100%'}" 
                                       [showClear]="false" 
                                       appendTo="body" 
                                       required>
                            </p-dropdown>
                            <small class="text-red-500" *ngIf="submitted && !reporte.tipo">Tipo es requerido.</small>
                        </div>
                        <div class="col-span-6">
                            <label for="estado" class="block font-bold mb-3">Estado</label>
                            <p-dropdown [(ngModel)]="reporte.estado" 
                                       [options]="estadosReporte" 
                                       optionLabel="label" 
                                       optionValue="value" 
                                       placeholder="Seleccione Estado" 
                                       [style]="{'width':'100%'}" 
                                       [showClear]="false" 
                                       appendTo="body" 
                                       required>
                            </p-dropdown>
                            <small class="text-red-500" *ngIf="submitted && !reporte.estado">Estado es requerido.</small>
                        </div>
                    </div>
                </div>
            </ng-template>

            <ng-template #footer>
                <p-button label="Cancelar" icon="pi pi-times" text (click)="hideDialog()" />
                <p-button label="Guardar" icon="pi pi-check" (click)="saveReporte()" />
            </ng-template>
        </p-dialog>

        <p-confirmdialog [style]="{ width: '450px' }" />
    `
})
export class Reportes implements OnInit {
    reporteDialog: boolean = false;

    reportes = signal<Reporte[]>([]);
    
    reporte: Reporte = {
        titulo: '',
        tipo: 'INVENTARIO',
        estado: 'PENDIENTE'
    };

    selectedReportes: Reporte[] | null = null;

    submitted: boolean = false;

    loading: boolean = true;
    
    tiposReporte: any[] = [];
    estadosReporte: any[] = [];

    @ViewChild('dt') dt!: Table;

    exportColumns!: ExportColumn[];

    cols!: Column[];

    constructor(
        private reporteService: ReporteService,
        private messageService: MessageService,
        private confirmationService: ConfirmationService,
        private datePipe: DatePipe
    ) {}

    exportCSV() {
        this.dt.exportCSV();
    }

    ngOnInit() {
        this.loadData();
        this.tiposReporte = this.reporteService.getTiposReporte();
        this.estadosReporte = this.reporteService.getEstadosReporte();

        this.cols = [
            { field: 'reporte_id', header: 'ID' },
            { field: 'titulo', header: 'Título' },
            { field: 'tipo', header: 'Tipo' },
            { field: 'fecha_creacion', header: 'Fecha' },
            { field: 'usuario', header: 'Usuario' },
            { field: 'estado', header: 'Estado' }
        ];

        this.exportColumns = this.cols.map((col) => ({ title: col.header, dataKey: col.field }));
    }

    loadData() {
        this.loading = true;
        this.reporteService.getReportes()
            .then(data => {
                this.reportes.set(data);
                this.loading = false;
            })
            .catch(error => {
                console.error('Error al cargar reportes:', error);
                this.messageService.add({ 
                    severity: 'error', 
                    summary: 'Error', 
                    detail: 'Error al cargar reportes', 
                    life: 3000 
                });
                this.loading = false;
            });
    }

    onGlobalFilter(table: Table, event: Event) {
        table.filterGlobal((event.target as HTMLInputElement).value, 'contains');
    }

    openNew() {
        this.reporte = {
            titulo: '',
            tipo: 'INVENTARIO',
            estado: 'PENDIENTE'
        };
        this.submitted = false;
        this.reporteDialog = true;
    }

    editReporte(reporte: Reporte) {
        this.reporte = { ...reporte };
        this.reporteDialog = true;
    }

    deleteSelectedReportes() {
        this.confirmationService.confirm({
            message: '¿Está seguro de eliminar los reportes seleccionados?',
            header: 'Confirmar',
            icon: 'pi pi-exclamation-triangle',
            accept: () => {
                if (this.selectedReportes && this.selectedReportes.length > 0) {
                    const deletePromises = this.selectedReportes
                        .filter(reporte => reporte.reporte_id)
                        .map(reporte => this.reporteService.deleteReporte(reporte.reporte_id!));
                    
                    Promise.all(deletePromises)
                        .then(() => {
                            this.loadData();
                            this.messageService.add({ 
                                severity: 'success', 
                                summary: 'Éxito', 
                                detail: 'Reportes eliminados correctamente', 
                                life: 3000 
                            });
                            this.selectedReportes = null;
                        })
                        .catch(error => {
                            console.error('Error al eliminar reportes:', error);
                            this.messageService.add({ 
                                severity: 'error', 
                                summary: 'Error', 
                                detail: 'No se pudieron eliminar todos los reportes', 
                                life: 3000 
                            });
                        });
                }
            }
        });
    }

    hideDialog() {
        this.reporteDialog = false;
        this.submitted = false;
    }

    deleteReporte(reporte: Reporte) {
        this.confirmationService.confirm({
            message: `¿Está seguro de eliminar el reporte "${reporte.titulo}"?`,
            header: 'Confirmar',
            icon: 'pi pi-exclamation-triangle',
            accept: () => {
                if (reporte.reporte_id) {
                    this.reporteService.deleteReporte(reporte.reporte_id)
                        .then(() => {
                            this.loadData();
                            this.messageService.add({ 
                                severity: 'success', 
                                summary: 'Éxito', 
                                detail: 'Reporte eliminado correctamente', 
                                life: 3000 
                            });
                        })
                        .catch(error => {
                            console.error('Error al eliminar reporte:', error);
                            this.messageService.add({ 
                                severity: 'error', 
                                summary: 'Error', 
                                detail: 'No se pudo eliminar el reporte', 
                                life: 3000 
                            });
                        });
                }
            }
        });
    }

    saveReporte() {
        this.submitted = true;

        if (!this.reporte.titulo || !this.reporte.tipo || !this.reporte.estado) {
            return;
        }

        const saveOperation = this.reporte.reporte_id
            ? this.reporteService.updateReporte(this.reporte)
            : this.reporteService.createReporte(this.reporte);

        saveOperation
            .then(() => {
                this.loadData();
                this.messageService.add({ 
                    severity: 'success', 
                    summary: 'Éxito', 
                    detail: `Reporte ${this.reporte.reporte_id ? 'actualizado' : 'creado'} correctamente`, 
                    life: 3000 
                });
                this.reporteDialog = false;
                this.reporte = {
                    titulo: '',
                    tipo: 'INVENTARIO',
                    estado: 'PENDIENTE'
                };
            })
            .catch(error => {
                console.error('Error al guardar reporte:', error);
                this.messageService.add({ 
                    severity: 'error', 
                    summary: 'Error', 
                    detail: `No se pudo ${this.reporte.reporte_id ? 'actualizar' : 'crear'} el reporte`, 
                    life: 3000 
                });
            });
    }

    getTipoSeverity(tipo: string): 'success' | 'info' | 'warn' | 'danger' | 'secondary' | 'contrast' | undefined {
        switch (tipo) {
            case 'INVENTARIO':
                return 'info';
            case 'VENTAS':
                return 'success';
            case 'PRODUCTOS':
                return 'warn';
            case 'EMPLEADOS':
                return 'contrast';
            case 'BODEGAS':
                return 'secondary';
            default:
                return 'secondary';
        }
    }

    getEstadoSeverity(estado: string): 'success' | 'info' | 'warn' | 'danger' | 'secondary' | 'contrast' | undefined {
        switch (estado) {
            case 'PENDIENTE':
                return 'secondary';
            case 'GENERADO':
                return 'success';
            case 'ERROR':
                return 'danger';
            default:
                return 'secondary';
        }
    }

    downloadReporte(reporte: Reporte, formato: string) {
        if (!reporte.reporte_id) return;

        this.loading = true;
        this.reporteService.downloadReporte(reporte.reporte_id, formato)
            .then(blob => {
                // Crear un objeto URL para el blob
                const url = window.URL.createObjectURL(blob);
                
                // Crear un enlace temporal para descargar el archivo
                const a = document.createElement('a');
                a.href = url;
                a.download = `reporte_${reporte.reporte_id}_${this.datePipe.transform(new Date(), 'yyyyMMdd')}.${formato.toLowerCase()}`;
                
                // Añadir el enlace al DOM y hacer clic en él
                document.body.appendChild(a);
                a.click();
                
                // Limpiar
                window.URL.revokeObjectURL(url);
                document.body.removeChild(a);
                
                this.loading = false;
                this.messageService.add({ 
                    severity: 'success', 
                    summary: 'Éxito', 
                    detail: 'Reporte descargado correctamente', 
                    life: 3000 
                });
            })
            .catch(error => {
                console.error('Error al descargar reporte:', error);
                this.loading = false;
                this.messageService.add({ 
                    severity: 'error', 
                    summary: 'Error', 
                    detail: 'No se pudo descargar el reporte', 
                    life: 3000 
                });
            });
    }

    getAccionesItems(reporte: Reporte) {
        return [
            {
                label: 'Editar',
                icon: 'pi pi-pencil',
                command: () => {
                    this.editReporte(reporte);
                }
            },
            {
                label: 'Eliminar',
                icon: 'pi pi-trash',
                command: () => {
                    this.deleteReporte(reporte);
                }
            },
            {
                separator: true
            },
            {
                label: 'Descargar PDF',
                icon: 'pi pi-file-pdf',
                command: () => {
                    this.downloadReporte(reporte, 'PDF');
                }
            },
            {
                label: 'Descargar Excel',
                icon: 'pi pi-file-excel',
                command: () => {
                    this.downloadReporte(reporte, 'EXCEL');
                }
            }
        ];
    }
} 