import { Component } from '@angular/core';

@Component({
    standalone: true,
    selector: 'app-footer',
    template: `<div class="layout-footer">
        Bodega Central para alimentos no perecibles
    </div>`
})
export class AppFooter {}
