import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { BehaviorSubject, Observable, firstValueFrom, throwError } from 'rxjs';
import { Bodega } from './bodega.service';
import { Producto } from './producto.service';

export interface EnvioItem {
    item_id?: number;
    envio_id?: number;
    producto_id: number;
    producto?: Producto;
    cantidad: number;
    observacion?: string;
}

export interface Envio {
    envio_id?: number;
    fecha_creacion?: Date;
    fecha_envio?: Date;
    fecha_recepcion?: Date;
    bodega_origen_id: number;
    bodega_destino_id: number;
    bodega_origen?: Bodega;
    bodega_destino?: Bodega;
    estado: string;
    codigo_seguimiento?: string;
    notas?: string;
    empleado_id?: number;
    empleado?: string;
    items: EnvioItem[];
}

export interface EnvioResponse {
    items: Envio[];
    total: number;
}

@Injectable({
    providedIn: 'root'
})
export class EnvioService {
    private apiUrl = `${environment.apiUrl}/envios`;
    private enviosSource = new BehaviorSubject<Envio[]>([]);
    envios$ = this.enviosSource.asObservable();

    constructor(private http: HttpClient) {
        // Carga inicial de datos
        this.loadEnvios();
    }

    // Obtener el token desde el localStorage
    private getAuthHeaders(): HttpHeaders {
        const token = localStorage.getItem('access_token');
        return new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        });
    }

    // Método para cargar datos de envíos desde la API
    async loadEnvios(): Promise<Envio[]> {
        try {
            const headers = this.getAuthHeaders();
            const response = await firstValueFrom(
                this.http.get<EnvioResponse>(this.apiUrl, { headers })
            );
            
            const envios = Array.isArray(response) ? response : 
                            (response.items ? response.items : []);
            
            this.enviosSource.next(envios);
            return envios;
        } catch (error) {
            console.error('Error al cargar envíos:', error);
            // En caso de error, usar datos de demostración
            const demoEnvios = this.getDemoEnvios();
            this.enviosSource.next(demoEnvios);
            return demoEnvios;
        }
    }

    // Método para obtener todos los envíos
    getEnvios(): Promise<Envio[]> {
        return firstValueFrom(this.envios$).then(envios => {
            if (envios.length === 0) {
                return this.loadEnvios();
            }
            return envios;
        });
    }

    // Método para obtener un envío por ID
    async getEnvio(id: number): Promise<Envio | undefined> {
        try {
            const headers = this.getAuthHeaders();
            return await firstValueFrom(
                this.http.get<Envio>(`${this.apiUrl}/${id}`, { headers })
            );
        } catch (error) {
            console.error(`Error al obtener envío con ID ${id}:`, error);
            throw error;
        }
    }

    // Método para crear un nuevo envío
    async createEnvio(envio: Envio): Promise<Envio> {
        try {
            const headers = this.getAuthHeaders();
            const newEnvio = await firstValueFrom(
                this.http.post<Envio>(this.apiUrl, envio, { headers })
            );
            await this.loadEnvios(); // Recargar lista
            return newEnvio;
        } catch (error) {
            console.error('Error al crear envío:', error);
            throw error;
        }
    }

    // Método para actualizar un envío existente
    async updateEnvio(envio: Envio): Promise<Envio> {
        if (!envio.envio_id) {
            throw new Error('El envío debe tener un ID');
        }

        try {
            const headers = this.getAuthHeaders();
            const updatedEnvio = await firstValueFrom(
                this.http.put<Envio>(`${this.apiUrl}/${envio.envio_id}`, envio, { headers })
            );
            await this.loadEnvios(); // Recargar lista
            return updatedEnvio;
        } catch (error) {
            console.error(`Error al actualizar envío con ID ${envio.envio_id}:`, error);
            throw error;
        }
    }

    // Método para eliminar un envío
    async deleteEnvio(id: number): Promise<void> {
        try {
            const headers = this.getAuthHeaders();
            await firstValueFrom(
                this.http.delete(`${this.apiUrl}/${id}`, { headers })
            );
            await this.loadEnvios(); // Recargar lista
        } catch (error) {
            console.error(`Error al eliminar envío con ID ${id}:`, error);
            throw error;
        }
    }

    // Método para cambiar el estado de un envío
    async cambiarEstadoEnvio(id: number, estado: string): Promise<Envio> {
        try {
            const headers = this.getAuthHeaders();
            const updatedEnvio = await firstValueFrom(
                this.http.put<Envio>(`${this.apiUrl}/${id}/estado`, { estado }, { headers })
            );
            await this.loadEnvios(); // Recargar lista
            return updatedEnvio;
        } catch (error) {
            console.error(`Error al cambiar estado del envío con ID ${id}:`, error);
            throw error;
        }
    }

    // Métodos para datos estáticos (compatibilidad y fallback)
    getEstadosEnvio(): { label: string, value: string }[] {
        return [
            { label: 'Pendiente', value: 'PENDIENTE' },
            { label: 'En Tránsito', value: 'EN_TRANSITO' },
            { label: 'Entregado', value: 'ENTREGADO' },
            { label: 'Cancelado', value: 'CANCELADO' }
        ];
    }

    // Método para datos de demostración (solo para fallback)
    getDemoEnvios(): Envio[] {
        return [
            {
                envio_id: 1,
                fecha_creacion: new Date('2023-12-01'),
                fecha_envio: new Date('2023-12-02'),
                bodega_origen_id: 1,
                bodega_destino_id: 2,
                estado: 'ENTREGADO',
                codigo_seguimiento: 'ENV-001-2023',
                empleado_id: 1,
                items: [
                    {
                        item_id: 1,
                        envio_id: 1,
                        producto_id: 1,
                        cantidad: 10
                    },
                    {
                        item_id: 2,
                        envio_id: 1,
                        producto_id: 2,
                        cantidad: 5
                    }
                ]
            },
            {
                envio_id: 2,
                fecha_creacion: new Date('2023-12-05'),
                fecha_envio: new Date('2023-12-06'),
                bodega_origen_id: 1,
                bodega_destino_id: 3,
                estado: 'EN_TRANSITO',
                codigo_seguimiento: 'ENV-002-2023',
                empleado_id: 2,
                items: [
                    {
                        item_id: 3,
                        envio_id: 2,
                        producto_id: 3,
                        cantidad: 8
                    }
                ]
            },
            {
                envio_id: 3,
                fecha_creacion: new Date('2023-12-10'),
                bodega_origen_id: 2,
                bodega_destino_id: 1,
                estado: 'PENDIENTE',
                codigo_seguimiento: 'ENV-003-2023',
                empleado_id: 3,
                items: [
                    {
                        item_id: 4,
                        envio_id: 3,
                        producto_id: 1,
                        cantidad: 3
                    },
                    {
                        item_id: 5,
                        envio_id: 3,
                        producto_id: 4,
                        cantidad: 12
                    }
                ]
            }
        ];
    }

    // Manejo de errores
    private handleError(error: any) {
        let errorMessage = '';
        if (error.error instanceof ErrorEvent) {
            // Error del cliente
            errorMessage = `Error: ${error.error.message}`;
        } else {
            // Error del servidor
            errorMessage = `Código de error: ${error.status}\nMensaje: ${error.message}`;
        }
        console.error(errorMessage);
        return throwError(() => new Error(errorMessage));
    }
} 