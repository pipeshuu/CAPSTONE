import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { BehaviorSubject, firstValueFrom, throwError } from 'rxjs';

export interface Usuario {
    usuario_id: string;
    email: string;
    nombre: string;
    apellidos: string;
    activo: boolean;
    es_admin: boolean;
}

export interface UsuarioList {
    items: Usuario[];
    total: number;
}

@Injectable({
    providedIn: 'root'
})
export class UsuarioService {
    private apiUrl = `${environment.apiUrl}/auth`;
    private usuariosSource = new BehaviorSubject<Usuario[]>([]);
    usuarios$ = this.usuariosSource.asObservable();

    constructor(private http: HttpClient) {
        // Carga inicial de datos
        this.loadUsuarios();
    }

    // Obtener el token desde el localStorage
    private getAuthHeaders(): HttpHeaders {
        const token = localStorage.getItem('access_token');
        return new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        });
    }

    // Obtener el usuario actual
    async getCurrentUser(): Promise<Usuario> {
        try {
            const headers = this.getAuthHeaders();
            return await firstValueFrom(
                this.http.get<Usuario>(`${this.apiUrl}/me`, { headers })
            );
        } catch (error) {
            console.error('Error al obtener usuario actual:', error);
            throw error;
        }
    }

    // Método para cargar datos de usuarios desde la API
    async loadUsuarios(): Promise<Usuario[]> {
        try {
            const headers = this.getAuthHeaders();
            const response = await firstValueFrom(
                this.http.get<UsuarioList>(`${this.apiUrl}/users`, { headers })
            );
            
            const usuarios = response.items || [];
            this.usuariosSource.next(usuarios);
            return usuarios;
        } catch (error) {
            console.error('Error al cargar usuarios:', error);
            return [];
        }
    }

    // Método para obtener todos los usuarios
    getUsuarios(): Promise<Usuario[]> {
        return firstValueFrom(this.usuarios$).then(usuarios => {
            if (usuarios.length === 0) {
                return this.loadUsuarios();
            }
            return usuarios;
        });
    }

    // Método para obtener un usuario por ID
    async getUsuario(id: string): Promise<Usuario> {
        try {
            const headers = this.getAuthHeaders();
            return await firstValueFrom(
                this.http.get<Usuario>(`${this.apiUrl}/users/${id}`, { headers })
            );
        } catch (error) {
            console.error(`Error al obtener usuario con ID ${id}:`, error);
            throw error;
        }
    }

    // Método para convertir un usuario en empleado
    async convertirUsuarioAEmpleado(
        usuario_id: string, 
        datosEmpleado: {
            nombre: string;
            apellidos: string;
            cargo: string;
            usuario_sistema: string;
            bodega_id: number;
        }
    ): Promise<any> {
        try {
            const headers = this.getAuthHeaders();
            return await firstValueFrom(
                this.http.post(
                    `${environment.apiUrl}/empleados/users/${usuario_id}/convert-to-empleado`, 
                    datosEmpleado, 
                    { headers }
                )
            );
        } catch (error) {
            console.error(`Error al convertir usuario a empleado:`, error);
            throw error;
        }
    }

    // Método para asignar un usuario a un empleado existente
    async asignarUsuarioAEmpleado(empleado_id: number, usuario_id: string): Promise<any> {
        try {
            const headers = this.getAuthHeaders();
            return await firstValueFrom(
                this.http.post(
                    `${environment.apiUrl}/empleados/${empleado_id}/assign-user/${usuario_id}`, 
                    {}, 
                    { headers }
                )
            );
        } catch (error) {
            console.error(`Error al asignar usuario a empleado:`, error);
            throw error;
        }
    }

    // Método para obtener usuarios disponibles (no vinculados a empleados)
    async getUsuariosDisponibles(): Promise<Usuario[]> {
        try {
            const headers = this.getAuthHeaders();
            const response = await firstValueFrom(
                this.http.get<Usuario[]>(`${this.apiUrl}/users/disponibles`, { headers })
            );
            
            // Si la API no tiene un endpoint específico, filtramos aquí
            // Nota: esto es un fallback, lo ideal es tener un endpoint específico
            const allEmpleados = await this.getEmpleadosConUsuario();
            const usuariosAsignados = allEmpleados
                .filter((e: {usuario_id?: string}) => e.usuario_id)
                .map((e: {usuario_id?: string}) => e.usuario_id);
            
            return Array.isArray(response) ? 
                response.filter(u => !usuariosAsignados.includes(u.usuario_id)) : 
                [];
        } catch (error) {
            console.error('Error al obtener usuarios disponibles:', error);
            // Implementación alternativa si no existe el endpoint
            const allUsuarios = await this.getUsuarios();
            const allEmpleados = await this.getEmpleadosConUsuario();
            const usuariosAsignados = allEmpleados
                .filter((e: {usuario_id?: string}) => e.usuario_id)
                .map((e: {usuario_id?: string}) => e.usuario_id);
            
            return allUsuarios.filter(u => !usuariosAsignados.includes(u.usuario_id));
        }
    }

    // Método auxiliar para obtener empleados con usuario
    private async getEmpleadosConUsuario(): Promise<any[]> {
        try {
            const headers = this.getAuthHeaders();
            return await firstValueFrom(
                this.http.get<any[]>(`${environment.apiUrl}/empleados`, { headers })
            );
        } catch (error) {
            console.error('Error al obtener empleados:', error);
            return [];
        }
    }

    // Método para registrar un nuevo usuario
    async registerUsuario(userData: { 
        email: string; 
        nombre: string; 
        apellidos: string; 
        password: string 
    }): Promise<Usuario> {
        try {
            const headers = this.getAuthHeaders();
            return await firstValueFrom(
                this.http.post<Usuario>(`${this.apiUrl}/register`, userData, { headers })
            );
        } catch (error) {
            console.error('Error al registrar usuario:', error);
            throw error;
        }
    }
} 