import { Injectable } from '@angular/core';

export interface Producto {
    producto_id?: number;
    nombre: string;
    codigo?: string;
    descripcion?: string;
    precio?: number;
    imagen_url?: string;
}

@Injectable({
    providedIn: 'root'
})
export class ProductoService {
    constructor() {}
} 