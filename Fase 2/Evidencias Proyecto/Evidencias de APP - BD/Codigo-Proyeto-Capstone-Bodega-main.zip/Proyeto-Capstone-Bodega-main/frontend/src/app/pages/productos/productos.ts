import { Component, OnInit, signal, ViewChild, OnDestroy } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Table, TableModule } from 'primeng/table';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { RippleModule } from 'primeng/ripple';
import { ToastModule } from 'primeng/toast';
import { ToolbarModule } from 'primeng/toolbar';
import { InputTextModule } from 'primeng/inputtext';
import { TextareaModule } from 'primeng/textarea';
import { SelectModule } from 'primeng/select';
import { RadioButtonModule } from 'primeng/radiobutton';
import { InputNumberModule } from 'primeng/inputnumber';
import { DialogModule } from 'primeng/dialog';
import { TagModule } from 'primeng/tag';
import { InputIconModule } from 'primeng/inputicon';
import { IconFieldModule } from 'primeng/iconfield';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { DropdownModule } from 'primeng/dropdown';
import { FileUploadModule } from 'primeng/fileupload';
import { Producto, Categoria, ProductosService } from '../../services/productos.service';
import { Subject, takeUntil } from 'rxjs';

interface Column {
    field: string;
    header: string;
    customExportHeader?: string;
}

interface ExportColumn {
    title: string;
    dataKey: string;
}

@Component({
    selector: 'app-productos',
    standalone: true,
    imports: [
        CommonModule,
        TableModule,
        FormsModule,
        ButtonModule,
        RippleModule,
        ToastModule,
        ToolbarModule,
        InputTextModule,
        TextareaModule,
        SelectModule,
        RadioButtonModule,
        InputNumberModule,
        DialogModule,
        TagModule,
        InputIconModule,
        IconFieldModule,
        ConfirmDialogModule,
        DropdownModule,
        FileUploadModule
    ],
    template: `
        <p-toast></p-toast>
        <p-toolbar styleClass="mb-6">
            <ng-template #start>
                <p-button label="Nuevo" icon="pi pi-plus" severity="secondary" class="mr-2" (onClick)="openNew()" />
                <p-button severity="secondary" label="Eliminar" icon="pi pi-trash" outlined (onClick)="deleteSelectedProducts()" [disabled]="!selectedProducts || !selectedProducts.length" />
            </ng-template>

            <ng-template #end>
                <p-button label="Exportar" icon="pi pi-upload" severity="secondary" (onClick)="exportCSV()" />
            </ng-template>
        </p-toolbar>

        <p-table
            #dt
            [value]="products()"
            [rows]="10"
            [columns]="cols"
            [paginator]="true"
            [globalFilterFields]="['nombre', 'sku', 'unidad_medida', 'categoria.nombre', 'precio']"
            [tableStyle]="{ 'min-width': '75rem' }"
            [(selection)]="selectedProducts"
            [rowHover]="true"
            dataKey="producto_id"
            currentPageReportTemplate="Mostrando {first} a {last} de {totalRecords} productos"
            [showCurrentPageReport]="true"
            [rowsPerPageOptions]="[10, 20, 30]"
            [loading]="loading"
        >
            <ng-template #caption>
                <div class="flex items-center justify-between">
                    <h5 class="m-0">Productos</h5>
                    <p-iconfield>
                        <p-inputicon styleClass="pi pi-search" />
                        <input pInputText type="text" (input)="onGlobalFilter(dt, $event)" placeholder="Buscar..." />
                    </p-iconfield>
                </div>
            </ng-template>
            <ng-template #header>
                <tr>
                    <th style="width: 3rem">
                        <p-tableHeaderCheckbox />
                    </th>
                    <th style="min-width: 12rem">SKU</th>
                    <th pSortableColumn="nombre" style="min-width:16rem">
                        Nombre
                        <p-sortIcon field="nombre" />
                    </th>
                    <th>Imagen</th>
                    <th pSortableColumn="peso" style="min-width: 8rem">
                        Peso
                        <p-sortIcon field="peso" />
                    </th>
                    <th pSortableColumn="unidad_medida" style="min-width: 8rem">
                        Unidad
                        <p-sortIcon field="unidad_medida" />
                    </th>
                    <th pSortableColumn="precio" style="min-width: 8rem">
                        Precio
                        <p-sortIcon field="precio" />
                    </th>
                    <th pSortableColumn="categoria.nombre" style="min-width:10rem">
                        Categoría
                        <p-sortIcon field="categoria.nombre" />
                    </th>
                    <th style="min-width: 12rem"></th>
                </tr>
            </ng-template>
            <ng-template #body let-product>
                <tr>
                    <td style="width: 3rem">
                        <p-tableCheckbox [value]="product" />
                    </td>
                    <td style="min-width: 12rem">{{ product.sku }}</td>
                    <td style="min-width: 16rem">{{ product.nombre }}</td>
                    <td>
                        <img [src]="product.imagen_url || 'assets/images/product-placeholder.svg'" [alt]="product.nombre" style="width: 64px" class="rounded" />
                    </td>
                    <td>{{ product.peso }}</td>
                    <td>{{ product.unidad_medida }}</td>
                    <td>{{ product.precio | currency: 'CLP' }}</td>
                    <td>{{ product.categoria?.nombre }}</td>
                    <td>
                        <p-button icon="pi pi-pencil" class="mr-2" [rounded]="true" [outlined]="true" (click)="editProduct(product)" />
                        <p-button icon="pi pi-trash" severity="danger" [rounded]="true" [outlined]="true" (click)="deleteProduct(product)" />
                    </td>
                </tr>
            </ng-template>
        </p-table>

        <p-dialog [(visible)]="productDialog" [style]="{ width: '650px' }" header="Detalles del producto" [modal]="true">
            <ng-template #content>
                <div class="flex flex-col gap-6">
                    <div class="flex justify-center">
                        <img [src]="product.imagen_url || selectedImageUrl || 'assets/images/product-placeholder.svg'" [alt]="product.nombre" class="w-40 h-auto pb-4" *ngIf="product.imagen_url || selectedImageUrl" />
                    </div>
                    
                    <div class="grid grid-cols-12 gap-4">
                        <div class="col-span-6">
                            <label for="sku" class="block font-bold mb-3">SKU</label>
                            <input type="text" pInputText id="sku" [(ngModel)]="product.sku" required autofocus class="w-full" />
                            <small class="text-red-500" *ngIf="submitted && !product.sku">SKU es requerido.</small>
                        </div>
                        
                        <div class="col-span-6">
                            <label for="nombre" class="block font-bold mb-3">Nombre</label>
                            <input type="text" pInputText id="nombre" [(ngModel)]="product.nombre" required class="w-full" />
                            <small class="text-red-500" *ngIf="submitted && !product.nombre">Nombre es requerido.</small>
                        </div>
                    </div>
                    
                    <div>
                        <label for="descripcion" class="block font-bold mb-3">Descripción</label>
                        <textarea id="descripcion" pTextarea [(ngModel)]="product.descripcion" rows="3" class="w-full"></textarea>
                    </div>
                    
                    <div class="grid grid-cols-12 gap-6">
                        <div class="col-span-6">
                            <label for="categoria" class="block font-bold mb-3">Categoría</label>
                            <p-dropdown 
                                [options]="categorias()" 
                                [(ngModel)]="product.categoria_id" 
                                optionLabel="nombre" 
                                optionValue="categoria_id"
                                placeholder="Seleccione una categoría" 
                                [showClear]="true"
                                appendTo="body"
                                class="w-full"
                                required
                            ></p-dropdown>
                            <small class="text-red-500" *ngIf="submitted && !product.categoria_id">Categoría es requerida.</small>
                        </div>
                        
                        <div class="col-span-6">
                            <label for="precio" class="block font-bold mb-3">Precio</label>
                            <p-inputNumber id="precio" [(ngModel)]="product.precio" mode="currency" currency="CLP" locale="es-CL" [minFractionDigits]="2" [maxFractionDigits]="2" class="w-full"></p-inputNumber>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-12 gap-6">
                        <div class="col-span-6">
                            <label for="peso" class="block font-bold mb-3">Peso</label>
                            <p-inputNumber id="peso" [(ngModel)]="product.peso" mode="decimal" [minFractionDigits]="2" [maxFractionDigits]="2" class="w-full"></p-inputNumber>
                        </div>
                        
                        <div class="col-span-6">
                            <label for="unidad" class="block font-bold mb-3">Unidad</label>
                            <input type="text" pInputText id="unidad" [(ngModel)]="product.unidad_medida" placeholder="kg, g, unidad..." class="w-full" />
                        </div>
                    </div>
                    
                    <div>
                        <label for="imagen" class="block font-bold mb-3">Imagen</label>
                        <input type="file" accept="image/*" (change)="onFileSelect($event)" class="w-full" />
                    </div>
                </div>
            </ng-template>

            <ng-template #footer>
                <p-button label="Cancelar" icon="pi pi-times" (onClick)="hideDialog()" class="p-button-text"></p-button>
                <p-button label="Guardar" icon="pi pi-check" (onClick)="saveProduct()"></p-button>
            </ng-template>
        </p-dialog>

        <p-confirmdialog [style]="{ width: '450px' }"></p-confirmdialog>
    `,
    providers: [MessageService, ConfirmationService]
})
export class Productos implements OnInit, OnDestroy {
    productDialog: boolean = false;
    products = signal<Producto[]>([]);
    categorias = signal<Categoria[]>([]);
    
    product: Producto = {};
    selectedProducts: Producto[] | null = null;
    submitted: boolean = false;
    loading: boolean = true;
    
    selectedFile: File | null = null;
    selectedImageUrl: string | null = null;
    
    private destroy$ = new Subject<void>();

    @ViewChild('dt') dt!: Table;

    exportColumns!: ExportColumn[];
    cols!: Column[];

    constructor(
        private productosService: ProductosService,
        private messageService: MessageService,
        private confirmationService: ConfirmationService
    ) {}

    exportCSV() {
        this.dt.exportCSV();
    }

    ngOnInit() {
        this.loadData();
        this.loadCategorias();

        this.cols = [
            { field: 'sku', header: 'SKU' },
            { field: 'nombre', header: 'Nombre' },
            { field: 'descripcion', header: 'Descripción' },
            { field: 'peso', header: 'Peso' },
            { field: 'unidad_medida', header: 'Unidad' },
            { field: 'precio', header: 'Precio' },
            { field: 'categoria.nombre', header: 'Categoría' }
        ];

        this.exportColumns = this.cols.map((col) => ({ title: col.header, dataKey: col.field }));
    }
    
    ngOnDestroy() {
        this.destroy$.next();
        this.destroy$.complete();
    }

    loadData() {
        this.loading = true;
        this.productosService.getProductos()
            .pipe(takeUntil(this.destroy$))
            .subscribe({
                next: (data) => {
                    this.products.set(data);
                    this.loading = false;
                },
                error: (error) => {
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Error',
                        detail: 'Error al cargar productos: ' + error.message,
                        life: 3000
                    });
                    this.loading = false;
                }
            });
    }
    
    loadCategorias() {
        this.productosService.getCategorias()
            .pipe(takeUntil(this.destroy$))
            .subscribe({
                next: (data) => {
                    this.categorias.set(data);
                },
                error: (error) => {
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Error',
                        detail: 'Error al cargar categorías: ' + error.message,
                        life: 3000
                    });
                }
            });
    }

    onGlobalFilter(table: Table, event: Event) {
        table.filterGlobal((event.target as HTMLInputElement).value, 'contains');
    }

    openNew() {
        this.product = {};
        this.submitted = false;
        this.selectedFile = null;
        this.selectedImageUrl = null;
        this.productDialog = true;
    }

    editProduct(product: Producto) {
        this.product = { ...product };
        this.selectedFile = null;
        this.selectedImageUrl = null;
        this.productDialog = true;
    }
    
    onFileSelect(event: Event) {
        const fileInput = event.target as HTMLInputElement;
        const files = fileInput.files;
        
        if (files && files.length > 0) {
            this.selectedFile = files[0];
            
            // Create preview URL
            const reader = new FileReader();
            reader.onload = () => {
                this.selectedImageUrl = reader.result as string;
            };
            reader.readAsDataURL(this.selectedFile);
        }
    }

    deleteSelectedProducts() {
        this.confirmationService.confirm({
            message: '¿Estás seguro que deseas eliminar los productos seleccionados?',
            header: 'Confirmar',
            icon: 'pi pi-exclamation-triangle',
            accept: () => {
                if (!this.selectedProducts || this.selectedProducts.length === 0) return;
                
                let successCount = 0;
                let errorCount = 0;
                let totalCount = this.selectedProducts.length;
                
                for (const product of this.selectedProducts) {
                    if (product.producto_id) {
                        this.productosService.deleteProducto(product.producto_id)
                            .pipe(takeUntil(this.destroy$))
                            .subscribe({
                                next: () => {
                                    successCount++;
                                    if (successCount + errorCount === totalCount) {
                                        this.loadData();
                                        this.messageService.add({
                                            severity: 'success',
                                            summary: 'Éxito',
                                            detail: `${successCount} productos eliminados correctamente.${errorCount > 0 ? ` ${errorCount} con errores.` : ''}`,
                                            life: 3000
                                        });
                                        this.selectedProducts = null;
                                    }
                                },
                                error: () => {
                                    errorCount++;
                                    if (successCount + errorCount === totalCount) {
                                        this.loadData();
                                        this.messageService.add({
                                            severity: 'success',
                                            summary: 'Éxito',
                                            detail: `${successCount} productos eliminados correctamente.${errorCount > 0 ? ` ${errorCount} con errores.` : ''}`,
                                            life: 3000
                                        });
                                        this.selectedProducts = null;
                                    }
                                }
                            });
                    }
                }
            }
        });
    }

    hideDialog() {
        this.productDialog = false;
        this.submitted = false;
        this.selectedFile = null;
        this.selectedImageUrl = null;
    }

    deleteProduct(product: Producto) {
        this.confirmationService.confirm({
            message: 'Estas seguro que quieres eliminar el producto ' + product.nombre + '?',
            header: 'Confirmar',
            icon: 'pi pi-exclamation-triangle',
            accept: () => {
                if (!product.producto_id) return;
                
                this.productosService.deleteProducto(product.producto_id)
                    .pipe(takeUntil(this.destroy$))
                    .subscribe({
                        next: () => {
                            this.loadData();
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Éxito',
                                detail: 'Producto eliminado correctamente',
                                life: 3000
                            });
                        },
                        error: (error) => {
                            this.messageService.add({
                                severity: 'error',
                                summary: 'Error',
                                detail: 'Error al eliminar el producto: ' + error.message,
                                life: 3000
                            });
                        }
                    });
            }
        });
    }

    saveProduct() {
        this.submitted = true;
        
        if (!this.product.sku || !this.product.nombre || !this.product.categoria_id) {
            return;
        }
        
        if (this.product.producto_id) {
            // Actualizar producto
            this.productosService.updateProducto(this.product.producto_id, this.product, this.selectedFile || undefined)
                .pipe(takeUntil(this.destroy$))
                .subscribe({
                    next: () => {
                        this.loadData();
                        this.messageService.add({
                            severity: 'success',
                            summary: 'Éxito',
                            detail: 'Producto actualizado correctamente',
                            life: 3000
                        });
                        this.productDialog = false;
                        this.product = {};
                        this.selectedFile = null;
                        this.selectedImageUrl = null;
                    },
                    error: (error) => {
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Error',
                            detail: 'Error al actualizar el producto: ' + error.message,
                            life: 3000
                        });
                    }
                });
        } else {
            // Crear nuevo producto
            this.productosService.createProducto(this.product, this.selectedFile || undefined)
                .pipe(takeUntil(this.destroy$))
                .subscribe({
                    next: () => {
                        this.loadData();
                        this.messageService.add({
                            severity: 'success',
                            summary: 'Éxito',
                            detail: 'Producto creado correctamente',
                            life: 3000
                        });
                        this.productDialog = false;
                        this.product = {};
                        this.selectedFile = null;
                        this.selectedImageUrl = null;
                    },
                    error: (error) => {
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Error',
                            detail: 'Error al crear el producto: ' + error.message,
                            life: 3000
                        });
                    }
                });
        }
    }
} 