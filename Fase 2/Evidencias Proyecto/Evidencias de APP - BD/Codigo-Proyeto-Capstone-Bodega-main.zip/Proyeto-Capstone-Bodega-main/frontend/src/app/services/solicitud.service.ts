import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { BehaviorSubject, Observable, firstValueFrom, throwError } from 'rxjs';

export interface SolicitudItem {
    item_id?: number;
    solicitud_id?: number;
    producto_id: number;
    producto?: any;
    cantidad: number;
    cantidad_aprobada?: number;
    observacion?: string;
}

export interface Solicitud {
    solicitud_id?: number;
    fecha_creacion?: Date;
    fecha_aprobacion?: Date;
    bodega_origen_id: number;
    bodega_destino_id: number;
    bodega_origen?: any;
    bodega_destino?: any;
    estado: string;
    prioridad: string;
    justificacion?: string;
    notas?: string;
    empleado_id?: number;
    empleado?: string;
    items: SolicitudItem[];
}

export interface SolicitudResponse {
    items: Solicitud[];
    total: number;
}

@Injectable({
    providedIn: 'root'
})
export class SolicitudService {
    private apiUrl = `${environment.apiUrl}/solicitudes`;
    private solicitudesSource = new BehaviorSubject<Solicitud[]>([]);
    solicitudes$ = this.solicitudesSource.asObservable();

    constructor(private http: HttpClient) {
        // Carga inicial de datos
        this.loadSolicitudes();
    }

    // Obtener el token desde el localStorage
    private getAuthHeaders(): HttpHeaders {
        const token = localStorage.getItem('access_token');
        return new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        });
    }

    // Método para cargar datos de solicitudes desde la API
    async loadSolicitudes(): Promise<Solicitud[]> {
        try {
            const headers = this.getAuthHeaders();
            const response = await firstValueFrom(
                this.http.get<SolicitudResponse>(this.apiUrl, { headers })
            );
            
            const solicitudes = Array.isArray(response) ? response : 
                            (response.items ? response.items : []);
            
            this.solicitudesSource.next(solicitudes);
            return solicitudes;
        } catch (error) {
            console.error('Error al cargar solicitudes:', error);
            // En caso de error, usar datos de demostración
            const demoSolicitudes = this.getDemoSolicitudes();
            this.solicitudesSource.next(demoSolicitudes);
            return demoSolicitudes;
        }
    }

    // Método para obtener todas las solicitudes
    getSolicitudes(): Promise<Solicitud[]> {
        return firstValueFrom(this.solicitudes$).then(solicitudes => {
            if (solicitudes.length === 0) {
                return this.loadSolicitudes();
            }
            return solicitudes;
        });
    }

    // Método para obtener una solicitud por ID
    async getSolicitud(id: number): Promise<Solicitud | undefined> {
        try {
            const headers = this.getAuthHeaders();
            return await firstValueFrom(
                this.http.get<Solicitud>(`${this.apiUrl}/${id}`, { headers })
            );
        } catch (error) {
            console.error(`Error al obtener solicitud con ID ${id}:`, error);
            throw error;
        }
    }

    // Método para crear una nueva solicitud
    async createSolicitud(solicitud: Solicitud): Promise<Solicitud> {
        try {
            const headers = this.getAuthHeaders();
            const newSolicitud = await firstValueFrom(
                this.http.post<Solicitud>(this.apiUrl, solicitud, { headers })
            );
            await this.loadSolicitudes(); // Recargar lista
            return newSolicitud;
        } catch (error) {
            console.error('Error al crear solicitud:', error);
            throw error;
        }
    }

    // Método para actualizar una solicitud existente
    async updateSolicitud(solicitud: Solicitud): Promise<Solicitud> {
        if (!solicitud.solicitud_id) {
            throw new Error('La solicitud debe tener un ID');
        }

        try {
            const headers = this.getAuthHeaders();
            const updatedSolicitud = await firstValueFrom(
                this.http.put<Solicitud>(`${this.apiUrl}/${solicitud.solicitud_id}`, solicitud, { headers })
            );
            await this.loadSolicitudes(); // Recargar lista
            return updatedSolicitud;
        } catch (error) {
            console.error(`Error al actualizar solicitud con ID ${solicitud.solicitud_id}:`, error);
            throw error;
        }
    }

    // Método para eliminar una solicitud
    async deleteSolicitud(id: number): Promise<void> {
        try {
            const headers = this.getAuthHeaders();
            await firstValueFrom(
                this.http.delete(`${this.apiUrl}/${id}`, { headers })
            );
            await this.loadSolicitudes(); // Recargar lista
        } catch (error) {
            console.error(`Error al eliminar solicitud con ID ${id}:`, error);
            throw error;
        }
    }

    // Método para aprobar una solicitud
    async aprobarSolicitud(id: number, detalles: any): Promise<Solicitud> {
        try {
            const headers = this.getAuthHeaders();
            const updatedSolicitud = await firstValueFrom(
                this.http.put<Solicitud>(`${this.apiUrl}/${id}/aprobar`, detalles, { headers })
            );
            await this.loadSolicitudes(); // Recargar lista
            return updatedSolicitud;
        } catch (error) {
            console.error(`Error al aprobar solicitud con ID ${id}:`, error);
            throw error;
        }
    }

    // Método para rechazar una solicitud
    async rechazarSolicitud(id: number, motivo: string): Promise<Solicitud> {
        try {
            const headers = this.getAuthHeaders();
            const updatedSolicitud = await firstValueFrom(
                this.http.put<Solicitud>(`${this.apiUrl}/${id}/rechazar`, { motivo }, { headers })
            );
            await this.loadSolicitudes(); // Recargar lista
            return updatedSolicitud;
        } catch (error) {
            console.error(`Error al rechazar solicitud con ID ${id}:`, error);
            throw error;
        }
    }

    // Métodos para datos estáticos (compatibilidad y fallback)
    getEstadosSolicitud(): { label: string, value: string }[] {
        return [
            { label: 'Pendiente', value: 'PENDIENTE' },
            { label: 'Aprobada', value: 'APROBADA' },
            { label: 'Rechazada', value: 'RECHAZADA' },
            { label: 'Cancelada', value: 'CANCELADA' },
            { label: 'Completada', value: 'COMPLETADA' }
        ];
    }

    getPrioridadesSolicitud(): { label: string, value: string }[] {
        return [
            { label: 'Baja', value: 'BAJA' },
            { label: 'Media', value: 'MEDIA' },
            { label: 'Alta', value: 'ALTA' },
            { label: 'Urgente', value: 'URGENTE' }
        ];
    }

    // Método para datos de demostración (solo para fallback)
    getDemoSolicitudes(): Solicitud[] {
        return [
            {
                solicitud_id: 1,
                fecha_creacion: new Date('2023-12-01'),
                bodega_origen_id: 1,
                bodega_destino_id: 2,
                estado: 'APROBADA',
                prioridad: 'MEDIA',
                justificacion: 'Reposición de stock',
                empleado_id: 1,
                items: [
                    {
                        item_id: 1,
                        solicitud_id: 1,
                        producto_id: 1,
                        cantidad: 10,
                        cantidad_aprobada: 10
                    },
                    {
                        item_id: 2,
                        solicitud_id: 1,
                        producto_id: 2,
                        cantidad: 5,
                        cantidad_aprobada: 5
                    }
                ]
            },
            {
                solicitud_id: 2,
                fecha_creacion: new Date('2023-12-05'),
                bodega_origen_id: 1,
                bodega_destino_id: 3,
                estado: 'PENDIENTE',
                prioridad: 'ALTA',
                justificacion: 'Stock crítico de productos esenciales',
                empleado_id: 2,
                items: [
                    {
                        item_id: 3,
                        solicitud_id: 2,
                        producto_id: 3,
                        cantidad: 8
                    }
                ]
            },
            {
                solicitud_id: 3,
                fecha_creacion: new Date('2023-12-10'),
                bodega_origen_id: 2,
                bodega_destino_id: 1,
                estado: 'RECHAZADA',
                prioridad: 'BAJA',
                justificacion: 'Ajuste de inventario',
                empleado_id: 3,
                items: [
                    {
                        item_id: 4,
                        solicitud_id: 3,
                        producto_id: 1,
                        cantidad: 3
                    },
                    {
                        item_id: 5,
                        solicitud_id: 3,
                        producto_id: 4,
                        cantidad: 12
                    }
                ]
            }
        ];
    }

    // Manejo de errores
    private handleError(error: any) {
        let errorMessage = '';
        if (error.error instanceof ErrorEvent) {
            // Error del cliente
            errorMessage = `Error: ${error.error.message}`;
        } else {
            // Error del servidor
            errorMessage = `Código de error: ${error.status}\nMensaje: ${error.message}`;
        }
        console.error(errorMessage);
        return throwError(() => new Error(errorMessage));
    }
} 