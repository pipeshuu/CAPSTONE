import { Component, OnInit, signal, ViewChild } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Table, TableModule } from 'primeng/table';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { RippleModule } from 'primeng/ripple';
import { ToastModule } from 'primeng/toast';
import { ToolbarModule } from 'primeng/toolbar';
import { InputTextModule } from 'primeng/inputtext';
import { TextareaModule } from 'primeng/textarea';
import { SelectModule } from 'primeng/select';
import { RadioButtonModule } from 'primeng/radiobutton';
import { InputNumberModule } from 'primeng/inputnumber';
import { DialogModule } from 'primeng/dialog';
import { TagModule } from 'primeng/tag';
import { InputIconModule } from 'primeng/inputicon';
import { IconFieldModule } from 'primeng/iconfield';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { DropdownModule } from 'primeng/dropdown';
import { CheckboxModule } from 'primeng/checkbox';
import { Empleado, EmpleadoService } from '../../services/empleado.service';
import { BodegaService } from '../../services/bodega.service';
import { Usuario, UsuarioService } from '../../services/usuario.service';
import { TabViewModule } from 'primeng/tabview';
import { DividerModule } from 'primeng/divider';
import { PasswordModule } from 'primeng/password';

interface Column {
    field: string;
    header: string;
    customExportHeader?: string;
}

interface ExportColumn {
    title: string;
    dataKey: string;
}

@Component({
    selector: 'app-empleados',
    standalone: true,
    imports: [
        CommonModule,
        TableModule,
        FormsModule,
        ButtonModule,
        RippleModule,
        ToastModule,
        ToolbarModule,
        InputTextModule,
        TextareaModule,
        SelectModule,
        RadioButtonModule,
        InputNumberModule,
        DialogModule,
        TagModule,
        InputIconModule,
        IconFieldModule,
        ConfirmDialogModule,
        DropdownModule,
        CheckboxModule,
        TabViewModule,
        DividerModule,
        PasswordModule
    ],
    providers: [MessageService, ConfirmationService],
    template: `
        <p-toast></p-toast>
        
        <p-toolbar styleClass="mb-6">
            <ng-template #start>
                <p-button label="Nuevo" icon="pi pi-plus" severity="secondary" class="mr-2" (onClick)="openNew()" />
                <p-button severity="secondary" label="Eliminar" icon="pi pi-trash" outlined (onClick)="deleteSelectedEmpleados()" [disabled]="!selectedEmpleados || !selectedEmpleados.length" />
            </ng-template>

            <ng-template #end>
                <p-button label="Exportar" icon="pi pi-upload" severity="secondary" (onClick)="exportCSV()" />
            </ng-template>
        </p-toolbar>

        <p-table
            #dt
            [value]="empleados()"
            [rows]="10"
            [columns]="cols"
            [paginator]="true"
            [globalFilterFields]="['nombre', 'apellidos', 'cedula', 'cargo', 'email']"
            [tableStyle]="{ 'min-width': '75rem' }"
            [(selection)]="selectedEmpleados"
            [rowHover]="true"
            dataKey="empleado_id"
            currentPageReportTemplate="Mostrando {first} a {last} de {totalRecords} empleados"
            [showCurrentPageReport]="true"
            [rowsPerPageOptions]="[10, 20, 30]"
            [loading]="loading"
        >
            <ng-template #caption>
                <div class="flex items-center justify-between">
                    <h5 class="m-0">Gestión de Empleados</h5>
                    <p-iconfield>
                        <p-inputicon styleClass="pi pi-search" />
                        <input pInputText type="text" (input)="onGlobalFilter(dt, $event)" placeholder="Buscar..." />
                    </p-iconfield>
                </div>
            </ng-template>
            <ng-template #header>
                <tr>
                    <th style="width: 3rem">
                        <p-tableHeaderCheckbox />
                    </th>
                    <th pSortableColumn="empleado_id" style="min-width: 4rem">
                        ID
                        <p-sortIcon field="empleado_id" />
                    </th>
                    <th pSortableColumn="nombre" style="min-width: 10rem">
                        Nombre
                        <p-sortIcon field="nombre" />
                    </th>
                    <th pSortableColumn="apellidos" style="min-width: 10rem">
                        Apellidos
                        <p-sortIcon field="apellidos" />
                    </th>
                    <th pSortableColumn="cedula" style="min-width: 8rem">
                        Cédula
                        <p-sortIcon field="cedula" />
                    </th>
                    <th pSortableColumn="cargo" style="min-width: 8rem">
                        Cargo
                        <p-sortIcon field="cargo" />
                    </th>
                    <th pSortableColumn="email" style="min-width: 12rem">
                        Email
                        <p-sortIcon field="email" />
                    </th>
                    <th pSortableColumn="bodega_id" style="min-width: 10rem">
                        Bodega
                        <p-sortIcon field="bodega_id" />
                    </th>
                    <th pSortableColumn="activo" style="min-width: 6rem">
                        Estado
                        <p-sortIcon field="activo" />
                    </th>
                    <th pSortableColumn="usuario_id" style="min-width: 8rem">
                        Usuario
                        <p-sortIcon field="usuario_id" />
                    </th>
                    <th style="min-width: 10rem"></th>
                </tr>
            </ng-template>
            <ng-template #body let-empleado>
                <tr>
                    <td style="width: 3rem">
                        <p-tableCheckbox [value]="empleado" />
                    </td>
                    <td style="min-width: 4rem">{{ empleado.empleado_id }}</td>
                    <td style="min-width: 10rem">{{ empleado.nombre }}</td>
                    <td style="min-width: 10rem">{{ empleado.apellidos }}</td>
                    <td style="min-width: 8rem">{{ empleado.cedula }}</td>
                    <td style="min-width: 8rem">
                        <p-tag [value]="empleado.cargo" [severity]="getCargoSeverity(empleado.cargo)" />
                    </td>
                    <td style="min-width: 12rem">{{ empleado.email }}</td>
                    <td style="min-width: 10rem">{{ getBodegaNombre(empleado.bodega_id) }}</td>
                    <td style="min-width: 6rem">
                        <p-tag [value]="empleado.activo ? 'Activo' : 'Inactivo'" [severity]="empleado.activo ? 'success' : 'danger'" />
                    </td>
                    <td style="min-width: 8rem">
                        <p-tag 
                            *ngIf="empleado.usuario_id" 
                            value="Vinculado" 
                            severity="success" 
                            icon="pi pi-user"
                        ></p-tag>
                        <p-tag 
                            *ngIf="!empleado.usuario_id" 
                            value="Sin usuario" 
                            severity="warn" 
                            icon="pi pi-user-minus"
                        ></p-tag>
                    </td>
                    <td>
                        <p-button icon="pi pi-pencil" class="mr-2" [rounded]="true" [outlined]="true" (click)="editEmpleado(empleado)" />
                        <p-button icon="pi pi-trash" severity="danger" [rounded]="true" [outlined]="true" (click)="deleteEmpleado(empleado)" />
                        <p-button 
                            *ngIf="!empleado.usuario_id"
                            icon="pi pi-user-plus" 
                            severity="info" 
                            [rounded]="true" 
                            [outlined]="true" 
                            class="ml-2" 
                            pTooltip="Vincular usuario" 
                            (click)="openUserDialog(empleado)"
                        />
                    </td>
                </tr>
            </ng-template>
        </p-table>

        <!-- Diálogo para crear/editar empleado -->
        <p-dialog [(visible)]="empleadoDialog" [style]="{ width: '700px' }" header="Detalles de Empleado" [modal]="true">
            <p-tabView>
                <!-- Pestaña de datos del empleado -->
                <p-tabPanel header="Datos del Empleado">
                    <div class="flex flex-col gap-6">
                        <div class="grid grid-cols-12 gap-4">
                            <div class="col-span-6">
                                <label for="nombre" class="block font-bold mb-3">Nombre</label>
                                <input type="text" pInputText id="nombre" [(ngModel)]="empleado.nombre" required autofocus class="w-full" />
                                <small class="text-red-500" *ngIf="submitted && !empleado.nombre">Nombre es requerido.</small>
                            </div>
                            <div class="col-span-6">
                                <label for="apellidos" class="block font-bold mb-3">Apellidos</label>
                                <input type="text" pInputText id="apellidos" [(ngModel)]="empleado.apellidos" required class="w-full" />
                                <small class="text-red-500" *ngIf="submitted && !empleado.apellidos">Apellidos es requerido.</small>
                            </div>
                        </div>

                        <div class="grid grid-cols-12 gap-4">
                            <div class="col-span-6">
                                <label for="cedula" class="block font-bold mb-3">Cédula</label>
                                <input type="text" pInputText id="cedula" [(ngModel)]="empleado.cedula" required class="w-full" />
                                <small class="text-red-500" *ngIf="submitted && !empleado.cedula">Cédula es requerida.</small>
                            </div>
                            <div class="col-span-6">
                                <label for="telefono" class="block font-bold mb-3">Teléfono</label>
                                <input type="text" pInputText id="telefono" [(ngModel)]="empleado.telefono" class="w-full" />
                            </div>
                        </div>

                        <div class="grid grid-cols-12 gap-4">
                            <div class="col-span-12">
                                <label for="email" class="block font-bold mb-3">Email</label>
                                <input type="email" pInputText id="email" [(ngModel)]="empleado.email" class="w-full" />
                            </div>
                        </div>

                        <div class="grid grid-cols-12 gap-4">
                            <div class="col-span-6">
                                <label for="cargo" class="block font-bold mb-3">Cargo</label>
                                <p-dropdown [(ngModel)]="empleado.cargo" 
                                        [options]="cargos" 
                                        optionLabel="label" 
                                        optionValue="value" 
                                        placeholder="Seleccione Cargo" 
                                        [style]="{'width':'100%'}" 
                                        [showClear]="false" 
                                        appendTo="body" 
                                        required>
                                </p-dropdown>
                                <small class="text-red-500" *ngIf="submitted && !empleado.cargo">Cargo es requerido.</small>
                            </div>
                            <div class="col-span-6">
                                <label for="bodega_id" class="block font-bold mb-3">Bodega</label>
                                <p-dropdown [(ngModel)]="empleado.bodega_id" 
                                        [options]="bodegas" 
                                        optionLabel="label" 
                                        optionValue="value" 
                                        placeholder="Seleccione Bodega" 
                                        [style]="{'width':'100%'}" 
                                        [filter]="true" 
                                        filterBy="label" 
                                        [showClear]="true" 
                                        appendTo="body">
                                </p-dropdown>
                            </div>
                        </div>

                        <div class="grid grid-cols-12 gap-4">
                            <div class="col-span-12">
                                <label for="usuario_sistema" class="block font-bold mb-3">Usuario del Sistema</label>
                                <input type="text" pInputText id="usuario_sistema" [(ngModel)]="empleado.usuario_sistema" required class="w-full" />
                                <small class="text-red-500" *ngIf="submitted && !empleado.usuario_sistema">Usuario del sistema es requerido.</small>
                            </div>
                        </div>

                        <div class="grid grid-cols-12 gap-4">
                            <div class="col-span-6">
                                <div class="flex align-items-center">
                                    <p-checkbox [(ngModel)]="empleado.activo" [binary]="true" inputId="activo"></p-checkbox>
                                    <label for="activo" class="ml-2">Activo</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </p-tabPanel>

                <!-- Pestaña de cuenta de usuario vinculada (solo para crear) -->
                <p-tabPanel header="Cuenta de Usuario" *ngIf="isNewEmployee">
                    <div class="mb-4">
                        <div class="flex align-items-center mb-4">
                            <p-checkbox 
                                [(ngModel)]="createUserAccount" 
                                [binary]="true" 
                                inputId="createUserAccount">
                            </p-checkbox>
                            <label for="createUserAccount" class="ml-2 font-bold">
                                Crear cuenta de usuario vinculada
                            </label>
                        </div>
                        <p class="text-gray-600 text-sm mt-2" *ngIf="!createUserAccount">
                            También podrá vincular una cuenta de usuario posteriormente
                        </p>
                    </div>

                    <div *ngIf="createUserAccount" class="flex flex-col gap-4 mt-4">
                        <p-divider></p-divider>

                        <div class="grid grid-cols-12 gap-4">
                            <div class="col-span-12">
                                <label for="user_email" class="block font-bold mb-3">Email de usuario</label>
                                <input 
                                    type="email" 
                                    pInputText 
                                    id="user_email" 
                                    [(ngModel)]="newUser.email" 
                                    required 
                                    class="w-full" 
                                    [ngClass]="{'ng-invalid ng-dirty': submitted && !newUser.email}"
                                />
                                <small class="text-red-500" *ngIf="submitted && !newUser.email">Email es requerido.</small>
                            </div>
                        </div>

                        <div class="grid grid-cols-12 gap-4">
                            <div class="col-span-12">
                                <label for="user_password" class="block font-bold mb-3">Contraseña</label>
                                <p-password 
                                    id="user_password" 
                                    [(ngModel)]="newUser.password" 
                                    [toggleMask]="true"
                                    [feedback]="true"
                                    [required]="true"
                                    styleClass="w-full" 
                                    [ngClass]="{'ng-invalid ng-dirty': submitted && !newUser.password}"
                                ></p-password>
                                <small class="text-red-500" *ngIf="submitted && !newUser.password">Contraseña es requerida.</small>
                            </div>
                        </div>

                        <div class="grid grid-cols-12 gap-4">
                            <div class="col-span-6">
                                <div class="flex align-items-center">
                                    <p-checkbox [(ngModel)]="newUser.es_admin" [binary]="true" inputId="es_admin"></p-checkbox>
                                    <label for="es_admin" class="ml-2">Es administrador</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </p-tabPanel>
            </p-tabView>

            <ng-template #footer>
                <p-button label="Cancelar" icon="pi pi-times" text (click)="hideDialog()" />
                <p-button label="Guardar" icon="pi pi-check" (click)="saveEmpleado()" />
            </ng-template>
        </p-dialog>

        <!-- Diálogo para vincular usuario a empleado -->
        <p-dialog [(visible)]="vincularUsuarioDialog" [style]="{ width: '600px' }" header="Vincular Usuario a Empleado" [modal]="true">
            <div class="flex flex-col gap-6">
                <div class="mb-4" *ngIf="selectedEmpleado">
                    <h3 class="text-lg font-bold mb-2">Empleado seleccionado</h3>
                    <div>{{ selectedEmpleado.nombre }} {{ selectedEmpleado.apellidos }}</div>
                    <div class="text-sm text-gray-600">{{ selectedEmpleado.cargo }} - {{ selectedEmpleado.cedula }}</div>
                </div>

                <p-tabView>
                    <!-- Pestaña para crear un nuevo usuario -->
                    <p-tabPanel header="Crear Nuevo Usuario">
                        <div class="flex flex-col gap-4">
                            <div class="grid grid-cols-12 gap-4">
                                <div class="col-span-12">
                                    <label for="new_user_email" class="block font-bold mb-3">Email de usuario</label>
                                    <input 
                                        type="email" 
                                        pInputText 
                                        id="new_user_email" 
                                        [(ngModel)]="newUser.email" 
                                        required 
                                        class="w-full" 
                                    />
                                </div>
                            </div>

                            <div class="grid grid-cols-12 gap-4">
                                <div class="col-span-6">
                                    <label for="new_user_nombre" class="block font-bold mb-3">Nombre</label>
                                    <input 
                                        type="text" 
                                        pInputText 
                                        id="new_user_nombre" 
                                        [(ngModel)]="newUser.nombre" 
                                        required 
                                        class="w-full" 
                                    />
                                </div>
                                <div class="col-span-6">
                                    <label for="new_user_apellidos" class="block font-bold mb-3">Apellidos</label>
                                    <input 
                                        type="text" 
                                        pInputText 
                                        id="new_user_apellidos" 
                                        [(ngModel)]="newUser.apellidos" 
                                        required 
                                        class="w-full" 
                                    />
                                </div>
                            </div>

                            <div class="grid grid-cols-12 gap-4">
                                <div class="col-span-12">
                                    <label for="new_user_password" class="block font-bold mb-3">Contraseña</label>
                                    <p-password 
                                        id="new_user_password" 
                                        [(ngModel)]="newUser.password" 
                                        [toggleMask]="true"
                                        [feedback]="true"
                                        [required]="true"
                                        styleClass="w-full" 
                                    ></p-password>
                                </div>
                            </div>

                            <div class="grid grid-cols-12 gap-4">
                                <div class="col-span-6">
                                    <div class="flex align-items-center">
                                        <p-checkbox [(ngModel)]="newUser.es_admin" [binary]="true" inputId="new_user_es_admin"></p-checkbox>
                                        <label for="new_user_es_admin" class="ml-2">Es administrador</label>
                                    </div>
                                </div>
                            </div>

                            <div class="flex justify-end mt-4">
                                <p-button 
                                    label="Crear y Vincular" 
                                    icon="pi pi-user-plus" 
                                    (onClick)="crearYVincularUsuario()"
                                ></p-button>
                            </div>
                        </div>
                    </p-tabPanel>

                    <!-- Pestaña para vincular usuario existente -->
                    <p-tabPanel header="Vincular Usuario Existente">
                        <div class="flex flex-col gap-4">
                            <div class="grid grid-cols-12 gap-4">
                                <div class="col-span-12">
                                    <label for="usuario_existente" class="block font-bold mb-3">Seleccionar Usuario</label>
                                    <p-dropdown 
                                        [(ngModel)]="selectedUsuarioId" 
                                        [options]="usuariosSinEmpleado" 
                                        optionLabel="label" 
                                        optionValue="value" 
                                        placeholder="Seleccione Usuario" 
                                        [style]="{'width':'100%'}" 
                                        [filter]="true" 
                                        filterBy="label" 
                                        appendTo="body"
                                    ></p-dropdown>
                                </div>
                            </div>

                            <div class="flex justify-end mt-4">
                                <p-button 
                                    label="Vincular Usuario" 
                                    icon="pi pi-link" 
                                    [disabled]="!selectedUsuarioId"
                                    (onClick)="vincularUsuarioExistente()"
                                ></p-button>
                            </div>
                        </div>
                    </p-tabPanel>
                </p-tabView>
            </div>
        </p-dialog>

        <p-confirmdialog [style]="{ width: '450px' }" />
    `
})
export class Empleados implements OnInit {
    empleadoDialog: boolean = false;
    vincularUsuarioDialog: boolean = false;
    isNewEmployee: boolean = false;
    createUserAccount: boolean = false;

    empleados = signal<Empleado[]>([]);
    
    empleado: Empleado = {
        nombre: '',
        apellidos: '',
        cedula: '',
        cargo: 'VENDEDOR',
        activo: true,
        usuario_sistema: ''
    };

    selectedEmpleado: Empleado | null = null;
    selectedEmpleados: Empleado[] | null = null;
    selectedUsuarioId: string | null = null;

    // Para la creación de un nuevo usuario
    newUser = {
        email: '',
        nombre: '',
        apellidos: '',
        password: '',
        es_admin: false
    };

    submitted: boolean = false;
    loading: boolean = true;
    
    cargos: any[] = [];
    bodegas: any[] = [];
    usuariosSinEmpleado: any[] = [];

    @ViewChild('dt') dt!: Table;

    exportColumns!: ExportColumn[];
    cols!: Column[];

    constructor(
        private empleadoService: EmpleadoService,
        private bodegaService: BodegaService,
        private usuarioService: UsuarioService,
        private messageService: MessageService,
        private confirmationService: ConfirmationService
    ) {}

    exportCSV() {
        this.dt.exportCSV();
    }

    ngOnInit() {
        this.loadData();
        this.cargos = this.empleadoService.getCargos();
        this.loadBodegas();

        this.cols = [
            { field: 'empleado_id', header: 'ID' },
            { field: 'nombre', header: 'Nombre' },
            { field: 'apellidos', header: 'Apellidos' },
            { field: 'cedula', header: 'Cédula' },
            { field: 'cargo', header: 'Cargo' },
            { field: 'email', header: 'Email' },
            { field: 'bodega_id', header: 'Bodega' },
            { field: 'activo', header: 'Estado' },
            { field: 'usuario_id', header: 'Usuario' }
        ];

        this.exportColumns = this.cols.map((col) => ({ title: col.header, dataKey: col.field }));
    }

    loadData() {
        this.loading = true;
        this.empleadoService.getEmpleados()
            .then(data => {
                this.empleados.set(data);
                this.loading = false;
            })
            .catch(error => {
                console.error('Error al cargar empleados:', error);
                this.messageService.add({ 
                    severity: 'error', 
                    summary: 'Error', 
                    detail: 'Error al cargar empleados', 
                    life: 3000 
                });
                this.loading = false;
            });
    }

    loadBodegas() {
        this.bodegaService.getBodegas()
            .then(data => {
                this.bodegas = data.map(b => ({
                    label: b.nombre,
                    value: b.bodega_id
                }));

                // Añadir opción para "Sin bodega asignada"
                this.bodegas.unshift({
                    label: 'Sin bodega asignada',
                    value: null
                });
            })
            .catch(error => {
                console.error('Error al cargar bodegas:', error);
            });
    }

    loadUsuariosSinEmpleado() {
        this.usuarioService.getUsuarios()
            .then(usuarios => {
                // Filtramos usuarios que no estén ya asignados a empleados
                this.usuarioService.getUsuariosDisponibles().then((usuariosDisponibles: Usuario[]) => {
                    this.usuariosSinEmpleado = usuariosDisponibles.map((user: Usuario) => ({
                        label: `${user.nombre} ${user.apellidos} (${user.email})`,
                        value: user.usuario_id
                    }));
                });
            })
            .catch(error => {
                console.error('Error al cargar usuarios:', error);
                this.messageService.add({
                    severity: 'error',
                    summary: 'Error',
                    detail: 'Error al cargar usuarios disponibles',
                    life: 3000
                });
            });
    }

    onGlobalFilter(table: Table, event: Event) {
        table.filterGlobal((event.target as HTMLInputElement).value, 'contains');
    }

    openNew() {
        this.isNewEmployee = true;
        this.createUserAccount = false;
        this.empleado = {
            nombre: '',
            apellidos: '',
            cedula: '',
            cargo: 'VENDEDOR',
            activo: true,
            usuario_sistema: ''
        };
        this.newUser = {
            email: '',
            nombre: '',
            apellidos: '',
            password: '',
            es_admin: false
        };
        this.submitted = false;
        this.empleadoDialog = true;
    }

    editEmpleado(empleado: Empleado) {
        this.isNewEmployee = false;
        this.empleado = { ...empleado };
        this.empleadoDialog = true;
    }

    openUserDialog(empleado: Empleado) {
        this.selectedEmpleado = { ...empleado };
        this.selectedUsuarioId = null;
        this.newUser = {
            email: empleado.email || '',
            nombre: empleado.nombre || '',
            apellidos: empleado.apellidos || '',
            password: '',
            es_admin: false
        };
        this.loadUsuariosSinEmpleado();
        this.vincularUsuarioDialog = true;
    }

    deleteSelectedEmpleados() {
        this.confirmationService.confirm({
            message: '¿Está seguro de eliminar los empleados seleccionados?',
            header: 'Confirmar',
            icon: 'pi pi-exclamation-triangle',
            accept: () => {
                if (this.selectedEmpleados && this.selectedEmpleados.length > 0) {
                    const deletePromises = this.selectedEmpleados
                        .filter(empleado => empleado.empleado_id)
                        .map(empleado => this.empleadoService.deleteEmpleado(empleado.empleado_id!));
                    
                    Promise.all(deletePromises)
                        .then(() => {
                            this.loadData();
                            this.messageService.add({ 
                                severity: 'success', 
                                summary: 'Éxito', 
                                detail: 'Empleados eliminados correctamente', 
                                life: 3000 
                            });
                            this.selectedEmpleados = null;
                        })
                        .catch(error => {
                            console.error('Error al eliminar empleados:', error);
                            this.messageService.add({ 
                                severity: 'error', 
                                summary: 'Error', 
                                detail: 'No se pudieron eliminar todos los empleados', 
                                life: 3000 
                            });
                        });
                }
            }
        });
    }

    hideDialog() {
        this.empleadoDialog = false;
        this.vincularUsuarioDialog = false;
        this.submitted = false;
    }

    deleteEmpleado(empleado: Empleado) {
        this.confirmationService.confirm({
            message: `¿Está seguro de eliminar al empleado "${empleado.nombre} ${empleado.apellidos}"?`,
            header: 'Confirmar',
            icon: 'pi pi-exclamation-triangle',
            accept: () => {
                if (empleado.empleado_id) {
                    this.empleadoService.deleteEmpleado(empleado.empleado_id)
                        .then(() => {
                            this.loadData();
                            this.messageService.add({ 
                                severity: 'success', 
                                summary: 'Éxito', 
                                detail: 'Empleado eliminado correctamente', 
                                life: 3000 
                            });
                        })
                        .catch(error => {
                            console.error('Error al eliminar empleado:', error);
                            this.messageService.add({ 
                                severity: 'error', 
                                summary: 'Error', 
                                detail: 'No se pudo eliminar el empleado', 
                                life: 3000 
                            });
                        });
                }
            }
        });
    }

    saveEmpleado() {
        this.submitted = true;

        if (!this.empleado.nombre || !this.empleado.apellidos || !this.empleado.cedula || !this.empleado.cargo || !this.empleado.usuario_sistema) {
            return;
        }

        if (this.isNewEmployee && this.createUserAccount) {
            if (!this.newUser.email || !this.newUser.password) {
                return;
            }

            // Si es empleado nuevo y quiere crear usuario, primero creamos el usuario
            const usuarioData = {
                email: this.newUser.email,
                nombre: this.empleado.nombre,
                apellidos: this.empleado.apellidos,
                password: this.newUser.password
            };

            this.usuarioService.registerUsuario(usuarioData)
                .then((usuario: Usuario) => {
                    this.createEmpleadoWithUsuario(usuario.usuario_id);
                })
                .catch((error: any) => {
                    console.error('Error al crear usuario:', error);
                    this.messageService.add({
                        severity: 'error',
                        summary: 'Error',
                        detail: error.error?.detail || 'Error al crear usuario',
                        life: 3000
                    });
                });
        } else {
            // Caso normal: solo crear/actualizar empleado
            const saveOperation = this.empleado.empleado_id
                ? this.empleadoService.updateEmpleado(this.empleado)
                : this.empleadoService.createEmpleado(this.empleado);

            saveOperation
                .then(() => {
                    this.loadData();
                    this.messageService.add({ 
                        severity: 'success', 
                        summary: 'Éxito', 
                        detail: `Empleado ${this.empleado.empleado_id ? 'actualizado' : 'creado'} correctamente`, 
                        life: 3000 
                    });
                    this.empleadoDialog = false;
                    this.empleado = {
                        nombre: '',
                        apellidos: '',
                        cedula: '',
                        cargo: 'VENDEDOR',
                        activo: true,
                        usuario_sistema: ''
                    };
                })
                .catch(error => {
                    console.error('Error al guardar empleado:', error);
                    this.messageService.add({ 
                        severity: 'error', 
                        summary: 'Error', 
                        detail: `No se pudo ${this.empleado.empleado_id ? 'actualizar' : 'crear'} el empleado`, 
                        life: 3000 
                    });
                });
        }
    }

    createEmpleadoWithUsuario(usuario_id: string) {
        // Una vez creado el usuario, creamos el empleado vinculado
        this.empleadoService.createEmpleado(this.empleado)
            .then(empleado => {
                if (empleado.empleado_id) {
                    // Vinculamos el empleado con el usuario
                    this.usuarioService.asignarUsuarioAEmpleado(empleado.empleado_id, usuario_id)
                        .then(() => {
                            this.loadData();
                            this.messageService.add({
                                severity: 'success',
                                summary: 'Éxito',
                                detail: 'Empleado y usuario creados y vinculados correctamente',
                                life: 3000
                            });
                            this.empleadoDialog = false;
                            this.empleado = {
                                nombre: '',
                                apellidos: '',
                                cedula: '',
                                cargo: 'VENDEDOR',
                                activo: true,
                                usuario_sistema: ''
                            };
                        })
                        .catch(error => {
                            console.error('Error al vincular usuario con empleado:', error);
                            this.messageService.add({
                                severity: 'error',
                                summary: 'Advertencia',
                                detail: 'Empleado creado pero no se pudo vincular al usuario',
                                life: 3000
                            });
                            this.empleadoDialog = false;
                        });
                }
            })
            .catch(error => {
                console.error('Error al crear empleado:', error);
                this.messageService.add({
                    severity: 'error',
                    summary: 'Error',
                    detail: 'Error al crear empleado',
                    life: 3000
                });
            });
    }

    crearYVincularUsuario() {
        if (!this.selectedEmpleado || !this.selectedEmpleado.empleado_id) {
            this.messageService.add({
                severity: 'error',
                summary: 'Error',
                detail: 'No hay empleado seleccionado',
                life: 3000
            });
            return;
        }

        if (!this.newUser.email || !this.newUser.nombre || !this.newUser.apellidos || !this.newUser.password) {
            this.messageService.add({
                severity: 'error',
                summary: 'Error',
                detail: 'Todos los campos del usuario son requeridos',
                life: 3000
            });
            return;
        }

        const usuarioData = {
            email: this.newUser.email,
            nombre: this.newUser.nombre,
            apellidos: this.newUser.apellidos,
            password: this.newUser.password
        };

        this.usuarioService.registerUsuario(usuarioData)
            .then((usuario: Usuario) => {
                this.usuarioService.asignarUsuarioAEmpleado(this.selectedEmpleado!.empleado_id!, usuario.usuario_id)
                    .then(() => {
                        this.loadData();
                        this.messageService.add({
                            severity: 'success',
                            summary: 'Éxito',
                            detail: 'Usuario creado y vinculado al empleado correctamente',
                            life: 3000
                        });
                        this.vincularUsuarioDialog = false;
                    })
                    .catch((error: any) => {
                        console.error('Error al vincular usuario con empleado:', error);
                        this.messageService.add({
                            severity: 'error',
                            summary: 'Error',
                            detail: error.error?.detail || 'Error al vincular usuario con empleado',
                            life: 3000
                        });
                    });
            })
            .catch((error: any) => {
                console.error('Error al crear usuario:', error);
                this.messageService.add({
                    severity: 'error',
                    summary: 'Error',
                    detail: error.error?.detail || 'Error al crear usuario',
                    life: 3000
                });
            });
    }

    vincularUsuarioExistente() {
        if (!this.selectedEmpleado || !this.selectedEmpleado.empleado_id || !this.selectedUsuarioId) {
            this.messageService.add({
                severity: 'error',
                summary: 'Error',
                detail: 'Debe seleccionar un empleado y un usuario',
                life: 3000
            });
            return;
        }

        this.usuarioService.asignarUsuarioAEmpleado(this.selectedEmpleado.empleado_id, this.selectedUsuarioId)
            .then(() => {
                this.loadData();
                this.messageService.add({
                    severity: 'success',
                    summary: 'Éxito',
                    detail: 'Usuario vinculado al empleado correctamente',
                    life: 3000
                });
                this.vincularUsuarioDialog = false;
            })
            .catch(error => {
                console.error('Error al vincular usuario con empleado:', error);
                this.messageService.add({
                    severity: 'error',
                    summary: 'Error',
                    detail: error.error?.detail || 'Error al vincular usuario con empleado',
                    life: 3000
                });
            });
    }

    getCargoSeverity(cargo: string): 'success' | 'info' | 'warn' | 'danger' | 'secondary' | 'contrast' | undefined {
        switch (cargo) {
            case 'GERENTE':
                return 'info';
            case 'SUPERVISOR':
                return 'warn';
            case 'VENDEDOR':
                return 'success';
            case 'ALMACENISTA':
                return 'secondary';
            case 'ADMINISTRATIVO':
                return 'contrast';
            default:
                return 'secondary';
        }
    }

    getBodegaNombre(id: number | null | undefined): string {
        if (id === null || id === undefined) {
            return 'Sin asignar';
        }
        
        const bodega = this.bodegas.find(b => b.value === id);
        return bodega ? bodega.label : `Bodega #${id}`;
    }
} 