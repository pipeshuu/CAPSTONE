import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

export interface Producto {
  producto_id?: number;
  sku?: string;
  nombre?: string;
  descripcion?: string;
  unidad_medida?: string;
  peso?: number;
  categoria_id?: number;
  imagen_url?: string;
  precio?: number;
  categoria?: {
    categoria_id: number;
    nombre: string;
    descripcion: string;
  };
}

export interface Categoria {
  categoria_id: number;
  nombre: string;
  descripcion: string;
}

@Injectable({
  providedIn: 'root'
})
export class ProductosService {
  private apiUrl = `${environment.apiUrl}/productos`;

  constructor(private http: HttpClient) { }

  // Obtener el token desde el localStorage
  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('access_token');
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    });
  }

  // Obtener todos los productos
  getProductos(): Observable<Producto[]> {
    return this.http.get<Producto[]>(this.apiUrl, { headers: this.getAuthHeaders() })
      .pipe(
        catchError(this.handleError)
      );
  }

  // Obtener un producto por ID o SKU
  getProducto(identificador: string | number): Observable<Producto> {
    return this.http.get<Producto>(`${this.apiUrl}/${identificador}`, { headers: this.getAuthHeaders() })
      .pipe(
        catchError(this.handleError)
      );
  }

  // Crear un nuevo producto (con imagen)
  createProducto(producto: Producto, imagen?: File): Observable<Producto> {
    // Crear FormData para enviar datos + archivo
    const formData = new FormData();
    formData.append('sku', producto.sku!);
    formData.append('nombre', producto.nombre!);
    
    if (producto.descripcion) {
      formData.append('descripcion', producto.descripcion);
    }
    
    if (producto.unidad_medida) {
      formData.append('unidad_medida', producto.unidad_medida);
    }
    
    if (producto.peso !== undefined) {
      formData.append('peso', producto.peso.toString());
    }
    
    formData.append('categoria_id', producto.categoria_id!.toString());
    
    if (producto.precio !== undefined) {
      formData.append('precio', producto.precio.toString());
    }
    
    if (imagen) {
      formData.append('file', imagen);
    }

    // Enviar la petición sin Content-Type para que el navegador lo establezca automáticamente con boundary
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${localStorage.getItem('access_token')}`
    });

    return this.http.post<Producto>(this.apiUrl, formData, { headers })
      .pipe(
        catchError(this.handleError)
      );
  }

  // Actualizar un producto (con imagen)
  updateProducto(identificador: string | number, producto: Producto, imagen?: File): Observable<Producto> {
    const formData = new FormData();
    formData.append('sku', producto.sku!);
    formData.append('nombre', producto.nombre!);
    
    if (producto.descripcion) {
      formData.append('descripcion', producto.descripcion);
    }
    
    if (producto.unidad_medida) {
      formData.append('unidad_medida', producto.unidad_medida);
    }
    
    if (producto.peso !== undefined) {
      formData.append('peso', producto.peso.toString());
    }
    
    formData.append('categoria_id', producto.categoria_id!.toString());
    
    if (producto.precio !== undefined) {
      formData.append('precio', producto.precio.toString());
    }
    
    if (imagen) {
      formData.append('file', imagen);
    }

    // Enviar la petición sin Content-Type para que el navegador lo establezca automáticamente con boundary
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${localStorage.getItem('access_token')}`
    });

    return this.http.put<Producto>(`${this.apiUrl}/${identificador}`, formData, { headers })
      .pipe(
        catchError(this.handleError)
      );
  }

  // Eliminar un producto
  deleteProducto(identificador: string | number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${identificador}`, { headers: this.getAuthHeaders() })
      .pipe(
        catchError(this.handleError)
      );
  }

  // Obtener todas las categorías
  getCategorias(): Observable<Categoria[]> {
    return this.http.get<Categoria[]>(`${environment.apiUrl}/categorias`, { headers: this.getAuthHeaders() })
      .pipe(
        catchError(this.handleError)
      );
  }

  // Manejar errores
  private handleError(error: any) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // Error del cliente
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // Error del servidor
      errorMessage = `Código de error: ${error.status}\nMensaje: ${error.message}`;
    }
    console.error(errorMessage);
    return throwError(() => new Error(errorMessage));
  }
} 