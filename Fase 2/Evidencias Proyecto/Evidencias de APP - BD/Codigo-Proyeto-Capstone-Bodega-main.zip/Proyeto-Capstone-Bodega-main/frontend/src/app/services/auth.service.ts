import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { environment } from '../../environments/environment';
import { jwtDecode } from 'jwt-decode';

export interface LoginResponse {
    access_token: string;
    token_type: string;
}

interface DecodedToken {
    exp: number;
    sub: string;
    [key: string]: any;
}

@Injectable({
    providedIn: 'root'
})
export class AuthService {
    private apiUrl = environment.apiUrl;

    constructor(private http: HttpClient) {}

    login(username: string, password: string): Observable<LoginResponse> {
        // Crear el cuerpo de la solicitud en formato application/x-www-form-urlencoded
        const body = new URLSearchParams();
        body.set('username', username);
        body.set('password', password);
        
        const options = {
            headers: new HttpHeaders().set('Content-Type', 'application/x-www-form-urlencoded')
        };
        
        return this.http.post<LoginResponse>(`${this.apiUrl}/auth/login`, body.toString(), options)
            .pipe(
                tap(response => {
                    if (response.access_token) {
                        localStorage.setItem('access_token', response.access_token);
                    }
                })
            );
    }

    logout(): void {
        localStorage.removeItem('access_token');
    }

    isAuthenticated(): boolean {
        // Primero verificamos si existe un token
        const token = this.getToken();
        if (!token) {
            return false;
        }
        
        // Verificamos si el token ha expirado
        return !this.isTokenExpired();
    }

    getToken(): string | null {
        return localStorage.getItem('access_token');
    }
    
    isTokenExpired(): boolean {
        const token = this.getToken();
        if (!token) {
            return true;
        }
        
        try {
            const decodedToken = jwtDecode<DecodedToken>(token);
            const currentTime = Math.floor(Date.now() / 1000);
            
            // Si el tiempo de expiración es menor que el tiempo actual, el token ha expirado
            if (decodedToken.exp < currentTime) {
                // Borramos el token expirado del localStorage
                this.logout();
                return true;
            }
            
            return false;
        } catch (error) {
            // Si hay algún error al decodificar el token, asumimos que es inválido
            this.logout();
            return true;
        }
    }
} 