export const environment = {
  production: true,
  apiUrl: '/api/v1'  // En producción, asumimos que la API está en el mismo dominio
}; 